package com.usb.informer;
/**
 * Acceso directo a una unidad óptica USB (protocolo Bulk-Only + comandos SCSI/MMC)
 * mediante el UsbManager de Android, por reflexión.
 */
public class OpticalDisc implements Sectors {
    private static final String MGR = "android.hardware.usb.UsbManager";
    private static final String DEV = "android.hardware.usb.UsbDevice";
    private static final String ITF = "android.hardware.usb.UsbInterface";
    private static final String EP = "android.hardware.usb.UsbEndpoint";
    private static final String CONN = "android.hardware.usb.UsbDeviceConnection";

    private Object mgr, dev, conn, itf, inEp, outEp;
    private int tag = 1;
    private int lastGot;
    public int sectorSize() { return blockSize; }

    public int blockSize = 2048;
    public int blocks;
    public String vendor = "";
    public String product = "";
    /** Bit RMB del INQUIRY: el dispositivo dice ser extraíble. */
    public boolean removable;
    private int lastSent;
    /** Se ha escrito en el dispositivo: al cerrar no se suelta la interfaz (Android lo montaria y lo dejaria "sucio"). */
    private boolean wrote;
    /** Ultima conexion escrita y mantenida reservada hasta que se desenchufe o se vuelva a abrir. */
    private static OpticalDisc held;

    /** Libera de verdad la conexion mantenida (al desenchufar el dispositivo o al salir). */
    public static synchronized void dropHeld() {
        OpticalDisc h = held;
        held = null;
        if (h != null) h.reallyClose();
    }

    public OpticalDisc(Object mgr, Object dev) {
        this.mgr = mgr;
        this.dev = dev;
    }

    public void open() throws Exception {
        open(true);
    }

    /** optical = true exige una unidad de CD/DVD; false, un dispositivo de disco (pendrive, disco externo). */
    public void open(boolean optical) throws Exception {
        synchronized (OpticalDisc.class) {
            OpticalDisc h = held;
            if (h != null) {
                held = null;
                if (h.conn != null && h.dev != null && h.dev.equals(dev)) {
                    // reutiliza la conexion que seguia reservada tras escribir (sin devolver el USB a Android)
                    conn = h.conn; itf = h.itf; inEp = h.inEp; outEp = h.outEp;
                    h.conn = null;
                    wrote = true; // sigue reservada: cualquier cierre posterior tambien la mantiene
                    try {
                        openChecks(optical);
                        return;
                    } catch (Exception e) {
                        if (held == this) held = null;
                        reallyClose();
                        wrote = false;
                        itf = null; inEp = null; outEp = null;
                    }
                } else {
                    h.reallyClose();
                }
            }
        }
        int n = AndroidBridge.num(AndroidBridge.call0(dev, DEV, "getInterfaceCount"));
        for (int k = 0; k < n && itf == null; k++) {
            Object it = AndroidBridge.call(dev, DEV, "getInterface", new Class[] { Integer.TYPE }, new Object[] { AndroidBridge.i(k) });
            if (AndroidBridge.num(AndroidBridge.call0(it, ITF, "getInterfaceClass")) != 8) continue;
            int ne = AndroidBridge.num(AndroidBridge.call0(it, ITF, "getEndpointCount"));
            Object in = null, out = null;
            for (int e = 0; e < ne; e++) {
                Object ep = AndroidBridge.call(it, ITF, "getEndpoint", new Class[] { Integer.TYPE }, new Object[] { AndroidBridge.i(e) });
                int attrs = AndroidBridge.num(AndroidBridge.call0(ep, EP, "getAttributes"));
                int addr = AndroidBridge.num(AndroidBridge.call0(ep, EP, "getAddress"));
                if ((attrs & 3) != 2) continue;
                if ((addr & 0x80) != 0) in = ep; else out = ep;
            }
            if (in != null && out != null) {
                itf = it; inEp = in; outEp = out;
            }
        }
        if (itf == null) throw new Exception("El dispositivo no tiene interfaz de almacenamiento masivo");
        conn = AndroidBridge.call(mgr, MGR, "openDevice", new Class[] { Class.forName(DEV) }, new Object[] { dev });
        if (conn == null) throw new Exception("Android no dejó abrir el dispositivo (¿falta el permiso USB?)");
        boolean ok = AndroidBridge.bool(AndroidBridge.call(conn, CONN, "claimInterface",
                new Class[] { Class.forName(ITF), Boolean.TYPE }, new Object[] { itf, Boolean.TRUE }));
        if (!ok) {
            close();
            throw new Exception("No se pudo reclamar la interfaz USB de la unidad");
        }
        openChecks(optical);
    }

    private void openChecks(boolean optical) throws Exception {
        try {
            byte[] inq = new byte[36];
            int st = scsi(new byte[] { 0x12, 0, 0, 0, 36, 0 }, inq, 36);
            if (st == 0 && lastGot >= 32) {
                int type = inq[0] & 0x1F;
                removable = (inq[1] & 0x80) != 0;
                vendor = ascii(inq, 8, 8);
                product = ascii(inq, 16, 16);
                if (optical && type != 5) throw new Exception("No es una unidad de CD/DVD (tipo SCSI " + type + "), no la toco");
                if (!optical && type != 0 && type != 14) throw new Exception("No es un USB de almacenamiento (tipo SCSI " + type + ")");
            }
            waitReady();
            byte[] c = new byte[8];
            int st2 = scsi(new byte[] { 0x25, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, c, 8);
            if (st2 != 0 || lastGot < 8) throw new Exception("No se pudo leer la capacidad del disco");
            blocks = be32(c, 0) + 1;
            blockSize = be32(c, 4);
            if (blockSize <= 0) blockSize = 2048;
        } catch (Exception e) {
            close();
            throw e;
        }
    }

    public void close() {
        if (wrote && conn != null) {
            // tras escribir no se devuelve el USB a Android: lo montaria (Android/, LOST.DIR) y lo dejaria sucio
            flush();
            synchronized (OpticalDisc.class) {
                if (held != null && held != this) held.reallyClose();
                held = this;
            }
            return;
        }
        reallyClose();
    }

    private void reallyClose() {
        try {
            if (conn != null && itf != null) {
                AndroidBridge.call(conn, CONN, "releaseInterface", new Class[] { Class.forName(ITF) }, new Object[] { itf });
            }
        } catch (Throwable t) {
            // nada
        }
        try {
            if (conn != null) AndroidBridge.call0(conn, CONN, "close");
        } catch (Throwable t) {
            // nada
        }
        conn = null;
    }

    /** Lee hasta 8 sectores seguidos. */
    public synchronized byte[] read(int lba, int count) throws Exception {
        int len = count * blockSize;
        byte[] buf = new byte[len];
        byte[] cdb = { 0x28, 0, (byte) (lba >> 24), (byte) (lba >> 16), (byte) (lba >> 8), (byte) lba,
                0, (byte) (count >> 8), (byte) count, 0 };
        for (int k = 0; k < 3; k++) {
            int st = scsi(cdb, buf, len);
            if (st == 0 && lastGot == len) return buf;
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                break;
            }
        }
        throw new Exception("Error al leer el sector " + lba + " del disco");
    }

    /** Bytes por escritura SCSI (múltiplo de 512, 2048 y 4096). */
    public static final int WRITE_CHUNK = 65536;

    /** Escribe len bytes (múltiplo del tamaño de bloque) desde el bloque lba. DESTRUCTIVO. */
    public synchronized void write(int lba, byte[] data, int len) throws Exception {
        wrote = true;
        if (len % blockSize != 0) throw new Exception("Escritura no alineada al bloque");
        int count = len / blockSize;
        if (count > 65535) throw new Exception("Escritura demasiado grande");
        byte[] cdb = { 0x2A, 0, (byte) (lba >> 24), (byte) (lba >> 16), (byte) (lba >> 8), (byte) lba,
                0, (byte) (count >> 8), (byte) count, 0 };
        for (int k = 0; k < 3; k++) {
            int st = scsiOut(cdb, data, len);
            if (st == 0 && lastSent == len) return;
            byte[] sn = new byte[18];
            scsi(new byte[] { 3, 0, 0, 0, 18, 0 }, sn, 18);
            int key = sn[2] & 0x0F;
            int asc = sn[12] & 0xFF;
            if (key == 7 || asc == 0x27) throw new Exception("El USB está protegido contra escritura");
            if (key == 3 || key == 4) throw new Exception("Error de escritura en el bloque " + lba + " (el USB puede estar dañado)");
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                break;
            }
        }
        throw new Exception("Error al escribir el bloque " + lba + " del USB");
    }

    /** Sincroniza, permite quitar el medio y detiene la unidad. tray = expulsar la bandeja (CD/DVD). */
    public synchronized String eject(boolean tray) {
        wrote = true; // tras expulsar tampoco se devuelve el USB a Android
        flush();
        try {
            scsi(new byte[] { 0x1E, 0, 0, 0, 0, 0 }, null, 0);            // permitir extracción
            int st = scsi(new byte[] { 0x1B, 0, 0, 0, (byte) (tray ? 0x02 : 0x00), 0 }, null, 0);
            if (st != 0) return "El dispositivo no aceptó la orden de parada (ya está sincronizado igualmente).";
            return null;
        } catch (Throwable t) {
            return "No pude parar el dispositivo: " + t.getMessage();
        }
    }

    /** Vacía la caché de escritura del dispositivo (SYNCHRONIZE CACHE). */
    public synchronized void flush() {
        try {
            scsi(new byte[] { 0x35, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, null, 0);
        } catch (Throwable t) {
            // algunos dispositivos no lo soportan
        }
    }

    /** Comando con fase de datos de salida. Devuelve el estado del CSW (0 = correcto). */
    private synchronized int scsiOut(byte[] cdb, byte[] data, int len) throws Exception {
        byte[] cbw = new byte[31];
        cbw[0] = 0x55; cbw[1] = 0x53; cbw[2] = 0x42; cbw[3] = 0x43;
        int t = tag++;
        cbw[4] = (byte) t; cbw[5] = (byte) (t >> 8); cbw[6] = (byte) (t >> 16); cbw[7] = (byte) (t >> 24);
        cbw[8] = (byte) len; cbw[9] = (byte) (len >> 8); cbw[10] = (byte) (len >> 16); cbw[11] = (byte) (len >> 24);
        cbw[12] = 0;
        cbw[14] = (byte) cdb.length;
        System.arraycopy(cdb, 0, cbw, 15, cdb.length);
        int r = transfer(outEp, cbw, 31, 5000);
        if (r != 31) throw new Exception("Fallo al enviar el comando de escritura (" + r + ")");
        int sent = 0;
        while (sent < len) {
            int chunk = Math.min(len - sent, 16384);
            byte[] tmp = new byte[chunk];
            System.arraycopy(data, sent, tmp, 0, chunk);
            r = transfer(outEp, tmp, chunk, 20000);
            if (r <= 0) break;
            sent += r;
            if (r < chunk) break;
        }
        lastSent = sent;
        byte[] csw = new byte[13];
        r = transfer(inEp, csw, 13, 20000);
        if (r != 13) r = transfer(inEp, csw, 13, 5000);
        if (r != 13) throw new Exception("El USB no responde tras escribir (CSW " + r + ")");
        if (csw[0] != 0x55 || csw[1] != 0x53 || csw[2] != 0x42 || csw[3] != 0x53) {
            throw new Exception("Respuesta del USB no válida");
        }
        return csw[12] & 0xFF;
    }

    /** Tabla de contenidos: Vector de int[] { pista, control, lba }. La pista 0xAA es el final del disco. */
    public synchronized java.util.Vector readToc() throws Exception {
        java.util.Vector out = new java.util.Vector();
        byte[] t = new byte[804];
        int st = scsi(new byte[] { 0x43, 0, 0, 0, 0, 0, 1, (byte) (804 >> 8), (byte) 804, 0 }, t, 804);
        if (st != 0 || lastGot < 12) throw new Exception("No se pudo leer la tabla de pistas del disco");
        int dataLen = ((t[0] & 0xFF) << 8) | (t[1] & 0xFF);
        int n = (Math.min(dataLen + 2, lastGot) - 4) / 8;
        for (int k = 0; k < n; k++) {
            int o = 4 + k * 8;
            out.addElement(new int[] { t[o + 2] & 0xFF, t[o + 1] & 0x0F, be32(t, o + 4) });
        }
        return out;
    }

    /** Lee sectores de audio (2352 bytes por sector, PCM 44,1 kHz 16 bits estéreo). Hasta 16 sectores. */
    public synchronized byte[] readAudio(int lba, int count) throws Exception {
        int len = count * 2352;
        byte[] buf = new byte[len];
        byte[] cdb = { (byte) 0xBE, 0x04, (byte) (lba >> 24), (byte) (lba >> 16), (byte) (lba >> 8), (byte) lba,
                (byte) (count >> 16), (byte) (count >> 8), (byte) count, 0x10, 0, 0 };
        for (int k = 0; k < 3; k++) {
            int st = scsi(cdb, buf, len);
            if (st == 0 && lastGot == len) return buf;
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                break;
            }
        }
        throw new Exception("Error al leer audio en el sector " + lba);
    }

    /** Protección de copia del DVD: 0 ninguna, 1 CSS, 2 CPRM; -1 si no se sabe. */
    public synchronized int copyProtection() {
        try {
            byte[] b = new byte[8];
            int st = scsi(new byte[] { (byte) 0xAD, 0, 0, 0, 0, 0, 0, 1, 0, 8, 0, 0 }, b, 8);
            if (st != 0 || lastGot < 8) return -1;
            return b[4] & 0xFF;
        } catch (Throwable t) {
            return -1;
        }
    }

    private void waitReady() throws Exception {
        for (int k = 0; k < 12; k++) {
            int st = scsi(new byte[6], null, 0);
            if (st == 0) return;
            byte[] s = new byte[18];
            scsi(new byte[] { 3, 0, 0, 0, 18, 0 }, s, 18);
            int asc = s[12] & 0xFF;
            if (asc == 0x3A) throw new Exception("No hay disco en la unidad");
            try {
                Thread.sleep(asc == 0x28 ? 400 : 1000);
            } catch (InterruptedException e) {
                break;
            }
        }
        throw new Exception("La unidad no está lista (¿el disco está girando o es ilegible?)");
    }

    private int transfer(Object ep, byte[] buf, int len, int timeout) throws Exception {
        return AndroidBridge.num(AndroidBridge.call(conn, CONN, "bulkTransfer",
                new Class[] { Class.forName(EP), byte[].class, Integer.TYPE, Integer.TYPE },
                new Object[] { ep, buf, AndroidBridge.i(len), AndroidBridge.i(timeout) }));
    }

    /** Comando con fase de datos de entrada. Devuelve el estado del CSW (0 = correcto). */
    private synchronized int scsi(byte[] cdb, byte[] data, int len) throws Exception {
        byte[] cbw = new byte[31];
        cbw[0] = 0x55; cbw[1] = 0x53; cbw[2] = 0x42; cbw[3] = 0x43;
        int t = tag++;
        cbw[4] = (byte) t; cbw[5] = (byte) (t >> 8); cbw[6] = (byte) (t >> 16); cbw[7] = (byte) (t >> 24);
        cbw[8] = (byte) len; cbw[9] = (byte) (len >> 8); cbw[10] = (byte) (len >> 16); cbw[11] = (byte) (len >> 24);
        cbw[12] = (byte) (len > 0 ? 0x80 : 0);
        cbw[14] = (byte) cdb.length;
        System.arraycopy(cdb, 0, cbw, 15, cdb.length);
        int r = transfer(outEp, cbw, 31, 5000);
        if (r != 31) throw new Exception("Fallo al enviar el comando a la unidad (" + r + ")");
        int got = 0;
        while (got < len) {
            int chunk = Math.min(len - got, 16384);
            byte[] tmp = new byte[chunk];
            r = transfer(inEp, tmp, chunk, 10000);
            if (r <= 0) break;
            System.arraycopy(tmp, 0, data, got, r);
            got += r;
            if (r < chunk) break;
        }
        lastGot = got;
        byte[] csw = new byte[13];
        r = transfer(inEp, csw, 13, 5000);
        if (r != 13) r = transfer(inEp, csw, 13, 5000);
        if (r != 13) throw new Exception("La unidad no responde (CSW " + r + ")");
        if (csw[0] != 0x55 || csw[1] != 0x53 || csw[2] != 0x42 || csw[3] != 0x53) {
            throw new Exception("Respuesta de la unidad no válida");
        }
        return csw[12] & 0xFF;
    }

    private static int be32(byte[] b, int o) {
        return ((b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF);
    }

    private static String ascii(byte[] b, int off, int len) {
        StringBuffer sb = new StringBuffer();
        for (int i = off; i < off + len; i++) {
            int c = b[i] & 0xFF;
            sb.append(c >= 32 && c < 127 ? (char) c : ' ');
        }
        return sb.toString().trim();
    }
}
