package com.usb.informer;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Vector;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.StringItem;
import javax.microedition.lcdui.TextField;

/**
 * Graba una imagen ISO en un USB a bajo nivel (como dd). DESTRUCTIVO: borra todo el USB.
 * La imagen puede venir de un archivo del teléfono, de otro USB o de un CD/DVD.
 */
public class ImageUi implements CommandListener {
    private Display display;
    private UsbExtras x;
    private Displayable ret;
    private UsbDevInfo target;
    private Vector devices;

    private Command backCmd = new Command("Atrás", Command.BACK, 1);
    private Command okCmd = new Command("Aceptar", Command.OK, 1);
    private Command writeVerCmd = new Command("Grabar y verificar", Command.OK, 1);
    private Command writeCmd = new Command("Grabar sin verificar", Command.SCREEN, 2);
    private Command browseCmd = new Command("Examinar archivos del VHD", Command.SCREEN, 3);
    private Command connectCmd = new Command("Conectar", Command.OK, 1);
    private Command pathCmd = new Command("Usar esta ruta", Command.OK, 1);

    private List menu, roots, devList, browser;
    private Form confirm, working, result, pathForm, noteForm, ftpForm;
    private TextField ftpHost, ftpPort, ftpUser, ftpPass;
    private FtpFs ftp;
    private TextField sure, pathField;
    private StringItem status;
    private Displayable noteNext;

    private OpticalDisc tgt;      // USB de destino (abierto al confirmar)
    private OpticalDisc srcDisc;  // USB o CD de origen
    private FileSource srcFs;
    private ImageSource image;
    private Vector rootPaths = new Vector();
    private Vector devChoices = new Vector();
    private Vector entries = new Vector();
    private Vector stack = new Vector();
    private int mode;             // 1 = archivo, 2 = otro USB, 3 = CD
    private boolean contents;     // true = formatear FAT32 y copiar el CONTENIDO de la ISO (o del VHD)
    private boolean win;          // true = instalador de Windows: FAT32 normal (boot) + exFAT con la ISO completa
    private WinWriter ww;
    private ExtWriter ext;       // initrd cpio -> USB con ext2
    private boolean initrd;
    private TextField extName;
    private TextField fatName, ntfsName;
    private boolean vhd;          // true = el origen es un VHD (fijo o dinámico), no una ISO
    private String vhdStyle = "";  // tabla de particiones del VHD: GPT, MBR o NONE
    private boolean browse;       // true = solo examinar el VHD con el explorador (no se graba nada)
    private FileSource vhdFs;     // sistema de archivos montado del VHD
    private MediaUi media;

    public void setMedia(MediaUi m) {
        media = m;
    }
    private FileItem imgItem;
    private FatWriter fw;
    private volatile boolean cancel;
    private volatile boolean running;

    public ImageUi(Display d) {
        display = d;
    }

    public void setBackend(UsbExtras e) {
        x = e;
    }

    // ------------------------------------------------------------ utilidades

    private static String msg(Throwable t) {
        String m = t.getMessage();
        return m != null && m.length() > 0 ? m : t.toString();
    }

    private void note(String title, String text, Displayable next) {
        noteForm = new Form(title);
        noteForm.append(new StringItem(null, text));
        noteForm.addCommand(okCmd);
        noteForm.addCommand(backCmd);
        noteForm.setCommandListener(this);
        noteNext = next;
        display.setCurrent(noteForm);
    }

    private void closeAll() {
        if (tgt != null) tgt.close();
        if (srcDisc != null) srcDisc.close();
        if (ftp != null) ftp.close();
        ftp = null;
        tgt = null;
        srcDisc = null;
        srcFs = null;
        image = null;
        imgItem = null;
        fw = null;
        ww = null;
        ext = null;
    }

    private static String size(long n) {
        return Phone.sizeText(n);
    }

    // ------------------------------------------------------------ 1. elegir origen

    public void start(UsbDevInfo dev, Vector allDevices, Displayable back) {
        start(dev, allDevices, back, 0);
    }

    public void start(UsbDevInfo dev, Vector allDevices, Displayable back, int kind) {
        if (x == null) return;
        contents = kind == 1 || kind == 3;
        vhd = kind == 3 || kind == 4 || kind == 5;
        browse = kind == 4;
        win = kind == 2;
        initrd = kind == 6;
        if (running) {
            note("Grabar imagen", "Ya hay una grabación en curso.", back);
            return;
        }
        ret = back;
        target = dev;
        devices = allDevices;
        closeAll();
        if (dev.needsPermission && !browse) {
            note("Grabar imagen", "Primero concede el permiso USB a este dispositivo (menú principal: Pedir permiso USB).", back);
            return;
        }
        if (vhd) {
            menu = new List(browse ? "Examinar un VHD" : (contents ? "Contenido de un VHD en " : "Clonar un VHD en ") + dev.label(), Choice.IMPLICIT);
            menu.append("VHD desde un archivo del teléfono", null);
            menu.append("VHD desde otro USB (conectado a la vez)", null);
            menu.append("VHD desde un servidor FTP (también el del propio teléfono)", null);
        } else if (initrd) {
            menu = new List("Initrd en ext2 en " + dev.label(), Choice.IMPLICIT);
            menu.append("Initrd (cpio) desde un archivo del teléfono", null);
            menu.append("Initrd desde otro USB (conectado a la vez)", null);
            menu.append("Initrd desde un servidor FTP (también el del propio teléfono)", null);
        } else {
            boolean iso = contents || win;
            menu = new List((win ? "Instalador Windows en " : (contents ? "Contenido de ISO en " : "Grabar ISO en ")) + dev.label(), Choice.IMPLICIT);
            menu.append(iso ? "ISO desde un archivo del teléfono" : "Imagen desde un archivo del teléfono", null);
            menu.append(iso ? "ISO desde otro USB (conectado a la vez)" : "Imagen desde otro USB (conectado a la vez)", null);
            menu.append(iso ? "Copiar el contenido de un CD/DVD en este USB" : "Clonar un CD/DVD en este USB", null);
            menu.append((iso ? "ISO" : "Imagen") + " desde un servidor FTP (también el del propio teléfono)", null);
        }
        menu.addCommand(backCmd);
        menu.setCommandListener(this);
        display.setCurrent(menu);
    }

    private void showRoots() {
        mode = 1;
        rootPaths.removeAllElements();
        roots = new List(vhd ? "Dónde está el VHD" : initrd ? "Dónde está el initrd" : "Dónde está la ISO", Choice.IMPLICIT);
        String[] cand = { "/storage/emulated/0/Download", "/sdcard/Download", "/storage/emulated/0/Documents",
                "/storage/emulated/0" };
        for (int i = 0; i < cand.length; i++) {
            File f = new File(cand[i]);
            if (f.isDirectory()) {
                rootPaths.addElement(cand[i]);
                roots.append(cand[i], null);
            }
        }
        try {
            Object ctx = AndroidBridge.context();
            Object d = AndroidBridge.call(ctx, "android.content.Context", "getExternalFilesDir",
                    new Class[] { String.class }, new Object[] { null });
            if (d != null) {
                String p = ((File) d).getPath();
                rootPaths.addElement(p);
                roots.append("Carpeta de J2ME Loader: " + p, null);
            }
        } catch (Throwable t) {
            // sin carpeta de la app
        }
        rootPaths.addElement("");
        roots.append("Escribir la ruta a mano...", null);
        roots.addCommand(backCmd);
        roots.setCommandListener(this);
        display.setCurrent(roots);
    }

    private void showFtpForm() {
        mode = 4;
        ftpForm = new Form("Servidor FTP");
        ftpHost = new TextField("Servidor", ftpHost != null ? ftpHost.getString() : "127.0.0.1", 100, TextField.ANY);
        ftpPort = new TextField("Puerto", ftpPort != null ? ftpPort.getString() : "2121", 5, TextField.NUMERIC);
        ftpUser = new TextField("Usuario (vacío = anónimo)", ftpUser != null ? ftpUser.getString() : "", 50, TextField.ANY);
        ftpPass = new TextField("Contraseña", "", 50, TextField.PASSWORD);
        ftpForm.append(ftpHost);
        ftpForm.append(ftpPort);
        ftpForm.append(ftpUser);
        ftpForm.append(ftpPass);
        ftpForm.append(new StringItem(null,
                "Abre en el teléfono una app de servidor FTP que comparta la carpeta donde está " + (vhd ? "el VHD" : "la ISO") + " (por ejemplo Descargas) "
                + "y pon aquí su dirección y puerto. En el propio teléfono: 127.0.0.1."));
        ftpForm.addCommand(connectCmd);
        ftpForm.addCommand(backCmd);
        ftpForm.setCommandListener(this);
        display.setCurrent(ftpForm);
    }

    private void connectFtp() {
        int port;
        try {
            port = Integer.parseInt(ftpPort.getString().trim());
        } catch (Throwable t) {
            note("FTP", "El puerto no es válido.", ftpForm);
            return;
        }
        final FtpFs f = new FtpFs(ftpHost.getString().trim(), port, ftpUser.getString().trim(), ftpPass.getString());
        final Form busy = new Form("Conectando");
        busy.append("Conectando con el servidor FTP...");
        busy.addCommand(backCmd);
        busy.setCommandListener(this);
        working = busy;
        display.setCurrent(busy);
        new Thread(new Runnable() {
            public void run() {
                try {
                    f.connect();
                    Vector root = f.listRoot();
                    if (ftp != null) ftp.close();
                    ftp = f;
                    srcFs = f;
                    stack.removeAllElements();
                    showBrowser(root, "FTP " + ftpHost.getString().trim());
                } catch (Throwable t) {
                    f.close();
                    note("FTP", "No se pudo conectar: " + msg(t)
                            + "\n\nComprueba que el servidor FTP está encendido y que servidor y puerto son correctos.", ftpForm);
                }
            }
        }).start();
    }

    private void showPathForm() {
        pathForm = new Form("Ruta de la ISO");
        pathField = new TextField("Ruta completa del archivo", "/storage/emulated/0/Download/", 300, TextField.ANY);
        pathForm.append(pathField);
        pathForm.append(new StringItem(null,
                "Android puede impedir que J2ME Loader lea archivos de otras apps. Si falla, usa 'Otro USB' "
                + "(copia antes la ISO a un pendrive) o 'Clonar CD/DVD'."));
        pathForm.addCommand(pathCmd);
        pathForm.addCommand(backCmd);
        pathForm.setCommandListener(this);
        display.setCurrent(pathForm);
    }

    private void useLocalPath(String path) {
        File f = new File(path);
        if (!f.isFile() || !f.canRead()) {
            note("Ruta", "No puedo leer ese archivo. Android suele ocultar a J2ME Loader los archivos de otras apps "
                    + "(Descargas). Copia la ISO a otro pendrive y elige 'Otro USB', o clona el CD/DVD.", roots != null ? roots : menu);
            return;
        }
        FileItem it = new FileItem();
        it.name = f.getName();
        it.size = f.length();
        it.ref = f;
        srcFs = new LocalVolume(f.getParentFile(), "teléfono");
        imgItem = it;
        image = new FsImage(srcFs, it);
        askConfirm();
    }

    private void showDeviceChoice(final boolean optical) {
        mode = optical ? 3 : 2;
        devChoices.removeAllElements();
        devList = new List(optical ? "Elige la unidad de CD/DVD" : "Elige el USB con la ISO", Choice.IMPLICIT);
        for (int i = 0; i < devices.size(); i++) {
            UsbDevInfo d = (UsbDevInfo) devices.elementAt(i);
            if (d.deviceName.equals(target.deviceName)) continue;
            if (!d.mass) continue;
            if (d.optical != optical) continue;
            devChoices.addElement(d);
            devList.append(d.label() + (d.needsPermission ? " (sin permiso USB)" : ""), null);
        }
        if (devChoices.size() == 0) {
            note("Origen", optical ? "No hay ninguna unidad de CD/DVD USB conectada."
                    : "No hay otro USB de almacenamiento conectado. Conecta el que tiene la ISO (con un hub o USB-C múltiple).", menu);
            return;
        }
        devList.addCommand(backCmd);
        devList.setCommandListener(this);
        display.setCurrent(devList);
    }

    private void openSource(final UsbDevInfo d) {
        if (d.needsPermission) {
            note("Origen", "Concede primero el permiso USB a ese dispositivo (menú principal: Pedir permiso USB).", devList);
            return;
        }
        final Form busy = new Form("Abriendo");
        busy.append("Leyendo el origen...");
        busy.addCommand(backCmd);
        busy.setCommandListener(this);
        working = busy;
        display.setCurrent(busy);
        new Thread(new Runnable() {
            public void run() {
                OpticalDisc o = null;
                try {
                    o = x.openDisc(d, mode == 3);
                    if (mode == 3) {
                        srcDisc = o;
                        image = new DiscImage(o, d.label());
                        askConfirm();
                    } else {
                        FileSource fs = UsbVolume.mount(o);
                        srcDisc = o;
                        srcFs = fs;
                        stack.removeAllElements();
                        showBrowser(fs.listRoot(), "USB " + d.label());
                    }
                } catch (Throwable t) {
                    if (o != null) o.close();
                    srcDisc = null;
                    note("Origen", msg(t), devList);
                }
            }
        }).start();
    }

    // ------------------------------------------------------------ navegador de imágenes

    private String browserTitle = "";

    private void showBrowser(Vector list, String title) {
        browserTitle = title;
        entries = new Vector();
        browser = new List(title, Choice.IMPLICIT);
        for (int i = 0; i < list.size(); i++) {
            FileItem it = (FileItem) list.elementAt(i);
            String n = it.name.toLowerCase();
            if (it.dir) {
                entries.addElement(it);
                browser.append("[" + it.name + "]", null);
            } else if (isImage(n)) {
                entries.addElement(it);
                browser.append(it.name + " (" + size(it.size) + ")", null);
            }
        }
        if (entries.size() == 0) browser.append(vhd ? "(no veo archivos .vhd aquí; Android oculta archivos de otras apps)" : initrd ? "(no veo ningún initrd (.img, .gz, .cpio) aquí)" : "(no veo imágenes .iso/.img aquí; Android oculta archivos de otras apps)", null);
        browser.addCommand(backCmd);
        browser.setCommandListener(this);
        display.setCurrent(browser);
    }

    private boolean isImage(String n) {
        if (vhd) return n.endsWith(".vhd");
        if (initrd) return n.endsWith(".img") || n.endsWith(".gz") || n.endsWith(".cpio") || n.endsWith(".cgz") || n.endsWith(".initrd")
                || n.startsWith("initr") || n.indexOf("cpio") >= 0;
        return n.endsWith(".iso") || n.endsWith(".img") || n.endsWith(".bin");
    }

    private boolean hasImage(Vector list) {
        for (int i = 0; i < list.size(); i++) {
            FileItem it = (FileItem) list.elementAt(i);
            String n = it.name.toLowerCase();
            if (!it.dir && isImage(n)) return true;
        }
        return false;
    }

    private void browserSelect() {
        int i = browser.getSelectedIndex();
        if (i < 0 || i >= entries.size()) return;
        final FileItem it = (FileItem) entries.elementAt(i);
        if (it.dir) {
            stack.addElement(new Object[] { entries, browserTitle });
            try {
                showBrowser(srcFs.list(it), it.name);
            } catch (Throwable t) {
                note("Carpeta", msg(t), browser);
            }
            return;
        }
        imgItem = it;
        image = new FsImage(srcFs, it);
        askConfirm();
    }

    private void browserUp() {
        if (stack.size() == 0) {
            if (srcDisc != null) srcDisc.close();
            srcDisc = null;
            display.setCurrent(mode == 4 ? (Displayable) ftpForm : (devList != null ? (Displayable) devList : (Displayable) menu));
            return;
        }
        Object[] s = (Object[]) stack.elementAt(stack.size() - 1);
        stack.removeElementAt(stack.size() - 1);
        showBrowser((Vector) s[0], (String) s[1]);
    }

    // ------------------------------------------------------------ 2. confirmar

    /** Recoge solo los primeros bytes de la imagen. */
    private static class Head extends OutputStream {
        byte[] b = new byte[512];
        int n;

        public void write(int v) throws IOException {
            write(new byte[] { (byte) v }, 0, 1);
        }

        public void write(byte[] d, int off, int len) throws IOException {
            int k = Math.min(len, b.length - n);
            System.arraycopy(d, off, b, n, k);
            n += k;
            if (n >= b.length) throw new IOException("STOP");
        }
    }

    private static class CancelOnly implements Progress {
        ImageUi ui;

        CancelOnly(ImageUi ui) {
            this.ui = ui;
        }

        public boolean cancelled() { return ui.cancel; }

        public void file(String n) {
        }

        public void add(long n) {
        }
    }

    private Sectors sectorsFor() throws Exception {
        if (mode == 3) return srcDisc;
        if (srcFs instanceof FtpFs) return new FtpSectors((FtpFs) srcFs, imgItem);
        if (srcFs instanceof BlockFs) return new BlockSectors((BlockFs) srcFs, imgItem);
        if (imgItem.ref instanceof File) return new FileSectors((File) imgItem.ref);
        throw new Exception("No sé leer esta ISO desde ese origen.");
    }

    private void askConfirm() {
        final Form busy = new Form("Comprobando");
        busy.append("Abriendo el USB de destino y leyendo la imagen...");
        busy.addCommand(backCmd);
        busy.setCommandListener(this);
        working = busy;
        display.setCurrent(busy);
        new Thread(new Runnable() {
            public void run() {
                if (browse) {
                    try {
                        VhdDisc vd = new VhdDisc(sectorsFor());
                        FileSource fs = UsbVolume.mount(vd);
                        media.openFileSource(fs, browser);
                    } catch (Throwable t) {
                        note("Examinar VHD", "No puedo leer este VHD: " + msg(t), browser);
                    }
                    return;
                }
                try {
                    if (tgt != null) tgt.close();
                    tgt = x.openDisc(target, false);
                    long cap = (long) tgt.blocks * tgt.blockSize;
                    if (initrd) {
                        ext = new ExtWriter(image, tgt);
                        ext.scan(new CancelOnly(ImageUi.this));
                        ext.layout();
                        showConfirmExt(cap);
                        return;
                    }
                    if (contents || win) {
                        DiscTree iso;
                        try {
                            if (vhd) {
                                VhdDisc vd = new VhdDisc(sectorsFor());
                                vhdStyle = vd.style();
                                vhdFs = UsbVolume.mount(vd);
                                iso = new FsTree(vhdFs);
                            } else {
                                iso = DiscTrees.open(sectorsFor());
                            }
                        } catch (Throwable t) {
                            throw new Exception(vhd ? "No puedo leer este VHD: " + msg(t)
                                    : "No reconozco esto como una ISO de datos (ISO9660/UDF): " + msg(t));
                        }
                        if (win) {
                            byte[] bcd = WinWriter.loadBcd();
                            if (bcd == null) throw new Exception("Falta el archivo BCD dentro de la aplicación (bcd.bin).");
                            ww = new WinWriter(iso, tgt, bcd);
                            ww.scan(new CancelOnly(ImageUi.this));
                            ww.layout();
                            showConfirmWin(cap);
                            return;
                        }
                        fw = new FatWriter(iso, tgt);
                        if (vhd && vhdStyle.equals("GPT")) fw.setGptDisk(true);
                        fw.scan(new CancelOnly(ImageUi.this));
                        fw.layout();
                        showConfirmContents(cap);
                        return;
                    }
                    if (vhd) {
                        try {
                            image = new VhdImage(new VhdDisc(sectorsFor()), image.name());
                        } catch (Throwable t) {
                            throw new Exception("No puedo leer este VHD: " + msg(t));
                        }
                    }
                    long need = image.size();
                    Head h = new Head();
                    try {
                        image.pump(h, new CancelOnly(ImageUi.this));
                    } catch (IOException e) {
                        if (h.n < 512) throw e;
                    }
                    boolean hybrid = h.n >= 512 && (h.b[510] & 0xFF) == 0x55 && (h.b[511] & 0xFF) == 0xAA;
                    showConfirm(cap, need, hybrid);
                } catch (Throwable t) {
                    if (tgt != null) tgt.close();
                    tgt = null;
                    note("Grabar imagen", msg(t), menu);
                }
            }
        }).start();
    }

    private static String fatLabelOf(String s) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length() && sb.length() < 11; i++) {
            char c = Character.toUpperCase(s.charAt(i));
            if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == ' ') sb.append(c);
        }
        String r = sb.toString().trim();
        return r.length() == 0 ? "WINBOOT" : r;
    }

    private void showConfirmWin(long cap) {
        confirm = new Form("Confirmar instalador Windows");
        StringBuffer sb = new StringBuffer();
        sb.append("DESTINO (SE BORRARÁ TODO; se creará un disco GPT con 2 particiones):\n");
        sb.append(target.label()).append("\n");
        sb.append(tgt.vendor).append(' ').append(tgt.product).append("\n");
        sb.append("Capacidad: ").append(size(cap)).append(tgt.removable ? "" : "  (¡no se declara extraíble: ¿es un disco duro?!)").append("\n\n");
        sb.append("ORIGEN: ").append(image.name()).append("\n\n");
        sb.append("1) FAT32 normal (").append(size(ww.fatBytes)).append("): carpetas EFI y boot, ").append(ww.fatFiles())
                .append(" archivos, con tu BCD de dos particiones.\n");
        sb.append("2) exFAT (el resto, ").append(size(ww.ntfsCapacity())).append("): ").append(ww.ntfsFiles())
                .append(" archivos, ").append(size(ww.ntfsBytesUsed())).append(" (la ISO COMPLETA: boot, efi, sources, install.wim...).\n\n");
        if (!ww.hasBootWim) {
            sb.append("AVISO: no veo sources\\boot.wim; no parece una ISO de instalación de Windows.\n\n");
        }
        if (!ww.hasEfi) {
            sb.append("AVISO: no veo EFI\\BOOT\\BOOT*.EFI; puede que no arranque.\n\n");
        }
        if (ww.skipped().size() > 0) {
            Vector sk = ww.skipped();
            sb.append("NO SE COPIARÁN ").append(sk.size()).append(" elemento(s):\n");
            for (int i = 0; i < sk.size() && i < 6; i++) sb.append("- ").append((String) sk.elementAt(i)).append("\n");
            sb.append("\n");
        }
        sb.append("Arranca solo en PC con UEFI. Tarda bastante (una ISO de Windows son varios GB); no desconectes el USB "
                + "ni cierres la app. No conectes a la vez dos pendrives hechos así en el mismo PC.");
        confirm.append(new StringItem(null, sb.toString()));
        fatName = new TextField("Nombre FAT32 (máx. 11)", ww.fatLabel, 11, TextField.ANY);
        ntfsName = new TextField("Nombre exFAT", ww.ntfsLabel, 32, TextField.ANY);
        confirm.append(fatName);
        confirm.append(ntfsName);
        sure = new TextField("Escribe BORRAR para confirmar", "", 10, TextField.ANY);
        confirm.append(sure);
        confirm.addCommand(writeVerCmd);
        confirm.addCommand(writeCmd);
        confirm.addCommand(backCmd);
        confirm.setCommandListener(this);
        display.setCurrent(confirm);
    }

    private void showConfirmExt(long cap) {
        confirm = new Form("Confirmar initrd en ext2");
        StringBuffer sb = new StringBuffer();
        sb.append("DESTINO (SE BORRARÁ TODO; se creará un disco GPT con una partición ext2):\n");
        sb.append(target.label()).append("\n");
        sb.append(tgt.vendor).append(' ').append(tgt.product).append("\n");
        sb.append("Capacidad: ").append(size(cap)).append(tgt.removable ? "" : "  (¡no se declara extraíble: ¿es un disco duro?!)").append("\n\n");
        sb.append("ORIGEN: ").append(image.name()).append("\n");
        sb.append(ext.fileCount).append(" archivos, ").append(ext.dirCount - 1).append(" carpetas, ").append(ext.linkCount)
                .append(" enlaces simbólicos, ").append(ext.specialCount).append(" dispositivos/especiales, ")
                .append(size(ext.fileBytes)).append("\n");
        sb.append("Partición ext2: ").append(size(ext.capacity())).append(", ").append(ext.inodeCount()).append(" inodos.\n\n");
        if (ext.skipped.size() > 0) {
            sb.append("NO SE COPIARÁN ").append(ext.skipped.size()).append(" elemento(s):\n");
            for (int i = 0; i < ext.skipped.size() && i < 6; i++) sb.append("- ").append((String) ext.skipped.elementAt(i)).append("\n");
            sb.append("\n");
        }
        sb.append("Se conservan permisos, propietarios, fechas, enlaces simbólicos y duros y nodos de dispositivo. "
                + "Solo se crea el sistema de archivos: no se instala gestor de arranque.\n\n"
                + "Al acabar, desconecta y vuelve a conectar el USB.");
        confirm.append(new StringItem(null, sb.toString()));
        extName = new TextField("Nombre del volumen (máx. 16)", ext.label, 16, TextField.ANY);
        confirm.append(extName);
        sure = new TextField("Escribe BORRAR para confirmar", "", 10, TextField.ANY);
        confirm.append(sure);
        confirm.addCommand(writeVerCmd);
        confirm.addCommand(writeCmd);
        confirm.addCommand(backCmd);
        confirm.setCommandListener(this);
        display.setCurrent(confirm);
    }

    private void showConfirmContents(long cap) {
        confirm = new Form("Confirmar grabación");
        StringBuffer sb = new StringBuffer();
        sb.append("DESTINO (SE BORRARÁ TODO y se FORMATEARÁ en FAT32):\n");
        sb.append(target.label()).append("\n");
        sb.append(tgt.vendor).append(' ').append(tgt.product).append("\n");
        sb.append("Capacidad: ").append(size(cap)).append(tgt.removable ? "" : "  (¡no se declara extraíble: ¿es un disco duro?!)").append("\n\n");
        sb.append("ORIGEN: ").append(image.name()).append("\n");
        sb.append(fw.fileCount()).append(" archivos en ").append(fw.dirCount() - 1).append(" carpetas, ")
                .append(size(fw.fileBytes)).append("\n");
        if (fw.label.length() > 0) sb.append("Nombre del volumen: ").append(fw.label).append("\n");
        sb.append("\n");
        if (fw.skipped.size() > 0) {
            sb.append("NO SE COPIARÁN ").append(fw.skipped.size()).append(" elemento(s):\n");
            for (int i = 0; i < fw.skipped.size() && i < 8; i++) sb.append("- ").append((String) fw.skipped.elementAt(i)).append("\n");
            if (fw.skipped.size() > 8) sb.append("- ...\n");
            sb.append("\n");
        }
        if (vhd) {
            sb.append("Se copian todos los archivos y carpetas del VHD tal cual.\n");
            if (vhdStyle.equals("GPT")) sb.append("El VHD usa tabla GPT: el USB se creará con tabla GPT (una partición FAT32).\n");
            else if (vhdStyle.equals("MBR")) sb.append("El VHD usa tabla MBR: el USB se creará con tabla MBR (una partición FAT32).\n");
            else sb.append("El VHD no tiene tabla de particiones: el USB se creará con MBR (lo más compatible).\n");
        } else if (fw.hasEfi) {
            sb.append("Tiene /EFI/BOOT: debería arrancar en PC con UEFI (desactiva Secure Boot si no arranca).\n");
        } else {
            sb.append("Aviso: no veo /EFI/BOOT/BOOT*.EFI. Este USB servirá para llevar los archivos, pero lo más probable es que NO arranque. "
                    + "Solo arranca en modo UEFI (no en BIOS antigua).\n");
        }
        sb.append("\nTarda varios minutos; no desconectes el USB ni cierres la app. Al acabar, desconecta y vuelve a conectar el USB.");
        confirm.append(new StringItem(null, sb.toString()));
        sure = new TextField("Escribe BORRAR para confirmar", "", 10, TextField.ANY);
        confirm.append(sure);
        confirm.addCommand(writeVerCmd);
        confirm.addCommand(writeCmd);
        if (vhd) confirm.addCommand(browseCmd);
        confirm.addCommand(backCmd);
        confirm.setCommandListener(this);
        display.setCurrent(confirm);
    }

    private void showConfirm(long cap, long need, boolean hybrid) {
        confirm = new Form("Confirmar grabación");
        StringBuffer sb = new StringBuffer();
        sb.append("DESTINO (SE BORRARÁ TODO):\n");
        sb.append(target.label()).append("\n");
        sb.append(tgt.vendor).append(' ').append(tgt.product).append("\n");
        sb.append("Capacidad: ").append(size(cap)).append(tgt.removable ? "" : "  (¡no se declara extraíble: ¿es un disco duro?!)").append("\n\n");
        sb.append(vhd ? "VHD (se clona el disco virtual entero, sector a sector):\n" : "IMAGEN:\n").append(image.name()).append("\n").append(size(need)).append("\n\n");
        boolean ok = true;
        if (need <= 0) {
            sb.append("La imagen está vacía.\n");
            ok = false;
        } else if (need > cap) {
            sb.append("La imagen NO CABE en el USB.\n");
            ok = false;
        }
        if (ok && !hybrid) {
            sb.append("Aviso: la imagen no parece híbrida (no empieza con MBR). Con grabación tipo dd puede NO arrancar "
                    + "desde el USB (por ejemplo las ISO de Windows).\n\n");
        }
        sb.append("Tarda varios minutos; no desconectes el USB ni cierres la app. Al acabar, desconecta y vuelve a conectar el USB.");
        confirm.append(new StringItem(null, sb.toString()));
        if (ok) {
            sure = new TextField("Escribe BORRAR para confirmar", "", 10, TextField.ANY);
            confirm.append(sure);
            confirm.addCommand(writeVerCmd);
            confirm.addCommand(writeCmd);
        }
        confirm.addCommand(backCmd);
        confirm.setCommandListener(this);
        display.setCurrent(confirm);
    }

    // ------------------------------------------------------------ 3. grabar

    private long done, total;
    private String phase = "";
    private long last, startMs;

    private long lastLight;

    private class Prog implements Progress {
        public boolean cancelled() { return cancel; }

        public void file(String n) {
        }

        public void add(long n) {
            done += n;
            long now = System.currentTimeMillis();
            if (now - lastLight > 3000) {
                lastLight = now;
                try { display.flashBacklight(8000); } catch (Throwable t) { }   // mantiene la pantalla encendida
            }
            if (now - last > 500) {
                last = now;
                long secs = (now - startMs) / 1000 + 1;
                long pct = total > 0 ? done * 100 / total : 0;
                status.setText(phase + "\n" + pct + " %  (" + size(done) + " de " + size(total) + ")\n"
                        + size(done / secs) + "/s\n\n(Atrás = cancelar)");
                OpStatus.progress(phase + " " + size(done) + " de " + size(total) + "  \u00B7  " + size(done / secs) + "/s", done, total);
            }
        }
    }

    private void startWrite(final boolean verify) {
        if (sure == null || !sure.getString().trim().equalsIgnoreCase("BORRAR")) {
            note("Confirmación", "Para grabar tienes que escribir BORRAR (en mayúsculas o minúsculas) en el campo.", confirm);
            return;
        }
        cancel = false;
        running = true;
        done = 0;
        if (win) {
            ww.fatLabel = fatLabelOf(fatName.getString());
            String nn = ntfsName.getString().trim();
            ww.ntfsLabel = nn.length() == 0 ? "WINSETUP" : nn;
        }
        if (initrd) {
            String en = extName.getString().trim();
            ext.label = en.length() == 0 ? "INITRD" : en;
        }
        total = initrd ? ext.dataBytes() + (verify ? ext.fileBytes : 0)
                : win ? ww.dataBytes() + (verify ? ww.fileBytes() : 0)
                : contents ? fw.dataBytes() + (verify ? fw.fileBytes : 0) : image.size() * (verify ? 2 : 1);
        startMs = System.currentTimeMillis();
        last = 0;
        phase = "Grabando...";
        OpStatus.begin(initrd ? "Grabando initrd en USB (ext2)" : win ? "Grabando instalador de Windows en USB"
                : contents ? "Formateando USB y copiando contenido" : "Grabando imagen en USB");
        working = new Form("Grabando imagen");
        status = new StringItem(null, "Empezando...");
        working.append(status);
        working.addCommand(backCmd);
        working.setCommandListener(this);
        display.setCurrent(working);
        try { display.flashBacklight(8000); } catch (Throwable t) { }
        final Form mine = working;
        new Thread(new Runnable() {
            public void run() {
                String m;
                boolean good = false;
                try {
                    Prog p = new Prog();
                    if (initrd) {
                        phase = "Creando ext2 y copiando...";
                        ext.write(p);
                        if (verify) {
                            phase = "Verificando...";
                            ext.verify(p);
                        }
                        m = "Listo: USB con ext2 (GPT) con " + ext.fileCount + " archivos, " + ext.linkCount + " enlaces simbólicos y "
                                + (ext.dirCount - 1) + " carpetas (" + size(ext.fileBytes) + ")" + (verify ? ", VERIFICADO." : ", sin verificar.");
                        m += "\n\nDesconecta el USB y vuelve a conectarlo.";
                        running = false;
                        closeAll();
                        finish(m, true);
                        return;
                    }
                    if (win) {
                        phase = "Creando particiones y copiando...";
                        ww.write(p);
                        if (verify) {
                            phase = "Verificando...";
                            ww.verify(p);
                        }
                        m = "Listo: USB de instalación de Windows (GPT: FAT32 + exFAT) con " + ww.fileCount() + " archivos, "
                                + size(ww.fileBytes()) + (verify ? " y VERIFICADO." : ", sin verificar.");
                        if (ww.skipped().size() > 0) {
                            m += "\n\nNo copiados (" + ww.skipped().size() + ").";
                        }
                        m += "\n\nDesconecta el USB y vuelve a conectarlo. Para instalar, arranca el PC en modo UEFI y elige el USB en el menú de arranque.";
                        running = false;
                        closeAll();
                        finish(m, true);
                        return;
                    }
                    if (contents) {
                        phase = "Formateando y copiando...";
                        fw.write(p);
                        if (verify) {
                            phase = "Verificando...";
                            fw.verify(p);
                        }
                        m = "Listo: USB formateado en FAT32 con el contenido " + (vhd ? "del VHD" : "de la ISO") + " (" + fw.fileCount() + " archivos, "
                                + size(fw.fileBytes) + ")" + (verify ? " y VERIFICADO." : ", sin verificar.");
                        if (fw.skipped.size() > 0) {
                            m += "\n\nNo copiados (" + fw.skipped.size() + "):";
                            for (int i = 0; i < fw.skipped.size() && i < 10; i++) m += "\n- " + (String) fw.skipped.elementAt(i);
                        }
                        m += "\n\nDesconecta el USB y vuelve a conectarlo.";
                        good = true;
                        running = false;
                        closeAll();
                        finish(m, good);
                        return;
                    }
                    ImageWriter w = new ImageWriter(tgt, p);
                    image.pump(w, new CancelOnly(ImageUi.this));
                    w.finish();
                    if (w.written != image.size()) {
                        throw new Exception("La imagen se leyó incompleta (" + w.written + " de " + image.size() + " bytes)");
                    }
                    if (verify) {
                        phase = "Verificando...";
                        image.pump(new ImageVerifier(tgt, p), new CancelOnly(ImageUi.this));
                        m = "Imagen grabada y VERIFICADA correctamente (" + size(image.size()) + ").";
                    } else {
                        m = "Imagen grabada (" + size(image.size()) + "), sin verificar.";
                    }
                    m += "\n\nDesconecta el USB y vuelve a conectarlo. Para arrancar un PC con él, elige el USB en el menú de arranque (BIOS/UEFI).";
                    good = true;
                } catch (Throwable t) {
                    m = cancel ? "Grabación CANCELADA. El USB ha quedado a medias: hay que volver a grabarlo."
                            : "ERROR: " + msg(t) + "\n\nEl USB puede haber quedado a medias; vuelve a grabarlo.";
                }
                running = false;
                closeAll();
                finish(m, good);
            }
        }).start();
    }

    private void finish(String m, boolean good) {
        String first = m;
        int nl = first.indexOf('\n');
        if (nl > 0) first = first.substring(0, nl);
        if (first.length() > 110) first = first.substring(0, 110) + "...";
        OpStatus.end(good ? OpStatus.OK : (cancel ? OpStatus.CANCEL : OpStatus.FAIL), first);
        result = new Form(good ? "Grabación terminada" : "Grabación fallida");
        result.append(new StringItem(null, m));
        result.addCommand(okCmd);
        result.setCommandListener(this);
        display.setCurrent(result);
    }

    // ------------------------------------------------------------ eventos

    public void commandAction(Command c, Displayable d) {
        if (d == noteForm) {
            display.setCurrent(noteNext != null ? noteNext : ret);
        } else if (d == menu) {
            if (c == backCmd) {
                closeAll();
                display.setCurrent(ret);
            } else {
                int i = menu.getSelectedIndex();
                if ((vhd || initrd) && i == 2) i = 3;
                if (i == 0) showRoots();
                else if (i == 1) showDeviceChoice(false);
                else if (i == 2) showDeviceChoice(true);
                else showFtpForm();
            }
        } else if (d == roots) {
            if (c == backCmd) {
                display.setCurrent(menu);
            } else {
                int i = roots.getSelectedIndex();
                String p = i >= 0 && i < rootPaths.size() ? (String) rootPaths.elementAt(i) : "";
                if (p.length() == 0) {
                    showPathForm();
                } else {
                    srcFs = new LocalVolume(new File(p), "teléfono");
                    stack.removeAllElements();
                    try {
                        Vector lst = srcFs.listRoot();
                        showBrowser(lst, p);
                        if (!hasImage(lst)) {
                            note("No veo ninguna ISO", "Aquí no aparece ninguna imagen .iso/.img.\n\nAndroid oculta a J2ME Loader "
                                    + "los archivos que no ha creado él (aunque estén en Descargas); solo deja ver las carpetas.\n\n"
                                    + "Soluciones:\n- Copia la ISO a otro pendrive (FAT32 o exFAT), conéctalo a la vez y usa "
                                    + "\"Imagen desde otro USB\".\n- O clona un CD/DVD.\n- O pon la ISO en la carpeta de J2ME Loader "
                                    + "(opción de esta lista) conectando el teléfono a un PC.", browser);
                        }
                    } catch (Throwable t) {
                        note("Carpeta", msg(t), roots);
                    }
                }
            }
        } else if (d == pathForm) {
            if (c == backCmd) display.setCurrent(roots);
            else useLocalPath(pathField.getString().trim());
        } else if (d == ftpForm) {
            if (c == backCmd) display.setCurrent(menu);
            else connectFtp();
        } else if (d == devList) {
            if (c == backCmd) {
                display.setCurrent(menu);
            } else {
                int i = devList.getSelectedIndex();
                if (i >= 0 && i < devChoices.size()) openSource((UsbDevInfo) devChoices.elementAt(i));
            }
        } else if (d == browser) {
            if (c == backCmd) browserUp();
            else browserSelect();
        } else if (d == confirm) {
            if (c == backCmd) {
                if (tgt != null) tgt.close();
                tgt = null;
                display.setCurrent(menu);
            } else if (c == browseCmd) {
                try {
                    media.openFileSource(vhdFs, confirm);
                } catch (Throwable t) {
                    note("Examinar VHD", msg(t), confirm);
                }
            } else {
                startWrite(c == writeVerCmd);
            }
        } else if (d == working) {
            if (c == backCmd) {
                if (running) {
                    cancel = true;
                    if (status != null) status.setText("Cancelando...");
                } else {
                    display.setCurrent(menu);
                }
            }
        } else if (d == result) {
            display.setCurrent(ret);
        }
    }
}
