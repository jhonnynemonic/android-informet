package com.usb.informer;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.Vector;

/** Carpeta del teléfono o volumen USB ya montado por Android (acceso con java.io.File). */
public class LocalVolume implements FileSource {
    private File root;
    private String name;

    public LocalVolume(File root, String name) {
        this.root = root;
        this.name = name;
    }

    public String label() { return name; }

    public Vector listRoot() throws Exception { return listDir(root); }

    public Vector list(FileItem dir) throws Exception { return listDir((File) dir.ref); }

    private Vector listDir(File d) throws Exception {
        File[] fs = d.listFiles();
        if (fs == null) {
            throw new Exception("Android no me deja leer esa carpeta. Usa \"Leer USB directamente\" "
                    + "en el menú del dispositivo.");
        }
        Vector dirs = new Vector();
        Vector files = new Vector();
        for (int i = 0; i < fs.length; i++) {
            FileItem it = new FileItem();
            it.name = fs[i].getName();
            it.dir = fs[i].isDirectory();
            it.size = it.dir ? 0 : fs[i].length();
            it.ref = fs[i];
            FileItem.sortedAdd(it.dir ? dirs : files, it);
        }
        for (int i = 0; i < files.size(); i++) dirs.addElement(files.elementAt(i));
        return dirs;
    }

    public String preview(FileItem f, int max) throws Exception {
        FileInputStream in = new FileInputStream((File) f.ref);
        try {
            byte[] b = new byte[(int) Math.min(f.size, max)];
            int got = 0;
            while (got < b.length) {
                int r = in.read(b, got, b.length - got);
                if (r <= 0) break;
                got += r;
            }
            return Preview.make(b, got, f.size);
        } finally {
            in.close();
        }
    }

    public void copy(FileItem f, OutputStream out, Progress p) throws Exception {
        FileInputStream in = new FileInputStream((File) f.ref);
        try {
            byte[] b = new byte[65536];
            int r;
            while ((r = in.read(b)) > 0) {
                if (p != null && p.cancelled()) throw new Exception("Cancelado");
                out.write(b, 0, r);
                if (p != null) p.add(r);
            }
        } finally {
            in.close();
        }
    }
}
