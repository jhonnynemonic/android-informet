package com.usb.informer;
import java.util.Vector;

/** Backend simulado: reparte dispositivos de ejemplo para probar la pantalla y el explorador. */
public class SimUsb implements UsbBackend {
    private Vector attached = new Vector();
    private int next = 0;
    private UsbListener listener;

    public String getName() { return "Simulado"; }

    public String start(UsbListener l) {
        listener = l;
        return null;
    }

    public void stop() { listener = null; }

    public Vector getDevices() { return attached; }

    public UsbDevInfo attachNext() {
        UsbDevInfo d = sample(next % 3, attached.size() + 2);
        next++;
        attached.addElement(d);
        if (listener != null) listener.deviceAttached(d);
        return d;
    }

    public UsbDevInfo detachLast() {
        if (attached.size() == 0) return null;
        UsbDevInfo d = (UsbDevInfo) attached.elementAt(attached.size() - 1);
        attached.removeElementAt(attached.size() - 1);
        if (listener != null) listener.deviceDetached(d);
        return d;
    }

    private static UsbDevInfo sample(int kind, int addr) {
        UsbDevInfo d = new UsbDevInfo();
        d.deviceName = "/dev/bus/usb/001/" + UsbUtil.pad(addr, 3);
        d.id = 1000 + addr;
        UsbNode cfg;
        UsbNode itf;
        if (kind == 0) {
            d.vendorId = 0x0951; d.productId = 0x1666;
            d.version = UsbUtil.bcdVersion(0x0110);
            d.manufacturer = "Kingston"; d.productName = "DataTraveler 100 G3";
            d.serial = "0019E000A1B2C3D4";
            cfg = UsbUtil.configNode(1, 1, 0x80, 100);
            itf = cfg.add(UsbUtil.interfaceNode(0, 0, 0x08, 0x06, 0x50, 2));
            itf.add(UsbUtil.endpointNode(0x81, 0x02, 512, 0));
            itf.add(UsbUtil.endpointNode(0x02, 0x02, 512, 0));
        } else if (kind == 1) {
            d.vendorId = 0x046D; d.productId = 0xC31C;
            d.version = UsbUtil.bcdVersion(0x6400);
            d.manufacturer = "Logitech"; d.productName = "USB Keyboard";
            cfg = UsbUtil.configNode(1, 1, 0xA0, 50);
            itf = cfg.add(UsbUtil.interfaceNode(0, 0, 0x03, 0x01, 0x01, 1));
            itf.add(UsbUtil.endpointNode(0x81, 0x03, 8, 10));
        } else {
            d.vendorId = 0x093A; d.productId = 0x2510;
            d.version = UsbUtil.bcdVersion(0x0100);
            d.manufacturer = "PixArt"; d.productName = "USB Optical Mouse";
            cfg = UsbUtil.configNode(1, 1, 0xA0, 50);
            itf = cfg.add(UsbUtil.interfaceNode(0, 0, 0x03, 0x01, 0x02, 1));
            itf.add(UsbUtil.endpointNode(0x81, 0x03, 4, 10));
        }
        d.configs.addElement(cfg);
        return d;
    }
}
