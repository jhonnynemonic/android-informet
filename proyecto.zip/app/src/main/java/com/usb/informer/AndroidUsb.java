package com.usb.informer;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

/**
 * Backend con el USB real del teléfono: usa el UsbManager de Android por reflexión
 * (funciona porque J2ME Loader corre dentro de Android). Detecta conexión y
 * desconexión sondeando la lista de dispositivos.
 */
public class AndroidUsb implements UsbBackend, UsbExtras {
    private static final String MGR = "android.hardware.usb.UsbManager";
    private static final String DEV = "android.hardware.usb.UsbDevice";
    private static final String CFG = "android.hardware.usb.UsbConfiguration";
    private static final String ITF = "android.hardware.usb.UsbInterface";
    private static final String EP = "android.hardware.usb.UsbEndpoint";
    private static final String CTX = "android.content.Context";
    private static final String INTENT = "android.content.Intent";
    private static final String PI = "android.app.PendingIntent";
    private static final String ACTION = "com.usb.informer.USB_PERMISSION";

    private Object ctx;
    private Object mgr;
    private UsbListener listener;
    private boolean running;
    private int gen;
    private Hashtable known = new Hashtable();
    private Hashtable asked = new Hashtable();
    private Vector volumeIds = new Vector();
    private Vector volumePaths = new Vector();

    public String getName() { return "Android USB (real)"; }

    public String start(UsbListener l) {
        try {
            ctx = AndroidBridge.context();
            if (ctx == null) return "no hay contexto de Android (¿no es J2ME Loader?)";
            mgr = AndroidBridge.call(ctx, CTX, "getSystemService", new Class[] { String.class }, new Object[] { "usb" });
            if (mgr == null) return "este teléfono no tiene UsbManager";
            listener = l;
            known.clear();
            asked.clear();
            Vector now = scan();
            for (int i = 0; i < now.size(); i++) {
                UsbDevInfo d = (UsbDevInfo) now.elementAt(i);
                known.put(d.deviceName, d);
            }
            running = true;
            gen++;
            new Thread(new Poller(gen)).start();
            return null;
        } catch (Throwable t) {
            return t.toString();
        }
    }

    public void stop() {
        running = false;
        listener = null;
    }

    public Vector getDevices() {
        try {
            return scan();
        } catch (Throwable t) {
            return new Vector();
        }
    }

    // ---------- sondeo de conexión / desconexión ----------

    private class Poller implements Runnable {
        private int myGen;

        Poller(int g) { myGen = g; }

        public void run() {
            while (running && myGen == gen) {
                try {
                    poll();
                } catch (Throwable t) {
                    // seguimos intentando
                }
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }

    private void poll() throws Exception {
        Vector now = scan();
        Hashtable seen = new Hashtable();
        for (int i = 0; i < now.size(); i++) {
            UsbDevInfo d = (UsbDevInfo) now.elementAt(i);
            seen.put(d.deviceName, d);
            UsbDevInfo old = (UsbDevInfo) known.get(d.deviceName);
            if (old == null || old.needsPermission != d.needsPermission) {
                known.put(d.deviceName, d);
                UsbListener l = listener;
                if (l != null) l.deviceAttached(d);
            }
            if (d.needsPermission && asked.get(d.deviceName) == null) {
                asked.put(d.deviceName, "1");
                try {
                    requestPermission(d.raw);
                } catch (Throwable t) {
                    // el usuario puede usar el menú para reintentar
                }
            }
        }
        Vector gone = new Vector();
        for (Enumeration e = known.keys(); e.hasMoreElements();) {
            Object k = e.nextElement();
            if (seen.get(k) == null) gone.addElement(k);
        }
        for (int i = 0; i < gone.size(); i++) {
            Object k = gone.elementAt(i);
            UsbDevInfo old = (UsbDevInfo) known.get(k);
            known.remove(k);
            asked.remove(k);
            OpticalDisc.dropHeld(); // el dispositivo se ha desenchufado: se libera la conexion que se mantenia
            UsbListener l = listener;
            if (l != null && old != null) l.deviceDetached(old);
        }
    }

    // ---------- lectura de dispositivos ----------

    private Vector scan() throws Exception {
        Object map = AndroidBridge.call0(mgr, MGR, "getDeviceList");
        Vector out = new Vector();
        for (Iterator it = ((Map) map).values().iterator(); it.hasNext();) {
            out.addElement(describe(it.next()));
        }
        return out;
    }

    private String tryStr(Object dev, String method) {
        try {
            return AndroidBridge.str(AndroidBridge.call0(dev, DEV, method));
        } catch (Throwable t) {
            return null;
        }
    }

    private UsbDevInfo describe(Object dev) throws Exception {
        UsbDevInfo i = new UsbDevInfo();
        i.raw = dev;
        i.deviceName = AndroidBridge.str(AndroidBridge.call0(dev, DEV, "getDeviceName"));
        i.vendorId = AndroidBridge.num(AndroidBridge.call0(dev, DEV, "getVendorId"));
        i.productId = AndroidBridge.num(AndroidBridge.call0(dev, DEV, "getProductId"));
        i.devClass = AndroidBridge.num(AndroidBridge.call0(dev, DEV, "getDeviceClass"));
        i.subClass = AndroidBridge.num(AndroidBridge.call0(dev, DEV, "getDeviceSubclass"));
        i.protocol = AndroidBridge.num(AndroidBridge.call0(dev, DEV, "getDeviceProtocol"));
        i.id = AndroidBridge.num(AndroidBridge.call0(dev, DEV, "getDeviceId"));
        String v = tryStr(dev, "getVersion");
        i.version = (v == null) ? "?" : v;

        boolean perm = false;
        try {
            perm = AndroidBridge.bool(AndroidBridge.call(mgr, MGR, "hasPermission",
                    new Class[] { Class.forName(DEV) }, new Object[] { dev }));
        } catch (Throwable t) {
            // sin dato de permiso
        }
        i.needsPermission = !perm;
        i.manufacturer = tryStr(dev, "getManufacturerName");
        i.productName = tryStr(dev, "getProductName");
        i.serial = tryStr(dev, "getSerialNumber");
        if (!perm) i.extra = "Permiso USB: pendiente (acéptalo en el aviso de Android o usa Pedir permiso USB)";

        i.optical = looksOptical(dev, i);
        i.mass = massFlag;
        try {
            int n = AndroidBridge.num(AndroidBridge.call0(dev, DEV, "getConfigurationCount"));
            for (int k = 0; k < n; k++) {
                Object cfg = AndroidBridge.call(dev, DEV, "getConfiguration",
                        new Class[] { Integer.TYPE }, new Object[] { AndroidBridge.i(k) });
                i.configs.addElement(describeConfig(cfg));
            }
        } catch (Throwable t) {
            // sin configuraciones legibles
        }
        return i;
    }

    private boolean massFlag;

    private boolean looksOptical(Object dev, UsbDevInfo i) {
        boolean mass = false;
        massFlag = false;
        try {
            int n = AndroidBridge.num(AndroidBridge.call0(dev, DEV, "getInterfaceCount"));
            for (int k = 0; k < n; k++) {
                Object itf = AndroidBridge.call(dev, DEV, "getInterface",
                        new Class[] { Integer.TYPE }, new Object[] { AndroidBridge.i(k) });
                int cls = AndroidBridge.num(AndroidBridge.call0(itf, ITF, "getInterfaceClass"));
                int sub = AndroidBridge.num(AndroidBridge.call0(itf, ITF, "getInterfaceSubclass"));
                if (cls == 8) {
                    mass = true;
                    massFlag = true;
                    if (sub == 2 || sub == 5) return true;
                }
            }
        } catch (Throwable t) {
            return false;
        }
        if (!mass) return false;
        String s = ((i.productName == null ? "" : i.productName) + " " + (i.manufacturer == null ? "" : i.manufacturer)).toLowerCase();
        String[] hints = { "dvd", "cd-rom", "cdrom", "cd/", "cd-rw", "cdrw", "multi drive", "optical", "blu-ray", "burner" };
        for (int k = 0; k < hints.length; k++) {
            if (s.indexOf(hints[k]) >= 0) return true;
        }
        return false;
    }

    public OpticalDisc openDisc(UsbDevInfo d) throws Exception {
        return openDisc(d, true);
    }

    public OpticalDisc openDisc(UsbDevInfo d, boolean optical) throws Exception {
        OpticalDisc o = new OpticalDisc(mgr, d.raw);
        o.open(optical);
        return o;
    }

    private UsbNode describeConfig(Object cfg) throws Exception {
        int id = AndroidBridge.num(AndroidBridge.call0(cfg, CFG, "getId"));
        int nIf = AndroidBridge.num(AndroidBridge.call0(cfg, CFG, "getInterfaceCount"));
        int attrs = 0x80;
        if (AndroidBridge.bool(AndroidBridge.call0(cfg, CFG, "isSelfPowered"))) attrs |= 0x40;
        if (AndroidBridge.bool(AndroidBridge.call0(cfg, CFG, "isRemoteWakeup"))) attrs |= 0x20;
        int mA = AndroidBridge.num(AndroidBridge.call0(cfg, CFG, "getMaxPower"));
        UsbNode cn = UsbUtil.configNode(id, nIf, attrs, mA / 2);
        for (int a = 0; a < nIf; a++) {
            Object itf = AndroidBridge.call(cfg, CFG, "getInterface",
                    new Class[] { Integer.TYPE }, new Object[] { AndroidBridge.i(a) });
            int nEp = AndroidBridge.num(AndroidBridge.call0(itf, ITF, "getEndpointCount"));
            UsbNode in = UsbUtil.interfaceNode(
                    AndroidBridge.num(AndroidBridge.call0(itf, ITF, "getId")),
                    AndroidBridge.num(AndroidBridge.call0(itf, ITF, "getAlternateSetting")),
                    AndroidBridge.num(AndroidBridge.call0(itf, ITF, "getInterfaceClass")),
                    AndroidBridge.num(AndroidBridge.call0(itf, ITF, "getInterfaceSubclass")),
                    AndroidBridge.num(AndroidBridge.call0(itf, ITF, "getInterfaceProtocol")),
                    nEp);
            for (int e = 0; e < nEp; e++) {
                Object ep = AndroidBridge.call(itf, ITF, "getEndpoint",
                        new Class[] { Integer.TYPE }, new Object[] { AndroidBridge.i(e) });
                in.add(UsbUtil.endpointNode(
                        AndroidBridge.num(AndroidBridge.call0(ep, EP, "getAddress")),
                        AndroidBridge.num(AndroidBridge.call0(ep, EP, "getAttributes")),
                        AndroidBridge.num(AndroidBridge.call0(ep, EP, "getMaxPacketSize")),
                        AndroidBridge.num(AndroidBridge.call0(ep, EP, "getInterval"))));
            }
            cn.add(in);
        }
        return cn;
    }

    // ---------- permisos ----------

    private void requestPermission(Object dev) throws Exception {
        Object intent = Class.forName(INTENT).getConstructor(new Class[] { String.class })
                .newInstance(new Object[] { ACTION });
        String pkg = AndroidBridge.str(AndroidBridge.call0(ctx, CTX, "getPackageName"));
        AndroidBridge.call(intent, INTENT, "setPackage", new Class[] { String.class }, new Object[] { pkg });
        Object pi = makePending(intent);
        AndroidBridge.call(mgr, MGR, "requestPermission",
                new Class[] { Class.forName(DEV), Class.forName(PI) }, new Object[] { dev, pi });
    }

    private Object makePending(Object intent) throws Exception {
        int update = 0x08000000;
        int[] flags = { update | 0x02000000, update | 0x04000000, update };
        Exception last = null;
        for (int k = 0; k < flags.length; k++) {
            try {
                return AndroidBridge.callStatic(PI, "getBroadcast",
                        new Class[] { Class.forName(CTX), Integer.TYPE, Class.forName(INTENT), Integer.TYPE },
                        new Object[] { ctx, AndroidBridge.i(0), intent, AndroidBridge.i(flags[k]) });
            } catch (Exception e) {
                last = e;
            }
        }
        throw last;
    }

    public String requestPermissions() {
        try {
            Vector now = scan();
            if (now.size() == 0) return "No hay dispositivos USB conectados";
            int asking = 0;
            for (int i = 0; i < now.size(); i++) {
                UsbDevInfo d = (UsbDevInfo) now.elementAt(i);
                if (d.needsPermission) {
                    requestPermission(d.raw);
                    asking++;
                }
            }
            if (asking == 0) return "Todos los dispositivos ya tienen permiso";
            return "Acepta el aviso de Android para ver todos los datos";
        } catch (Throwable t) {
            return "No se pudo pedir el permiso: " + t;
        }
    }

    // ---------- contenido del USB (explorador del sistema) ----------

    public Vector storageNames() {
        Vector names = new Vector();
        volumeIds.removeAllElements();
        volumePaths.removeAllElements();
        try {
            String SM = "android.os.storage.StorageManager";
            String SV = "android.os.storage.StorageVolume";
            Object sm = AndroidBridge.call(ctx, CTX, "getSystemService", new Class[] { String.class }, new Object[] { "storage" });
            List vols = (List) AndroidBridge.call0(sm, SM, "getStorageVolumes");
            for (Iterator it = vols.iterator(); it.hasNext();) {
                Object v = it.next();
                String desc = null;
                try {
                    desc = AndroidBridge.str(AndroidBridge.call(v, SV, "getDescription",
                            new Class[] { Class.forName(CTX) }, new Object[] { ctx }));
                } catch (Throwable t) {
                    // sin descripción
                }
                if (desc == null) desc = "Volumen";
                boolean primary = AndroidBridge.bool(AndroidBridge.call0(v, SV, "isPrimary"));
                boolean removable = AndroidBridge.bool(AndroidBridge.call0(v, SV, "isRemovable"));
                String uuid = AndroidBridge.str(AndroidBridge.call0(v, SV, "getUuid"));
                String state = AndroidBridge.str(AndroidBridge.call0(v, SV, "getState"));
                String label = desc + (removable ? " [extraíble]" : "") + (uuid != null ? " (" + uuid + ")" : "")
                        + (state != null && !"mounted".equals(state) ? " - " + state : "");
                names.addElement(label);
                volumeIds.addElement(primary ? "primary" : (uuid != null ? uuid : ""));
                String vpath = null;
                try {
                    Object f = AndroidBridge.call0(v, SV, "getDirectory");
                    if (f != null) vpath = f.toString();
                } catch (Throwable t) {
                    // API antigua
                }
                if (vpath == null) vpath = primary ? "/storage/emulated/0" : (uuid != null ? "/storage/" + uuid : "");
                volumePaths.addElement(vpath);
            }
        } catch (Throwable t) {
            // devolvemos lo que haya
        }
        return names;
    }

    public String volumeKind(int index) {
        return "android";
    }

    public String playDisc(int index, boolean audio) {
        return "No disponible en Android";
    }

    public String volumePath(int index) {
        if (index < 0 || index >= volumePaths.size()) return "";
        return (String) volumePaths.elementAt(index);
    }

    public String openAllFilesAccess() {
        try {
            String pkg = AndroidBridge.str(AndroidBridge.call0(ctx, CTX, "getPackageName"));
            Object uri = AndroidBridge.callStatic("android.net.Uri", "parse", new Class[] { String.class },
                    new Object[] { "package:" + pkg });
            Object intent = Class.forName(INTENT).getConstructor(new Class[] { String.class })
                    .newInstance(new Object[] { "android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION" });
            AndroidBridge.call(intent, INTENT, "setData", new Class[] { Class.forName("android.net.Uri") }, new Object[] { uri });
            AndroidBridge.call(intent, INTENT, "addFlags", new Class[] { Integer.TYPE }, new Object[] { AndroidBridge.i(0x10000000) });
            AndroidBridge.call(ctx, CTX, "startActivity", new Class[] { Class.forName(INTENT) }, new Object[] { intent });
            return null;
        } catch (Throwable t) {
            return "No se pudo abrir los ajustes: " + t;
        }
    }

    public String openStorageSettings() {
        String[] acts = { "android.settings.INTERNAL_STORAGE_SETTINGS", "android.settings.MEMORY_CARD_SETTINGS",
                "android.settings.SETTINGS" };
        Throwable last = null;
        for (int i = 0; i < acts.length; i++) {
            try {
                Object intent = Class.forName(INTENT).getConstructor(new Class[] { String.class })
                        .newInstance(new Object[] { acts[i] });
                AndroidBridge.call(intent, INTENT, "addFlags", new Class[] { Integer.TYPE }, new Object[] { AndroidBridge.i(0x10000000) });
                AndroidBridge.call(ctx, CTX, "startActivity", new Class[] { Class.forName(INTENT) }, new Object[] { intent });
                return null;
            } catch (Throwable t) {
                last = t;
            }
        }
        return "No se pudieron abrir los ajustes: " + last;
    }

    public String openUrl(String url, String mime) {
        try {
            Object uri = AndroidBridge.callStatic("android.net.Uri", "parse", new Class[] { String.class }, new Object[] { url });
            Object intent = Class.forName(INTENT).getConstructor(new Class[] { String.class })
                    .newInstance(new Object[] { "android.intent.action.VIEW" });
            AndroidBridge.call(intent, INTENT, "setDataAndType",
                    new Class[] { Class.forName("android.net.Uri"), String.class }, new Object[] { uri, mime });
            AndroidBridge.call(intent, INTENT, "addFlags", new Class[] { Integer.TYPE }, new Object[] { AndroidBridge.i(0x10000000) });
            AndroidBridge.call(ctx, CTX, "startActivity", new Class[] { Class.forName(INTENT) }, new Object[] { intent });
            return null;
        } catch (Throwable t) {
            return t.toString();
        }
    }

    public String openStorage(int index) {
        if (index < 0 || index >= volumeIds.size()) return "Volumen no válido";
        String id = (String) volumeIds.elementAt(index);
        if (id.length() == 0) return openFileManager();
        String err = openRoot(id);
        return err == null ? null : openFileManager();
    }

    public String openFileManager() {
        String err = openRoot("primary");
        if (err == null) return null;
        try {
            Object intent = Class.forName(INTENT).getConstructor(new Class[] { String.class })
                    .newInstance(new Object[] { "android.intent.action.GET_CONTENT" });
            AndroidBridge.call(intent, INTENT, "setType", new Class[] { String.class }, new Object[] { "*/*" });
            AndroidBridge.call(intent, INTENT, "addFlags", new Class[] { Integer.TYPE }, new Object[] { AndroidBridge.i(0x10000000) });
            AndroidBridge.call(ctx, CTX, "startActivity", new Class[] { Class.forName(INTENT) }, new Object[] { intent });
            return null;
        } catch (Throwable t) {
            return "No se pudo abrir el explorador de archivos: " + t;
        }
    }

    private String openRoot(String rootId) {
        try {
            Object uri = AndroidBridge.callStatic("android.net.Uri", "parse", new Class[] { String.class },
                    new Object[] { "content://com.android.externalstorage.documents/root/" + rootId });
            Object intent = Class.forName(INTENT).getConstructor(new Class[] { String.class })
                    .newInstance(new Object[] { "android.intent.action.VIEW" });
            AndroidBridge.call(intent, INTENT, "setDataAndType",
                    new Class[] { Class.forName("android.net.Uri"), String.class },
                    new Object[] { uri, "vnd.android.document/root" });
            AndroidBridge.call(intent, INTENT, "addFlags", new Class[] { Integer.TYPE }, new Object[] { AndroidBridge.i(0x10000000) });
            AndroidBridge.call(ctx, CTX, "startActivity", new Class[] { Class.forName(INTENT) }, new Object[] { intent });
            return null;
        } catch (Throwable t) {
            return t.toString();
        }
    }
}
