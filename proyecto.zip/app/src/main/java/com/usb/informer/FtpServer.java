package com.usb.informer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Vector;

/**
 * Servidor FTP de solo lectura que publica el contenido de un volumen (FileSource) por la red local.
 * Soporta lo necesario para clientes normales (FileZilla, Explorador de Windows, WinSCP, Total Commander...):
 * USER/PASS, PWD, CWD, CDUP, TYPE, PASV/EPSV, LIST/NLST/MLSD, RETR (con REST), SIZE, MDTM, NOOP, FEAT, OPTS, QUIT.
 * Usuario vacío = acceso libre (cualquier usuario/contraseña, o "anonymous").
 */
public class FtpServer implements Runnable {
    /** Una carpeta publicada: un USB (solo lectura) o el almacenamiento del teléfono (opcionalmente con escritura). */
    public static class Mount {
        public final String name;
        public final FileSource src;
        public final File base;       // solo teléfono
        public final boolean writable;

        public Mount(String name, FileSource src, File base, boolean writable) {
            this.name = name;
            this.src = src;
            this.base = base;
            this.writable = writable;
        }
    }

    /** Archivos del teléfono (java.io.File). Necesita el permiso "Permisos de archivos" del menú principal. */
    public static class PhoneSource implements FileSource {
        private final File base;

        public PhoneSource(File base) { this.base = base; }

        public String label() { return "Teléfono"; }

        private Vector ls(File d) throws Exception {
            File[] fs = d.listFiles();
            if (fs == null) throw new Exception("no puedo leer " + d.getPath() + " (concede 'Permisos de archivos' en el menú principal)");
            Vector v = new Vector();
            for (int i = 0; i < fs.length; i++) {
                FileItem it = new FileItem();
                it.name = fs[i].getName();
                it.dir = fs[i].isDirectory();
                it.size = it.dir ? 0 : fs[i].length();
                it.ref = fs[i];
                FileItem.sortedAdd(v, it);
            }
            return v;
        }

        public Vector listRoot() throws Exception { return ls(base); }

        public Vector list(FileItem dir) throws Exception { return ls((File) dir.ref); }

        public String preview(FileItem f, int max) { return ""; }

        public void copy(FileItem f, OutputStream out, Progress p) throws Exception {
            InputStream in = new FileInputStream((File) f.ref);
            try {
                byte[] b = new byte[65536];
                int n;
                while ((n = in.read(b)) > 0) {
                    if (p.cancelled()) throw new Exception("cancelado");
                    out.write(b, 0, n);
                }
            } finally {
                in.close();
            }
        }
    }

    private final Mount[] mounts;
    private final String user, pass;
    private final int port;
    private ServerSocket ss;
    private volatile boolean stopped;

    public volatile int clients;
    public volatile int sessions;
    public volatile long sent, received;
    public volatile String last = "";
    public volatile String error = "";
    private final ArrayList<String> log = new ArrayList<String>();
    private final ArrayList<Socket> open = new ArrayList<Socket>();

    public FtpServer(Mount[] mounts, String user, String pass, int port) {
        this.mounts = mounts;
        this.user = user == null ? "" : user;
        this.pass = pass == null ? "" : pass;
        this.port = port;
    }

    public boolean needsLogin() { return user.length() > 0; }

    public int port() { return ss != null ? ss.getLocalPort() : port; }

    /** Direcciones IPv4 locales (Wi-Fi, hotspot...) para mostrar al usuario. */
    public static Vector addresses() {
        Vector v = new Vector();
        try {
            Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces();
            while (e != null && e.hasMoreElements()) {
                NetworkInterface ni = e.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> a = ni.getInetAddresses();
                while (a.hasMoreElements()) {
                    InetAddress ia = a.nextElement();
                    if (ia instanceof Inet4Address && !ia.isLoopbackAddress()) v.addElement(ia.getHostAddress());
                }
            }
        } catch (Throwable t) {
            // sin red
        }
        return v;
    }

    public void start() throws Exception {
        ss = new ServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new InetSocketAddress(port));
        Thread t = new Thread(this, "ftp-accept");
        t.setDaemon(true);
        t.start();
    }

    public void stop() {
        stopped = true;
        try { if (ss != null) ss.close(); } catch (Throwable t) { }
        synchronized (open) {
            for (int i = 0; i < open.size(); i++) try { open.get(i).close(); } catch (Throwable t) { }
            open.clear();
        }
    }

    public String status() {
        StringBuffer sb = new StringBuffer();
        sb.append("Clientes conectados: ").append(clients).append("   (sesiones: ").append(sessions).append(")\n");
        sb.append("Enviado: ").append(Phone.sizeText(sent));
        if (received > 0) sb.append("   Recibido: ").append(Phone.sizeText(received));
        sb.append("\n");
        synchronized (log) {
            int from = Math.max(0, log.size() - 6);
            for (int i = from; i < log.size(); i++) sb.append(log.get(i)).append("\n");
        }
        if (error.length() > 0) sb.append("Error: ").append(error).append("\n");
        return sb.toString();
    }

    private void note(String s) {
        last = s;
        synchronized (log) {
            log.add(s);
            while (log.size() > 40) log.remove(0);
        }
    }

    public void run() {
        while (!stopped) {
            try {
                final Socket s = ss.accept();
                synchronized (open) { open.add(s); }
                Thread t = new Thread(new Runnable() {
                    public void run() { new Session(s).serve(); }
                }, "ftp-session");
                t.setDaemon(true);
                t.start();
            } catch (Throwable t) {
                if (!stopped) error = String.valueOf(t.getMessage());
                return;
            }
        }
    }

    // ------------------------------------------------------------------ sesión

    private class Session {
        final Socket ctl;
        ServerSocket pasv;
        String cwd = "/";
        String userGiven;
        boolean authed;
        long rest;
        String renameFrom;

        Session(Socket s) { ctl = s; }

        void serve() {
            clients++;
            sessions++;
            OutputStream out = null;
            try {
                ctl.setSoTimeout(10 * 60 * 1000);
                out = ctl.getOutputStream();
                final OutputStream o = out;
                BufferedReader in = new BufferedReader(new InputStreamReader(ctl.getInputStream(), "UTF-8"));
                note("Conexión de " + ctl.getInetAddress().getHostAddress());
                reply(o, "220 USB Informer FTP");
                String line;
                while (!stopped && (line = in.readLine()) != null) {
                    String cmd = line, arg = "";
                    int sp = line.indexOf(' ');
                    if (sp > 0) { cmd = line.substring(0, sp); arg = line.substring(sp + 1); }
                    cmd = cmd.toUpperCase();
                    boolean go;
                    try {
                        go = command(o, cmd, arg);
                    } catch (java.io.IOException io) {
                        throw io;
                    } catch (Exception e) {
                        closePasv();
                        reply(o, "550 Error: " + e.getMessage());
                        go = true;
                    }
                    if (!go) break;
                }
            } catch (Throwable t) {
                // cliente caído
            } finally {
                clients--;
                closePasv();
                try { ctl.close(); } catch (Throwable t) { }
                synchronized (open) { open.remove(ctl); }
            }
        }

        void reply(OutputStream o, String s) throws Exception {
            o.write((s + "\r\n").getBytes("UTF-8"));
            o.flush();
        }

        void closePasv() {
            if (pasv != null) try { pasv.close(); } catch (Throwable t) { }
            pasv = null;
        }

        /** Devuelve false para terminar la sesión. */
        boolean command(OutputStream o, String cmd, String arg) throws Exception {
            if (cmd.equals("QUIT")) { reply(o, "221 Adiós"); return false; }
            if (cmd.equals("USER")) {
                userGiven = arg;
                authed = false;
                if (!needsLogin()) { authed = true; reply(o, "230 Acceso libre, sin contraseña"); }
                else reply(o, "331 Contraseña necesaria");
                return true;
            }
            if (cmd.equals("PASS")) {
                if (!needsLogin() || (user.equals(userGiven) && pass.equals(arg))) {
                    authed = true;
                    note("Entra: " + (userGiven == null ? "?" : userGiven));
                    reply(o, "230 Identificado");
                } else {
                    note("Contraseña incorrecta (" + userGiven + ")");
                    reply(o, "530 Usuario o contraseña incorrectos");
                }
                return true;
            }
            if (cmd.equals("NOOP")) { reply(o, "200 OK"); return true; }
            if (cmd.equals("SYST")) { reply(o, "215 UNIX Type: L8"); return true; }
            if (cmd.equals("FEAT")) {
                o.write("211-Funciones\r\n SIZE\r\n MDTM\r\n REST STREAM\r\n MLSD\r\n EPSV\r\n UTF8\r\n211 Fin\r\n".getBytes("UTF-8"));
                o.flush();
                return true;
            }
            if (cmd.equals("OPTS")) { reply(o, "200 OK"); return true; }
            if (!authed) { reply(o, "530 Primero identifícate (USER/PASS)"); return true; }

            if (cmd.equals("PWD") || cmd.equals("XPWD")) { reply(o, "257 \"" + cwd + "\""); return true; }
            if (cmd.equals("TYPE")) { reply(o, "200 Tipo cambiado"); return true; }
            if (cmd.equals("MODE") || cmd.equals("STRU")) { reply(o, "200 OK"); return true; }
            if (cmd.equals("CWD") || cmd.equals("XCWD")) {
                String p = resolve(arg);
                Object it = find(p);
                if (it == null || (it != ROOT && !((FileItem) it).dir)) reply(o, "550 No existe la carpeta");
                else { cwd = p; reply(o, "250 Carpeta cambiada"); }
                return true;
            }
            if (cmd.equals("CDUP") || cmd.equals("XCUP")) { cwd = resolve(".."); reply(o, "250 OK"); return true; }
            if (cmd.equals("PASV") || cmd.equals("EPSV")) {
                closePasv();
                pasv = new ServerSocket(0);
                int pt = pasv.getLocalPort();
                if (cmd.equals("EPSV")) {
                    reply(o, "229 Modo pasivo extendido (|||" + pt + "|)");
                } else {
                    String ip = ctl.getLocalAddress().getHostAddress();
                    reply(o, "227 Modo pasivo (" + ip.replace('.', ',') + "," + (pt >> 8) + "," + (pt & 255) + ")");
                }
                return true;
            }
            if (cmd.equals("PORT") || cmd.equals("EPRT")) { reply(o, "502 Usa modo pasivo"); return true; }
            if (cmd.equals("REST")) {
                try { rest = Long.parseLong(arg.trim()); reply(o, "350 Se reanudará en " + rest); }
                catch (Exception e) { rest = 0; reply(o, "501 Número no válido"); }
                return true;
            }
            if (cmd.equals("SIZE")) {
                Object it = find(resolve(arg));
                if (it == null || it == ROOT || ((FileItem) it).dir) reply(o, "550 No es un archivo");
                else reply(o, "213 " + ((FileItem) it).size);
                return true;
            }
            if (cmd.equals("MDTM")) {
                Object it = find(resolve(arg));
                if (it == null) reply(o, "550 No existe");
                else reply(o, "213 " + stamp());
                return true;
            }
            if (cmd.equals("LIST") || cmd.equals("NLST") || cmd.equals("MLSD")) { listing(o, cmd, arg); return true; }
            if (cmd.equals("RETR")) { retr(o, arg); return true; }
            if (cmd.equals("STOR") || cmd.equals("APPE")) { stor(o, arg, cmd.equals("APPE")); return true; }
            if (cmd.equals("DELE") || cmd.equals("MKD") || cmd.equals("XMKD") || cmd.equals("RMD") || cmd.equals("XRMD")
                    || cmd.equals("RNFR") || cmd.equals("RNTO")) {
                changes(o, cmd, arg);
                return true;
            }
            if (cmd.equals("STOU")) { reply(o, "550 No soportado"); return true; }
            reply(o, "502 Comando no soportado");
            return true;
        }

        // ---- rutas virtuales

        private final Object ROOT = new Object();

        String resolve(String arg) {
            String p = arg == null ? "" : arg.trim();
            if (p.startsWith("-")) {   // "ls -la"
                int sp = p.indexOf(' ');
                p = sp < 0 ? "" : p.substring(sp + 1).trim();
            }
            String base = p.startsWith("/") ? "" : cwd;
            ArrayList<String> parts = new ArrayList<String>();
            String all = base + "/" + p;
            String[] seg = all.split("/");
            for (int i = 0; i < seg.length; i++) {
                String s = seg[i];
                if (s.length() == 0 || s.equals(".")) continue;
                if (s.equals("..")) { if (parts.size() > 0) parts.remove(parts.size() - 1); }
                else parts.add(s);
            }
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < parts.size(); i++) sb.append('/').append(parts.get(i));
            return sb.length() == 0 ? "/" : sb.toString();
        }

        /** Montaje al que pertenece una ruta (o null si es la raíz virtual con varios montajes). */
        Mount mountOf(String path) {
            if (mounts.length == 1) return mounts[0];
            if (path.equals("/")) return null;
            String first = path.substring(1);
            int sl = first.indexOf('/');
            if (sl >= 0) first = first.substring(0, sl);
            for (int i = 0; i < mounts.length; i++) if (mounts[i].name.equals(first)) return mounts[i];
            return null;
        }

        /** Segmentos de la ruta dentro del montaje. */
        String[] inner(String path) {
            String q = path;
            if (mounts.length > 1) {
                int sl = q.indexOf('/', 1);
                q = sl < 0 ? "/" : q.substring(sl);
            }
            return q.equals("/") ? new String[0] : q.substring(1).split("/");
        }

        /** Devuelve ROOT (raíz o raíz de un montaje), un FileItem, o null. */
        Object find(String path) throws Exception {
            if (path.equals("/")) return ROOT;
            Mount m = mountOf(path);
            if (m == null) return null;
            String[] seg = inner(path);
            if (seg.length == 0) return ROOT;
            FileItem cur = null;
            for (int i = 0; i < seg.length; i++) {
                Vector v = children(m, cur);
                FileItem hit = null;
                for (int k = 0; k < v.size(); k++) {
                    FileItem f = (FileItem) v.elementAt(k);
                    if (f.name.equals(seg[i])) { hit = f; break; }
                }
                if (hit == null) return null;
                if (i < seg.length - 1 && !hit.dir) return null;
                cur = hit;
            }
            return cur;
        }

        Vector children(Mount m, FileItem dir) throws Exception {
            synchronized (m.src) {
                return dir == null ? m.src.listRoot() : m.src.list(dir);
            }
        }

        /** Lista de una ruta que es carpeta (raíz virtual, raíz de montaje o carpeta normal). */
        Vector listDir(String path, Object it) throws Exception {
            if (it == ROOT && mounts.length > 1 && path.equals("/")) {
                Vector v = new Vector();
                for (int i = 0; i < mounts.length; i++) {
                    FileItem f = new FileItem();
                    f.name = mounts[i].name;
                    f.dir = true;
                    v.addElement(f);
                }
                return v;
            }
            Mount m = mountOf(path);
            return children(m, it == ROOT ? null : (FileItem) it);
        }

        /** Archivo real del teléfono para una ruta, si el montaje permite escribir; si no, null. */
        File writableFile(String path) {
            Mount m = mountOf(path);
            if (m == null || !m.writable || m.base == null) return null;
            String[] seg = inner(path);
            File f = m.base;
            for (int i = 0; i < seg.length; i++) f = new File(f, seg[i]);
            return f;
        }

        // ---- datos

        Socket dataSocket(OutputStream o) throws Exception {
            if (pasv == null) { reply(o, "425 Usa PASV/EPSV primero"); return null; }
            try {
                pasv.setSoTimeout(15000);
                Socket d = pasv.accept();
                return d;
            } catch (Exception e) {
                reply(o, "425 No se pudo abrir la conexión de datos");
                return null;
            } finally {
                closePasv();
            }
        }

        void listing(OutputStream o, String cmd, String arg) throws Exception {
            String p = resolve(arg);
            Object it = find(p);
            Vector v;
            FileItem single = null;
            if (it == null) { reply(o, "550 No existe"); closePasv(); return; }
            if (it == ROOT) v = listDir(p, it);
            else if (((FileItem) it).dir) v = listDir(p, it);
            else { v = new Vector(); v.addElement(it); single = (FileItem) it; }
            if (pasv == null) { reply(o, "425 Usa PASV/EPSV primero"); return; }
            reply(o, "150 Enviando lista");
            Socket d = dataSocket(o);
            if (d == null) return;
            try {
                OutputStream ds = d.getOutputStream();
                StringBuffer sb = new StringBuffer();
                Calendar c = Calendar.getInstance();
                String[] mon = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
                String date = mon[c.get(Calendar.MONTH)] + " " + (c.get(Calendar.DAY_OF_MONTH) < 10 ? " " : "") + c.get(Calendar.DAY_OF_MONTH)
                        + " " + two(c.get(Calendar.HOUR_OF_DAY)) + ":" + two(c.get(Calendar.MINUTE));
                for (int i = 0; i < v.size(); i++) {
                    FileItem f = (FileItem) v.elementAt(i);
                    if (cmd.equals("NLST")) sb.append(f.name).append("\r\n");
                    else if (cmd.equals("MLSD")) {
                        sb.append("type=").append(f.dir ? "dir" : "file").append(";size=").append(f.size).append(";modify=").append(stamp())
                                .append("; ").append(f.name).append("\r\n");
                    } else {
                        sb.append(f.dir ? "dr-xr-xr-x" : "-r--r--r--").append(" 1 usb usb ").append(f.dir ? 0 : f.size).append(' ')
                                .append(date).append(' ').append(f.name).append("\r\n");
                    }
                }
                ds.write(sb.toString().getBytes("UTF-8"));
                ds.flush();
                ds.close();
                reply(o, "226 Lista enviada");
            } catch (Throwable t) {
                reply(o, "426 Conexión de datos cortada");
            } finally {
                try { d.close(); } catch (Throwable t) { }
            }
        }

        void stor(OutputStream o, String arg, boolean append) throws Exception {
            String rp = resolve(arg);
            File f = writableFile(rp);
            if (f == null) { reply(o, "550 Aquí no se puede escribir (solo lectura)"); closePasv(); return; }
            File par = f.getParentFile();
            if (par == null || !par.isDirectory()) { reply(o, "550 La carpeta no existe"); closePasv(); return; }
            if (f.isDirectory()) { reply(o, "550 Es una carpeta"); closePasv(); return; }
            if (pasv == null) { reply(o, "425 Usa PASV/EPSV primero"); return; }
            reply(o, "150 Recibiendo " + f.getName());
            Socket d = dataSocket(o);
            if (d == null) return;
            note("Subida: " + f.getName());
            FileOutputStream fo = null;
            boolean ok = false;
            try {
                fo = new FileOutputStream(f, append);
                InputStream in = d.getInputStream();
                byte[] b = new byte[65536];
                int n;
                while ((n = in.read(b)) > 0) {
                    fo.write(b, 0, n);
                    received += n;
                }
                fo.close();
                fo = null;
                ok = true;
                reply(o, "226 Archivo recibido");
                note("Recibido: " + f.getName());
            } catch (Throwable t) {
                note("Subida cortada: " + f.getName() + " (" + t.getMessage() + ")");
                try { reply(o, "426 Transferencia interrumpida"); } catch (Throwable e) { }
            } finally {
                if (fo != null) try { fo.close(); } catch (Throwable t) { }
                try { d.close(); } catch (Throwable t) { }
            }
        }

        void changes(OutputStream o, String cmd, String arg) throws Exception {
            String rp = resolve(arg);
            File f = writableFile(rp);
            if (f == null) { reply(o, "550 Aquí no se puede escribir (solo lectura)"); return; }
            if (cmd.equals("MKD") || cmd.equals("XMKD")) {
                if (f.exists()) reply(o, "550 Ya existe");
                else if (f.mkdir()) { note("Carpeta creada: " + f.getName()); reply(o, "257 \"" + rp + "\" creada"); }
                else reply(o, "550 No se pudo crear");
            } else if (cmd.equals("DELE")) {
                if (!f.isFile()) reply(o, "550 No es un archivo");
                else if (f.delete()) { note("Borrado: " + f.getName()); reply(o, "250 Borrado"); }
                else reply(o, "550 No se pudo borrar");
            } else if (cmd.equals("RMD") || cmd.equals("XRMD")) {
                if (!f.isDirectory()) reply(o, "550 No es una carpeta");
                else if (f.delete()) { note("Carpeta borrada: " + f.getName()); reply(o, "250 Carpeta borrada"); }
                else reply(o, "550 No se pudo borrar (¿está vacía?)");
            } else if (cmd.equals("RNFR")) {
                if (f.exists()) { renameFrom = rp; reply(o, "350 Dime el nuevo nombre (RNTO)"); }
                else reply(o, "550 No existe");
            } else if (cmd.equals("RNTO")) {
                File from = renameFrom == null ? null : writableFile(renameFrom);
                renameFrom = null;
                if (from == null) reply(o, "503 Primero RNFR");
                else if (f.exists()) reply(o, "550 Ya existe el destino");
                else if (from.renameTo(f)) { note("Renombrado: " + from.getName() + " -> " + f.getName()); reply(o, "250 Renombrado"); }
                else reply(o, "550 No se pudo renombrar");
            }
        }

        void retr(OutputStream o, String arg) throws Exception {
            String rp = resolve(arg);
            Object it = find(rp);
            if (it == null || it == ROOT || ((FileItem) it).dir) { reply(o, "550 No es un archivo"); closePasv(); return; }
            final FileItem f = (FileItem) it;
            final Mount mt = mountOf(rp);
            if (pasv == null) { reply(o, "425 Usa PASV/EPSV primero"); return; }
            long skip = rest;
            rest = 0;
            reply(o, "150 Enviando " + f.name + " (" + f.size + " bytes)");
            Socket d = dataSocket(o);
            if (d == null) return;
            note("Descarga: " + f.name);
            try {
                OutputStream ds = d.getOutputStream();
                final Skip sk = new Skip(ds, skip);
                Progress p = new Progress() {
                    public boolean cancelled() { return stopped; }
                    public void add(long n) { }
                    public void file(String n) { }
                };
                synchronized (mt.src) {
                    mt.src.copy(f, sk, p);
                }
                ds.flush();
                ds.close();
                reply(o, "226 Transferencia completa");
                note("Completo: " + f.name);
            } catch (Throwable t) {
                note("Cortada: " + f.name + " (" + t.getMessage() + ")");
                try { reply(o, "426 Transferencia interrumpida"); } catch (Throwable e) { }
            } finally {
                try { d.close(); } catch (Throwable t) { }
            }
        }
    }

    /** Descarta los primeros 'skip' bytes (REST) y cuenta lo enviado. */
    private class Skip extends OutputStream {
        private final OutputStream o;
        private long skip;

        Skip(OutputStream o, long skip) { this.o = o; this.skip = skip; }

        public void write(int b) throws java.io.IOException {
            write(new byte[] {(byte) b}, 0, 1);
        }

        public void write(byte[] b, int off, int len) throws java.io.IOException {
            if (skip > 0) {
                long s = Math.min(skip, len);
                skip -= s;
                off += (int) s;
                len -= (int) s;
            }
            if (len > 0) {
                o.write(b, off, len);
                sent += len;
            }
        }
    }

    private static String two(int v) { return v < 10 ? "0" + v : "" + v; }

    private static String stamp() {
        Calendar c = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));
        return c.get(Calendar.YEAR) + two(c.get(Calendar.MONTH) + 1) + two(c.get(Calendar.DAY_OF_MONTH))
                + two(c.get(Calendar.HOUR_OF_DAY)) + two(c.get(Calendar.MINUTE)) + two(c.get(Calendar.SECOND));
    }
}
