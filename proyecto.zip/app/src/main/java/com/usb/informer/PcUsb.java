package com.usb.informer;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Vector;

/**
 * Backend para PC (FreeJ2ME, MicroEmulator... sobre Windows o Linux). No necesita librerías:
 * - Dispositivos USB: PowerShell/WMI en Windows, /sys/bus/usb en Linux.
 * - Contenido: las unidades que el sistema ya monta (E:\, D:\...), leídas como carpetas normales.
 * - Reproducción de DVD y CD de audio: con VLC, que descifra y lee la unidad por sí mismo.
 */
public class PcUsb implements UsbBackend, UsbExtras {
    private UsbListener listener;
    private volatile boolean running;
    private int gen;
    private boolean win;
    private Vector devs = new Vector();
    private Vector vols = new Vector();   // String[] { ruta, texto, tipo, dispositivo }
    private Hashtable known = new Hashtable();
    private long lastScan;
    private String scanError;

    public String getName() { return "PC (" + (win ? "Windows" : "Linux") + ")"; }

    public String start(UsbListener l) {
        try {
            Class.forName("android.os.Build");
            return "esto es Android, no un PC";
        } catch (Throwable t) {
            // no es Android: seguimos
        }
        String os = System.getProperty("os.name", "").toLowerCase();
        win = os.indexOf("win") >= 0;
        if (!win && os.indexOf("linux") < 0) return "sistema no soportado (" + os + ")";
        listener = l;
        refresh(true);
        known.clear();
        for (int i = 0; i < devs.size(); i++) {
            UsbDevInfo d = (UsbDevInfo) devs.elementAt(i);
            known.put(d.deviceName, d);
        }
        running = true;
        gen++;
        final int my = gen;
        new Thread(new Runnable() {
            public void run() {
                while (running && my == gen) {
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        return;
                    }
                    try {
                        poll();
                    } catch (Throwable t) {
                        // seguimos
                    }
                }
            }
        }).start();
        return null;
    }

    public void stop() {
        running = false;
        listener = null;
    }

    public synchronized Vector getDevices() {
        refresh(false);
        return (Vector) devs.clone();
    }

    private void poll() {
        Vector now;
        synchronized (this) {
            refresh(true);
            now = (Vector) devs.clone();
        }
        Hashtable seen = new Hashtable();
        for (int i = 0; i < now.size(); i++) {
            UsbDevInfo d = (UsbDevInfo) now.elementAt(i);
            seen.put(d.deviceName, d);
            if (known.get(d.deviceName) == null) {
                known.put(d.deviceName, d);
                UsbListener l = listener;
                if (l != null) l.deviceAttached(d);
            }
        }
        Vector gone = new Vector();
        java.util.Enumeration e = known.keys();
        while (e.hasMoreElements()) {
            Object k = e.nextElement();
            if (seen.get(k) == null) gone.addElement(k);
        }
        for (int i = 0; i < gone.size(); i++) {
            UsbDevInfo d = (UsbDevInfo) known.remove(gone.elementAt(i));
            UsbListener l = listener;
            if (l != null && d != null) l.deviceDetached(d);
        }
    }

    private synchronized void refresh(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - lastScan < 2000) return;
        lastScan = now;
        try {
            if (win) scanWindows();
            else scanLinux();
            scanError = null;
        } catch (Throwable t) {
            scanError = t.toString();
        }
    }

    // ---------------------------------------------------------------- Windows

    private static final String PS =
            "[Console]::OutputEncoding=[Text.Encoding]::UTF8;"
            + "Get-CimInstance Win32_PnPEntity | Where-Object { $_.DeviceID -like 'USB\\VID_*' } | ForEach-Object { 'D|' + $_.DeviceID + '|' + $_.Name + '|' + $_.Manufacturer + '|' + $_.Service };"
            + "Get-CimInstance Win32_LogicalDisk | ForEach-Object { 'V|' + $_.DeviceID + '|' + $_.DriveType + '|' + $_.VolumeName + '|' + $_.Size + '|' + $_.FileSystem };"
            + "Get-CimInstance Win32_CDROMDrive | ForEach-Object { 'C|' + $_.Drive + '|' + $_.Caption + '|' + $_.PNPDeviceID };"
            + "try { Get-CimInstance Win32_DiskDrive | Where-Object { $_.InterfaceType -eq 'USB' } | ForEach-Object { $d = $_; Get-CimAssociatedInstance -InputObject $d -ResultClassName Win32_DiskPartition | ForEach-Object { Get-CimAssociatedInstance -InputObject $_ -ResultClassName Win32_LogicalDisk | ForEach-Object { 'U|' + $_.DeviceID + '|' + $d.Model } } } } catch {}";

    private void scanWindows() throws Exception {
        String out = run(new String[] { "powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                "-Command", PS }, 25000);
        parseWindows(out);
    }

    /** Interpreta la salida del script de PowerShell (público para poder probarlo). */
    public void parseWindows(String out) {
        Vector nd = new Vector();
        Vector nv = new Vector();
        Hashtable usbModel = new Hashtable();
        Hashtable cdCaption = new Hashtable();
        Hashtable cdUsb = new Hashtable();
        Vector lines = split(out, '\n');
        for (int i = 0; i < lines.size(); i++) {
            String ln = ((String) lines.elementAt(i)).trim();
            if (ln.length() < 3 || ln.charAt(1) != '|') continue;
            Vector f = split(ln.substring(2), '|');
            char t = ln.charAt(0);
            if (t == 'U' && f.size() >= 2) usbModel.put(f.elementAt(0), f.elementAt(1));
            if (t == 'C' && f.size() >= 3) {
                cdCaption.put(f.elementAt(0), f.elementAt(1));
                if (((String) f.elementAt(2)).toUpperCase().startsWith("USBSTOR")) cdUsb.put(f.elementAt(0), "1");
            }
        }
        for (int i = 0; i < lines.size(); i++) {
            String ln = ((String) lines.elementAt(i)).trim();
            if (ln.length() < 3 || ln.charAt(1) != '|') continue;
            Vector f = split(ln.substring(2), '|');
            char t = ln.charAt(0);
            if (t == 'D' && f.size() >= 1) {
                UsbDevInfo d = winDevice(f);
                if (d != null) nd.addElement(d);
            } else if (t == 'V' && f.size() >= 5) {
                String id = (String) f.elementAt(0);
                String type = (String) f.elementAt(1);
                String label = (String) f.elementAt(2);
                String size = (String) f.elementAt(3);
                String fs = (String) f.elementAt(4);
                String kind;
                if (type.equals("5")) kind = "cd";
                else if (type.equals("2") || usbModel.get(id) != null) kind = "usb";
                else continue;
                if (kind.equals("usb") && !type.equals("2") && usbModel.get(id) == null) continue;
                StringBuffer sb = new StringBuffer(id);
                String name = label;
                if (kind.equals("cd") && name.length() == 0 && cdCaption.get(id) != null) name = (String) cdCaption.get(id);
                if (name.length() > 0) sb.append(' ').append(name);
                sb.append(" (");
                sb.append(kind.equals("cd") ? (cdUsb.get(id) != null ? "CD/DVD USB" : "CD/DVD") : "USB");
                long sz = 0;
                try {
                    sz = Long.parseLong(size.trim());
                } catch (Throwable e) {
                    // sin tamaño
                }
                if (sz > 0) sb.append(", ").append(Phone.sizeText(sz));
                else sb.append(", sin disco / sin soporte");
                if (fs.length() > 0) sb.append(", ").append(fs);
                sb.append(")");
                nv.addElement(new String[] { id + "\\", sb.toString(), kind, id });
            }
        }
        devs = nd;
        vols = nv;
    }

    private UsbDevInfo winDevice(Vector f) {
        String id = (String) f.elementAt(0);
        String up = id.toUpperCase();
        int v = up.indexOf("VID_");
        int p = up.indexOf("PID_");
        if (v < 0 || p < 0 || up.indexOf("&MI_") >= 0) return null;
        UsbDevInfo d = new UsbDevInfo();
        d.deviceName = id;
        try {
            d.vendorId = Integer.parseInt(up.substring(v + 4, v + 8), 16);
            d.productId = Integer.parseInt(up.substring(p + 4, p + 8), 16);
        } catch (Throwable t) {
            return null;
        }
        int sl = id.lastIndexOf('\\');
        String inst = sl >= 0 ? id.substring(sl + 1) : "";
        d.serial = inst.indexOf('&') >= 0 ? null : inst;
        d.productName = f.size() > 1 ? (String) f.elementAt(1) : "";
        d.manufacturer = f.size() > 2 ? (String) f.elementAt(2) : "";
        String svc = f.size() > 3 ? ((String) f.elementAt(3)).toLowerCase() : "";
        if (svc.equals("usbstor") || svc.equals("uaspstor")) { d.devClass = 8; d.subClass = 6; d.protocol = 80; d.mass = true; }
        else if (svc.startsWith("usbhub")) d.devClass = 9;
        else if (svc.equals("hidusb")) d.devClass = 3;
        else if (svc.equals("usbvideo")) d.devClass = 14;
        else if (svc.equals("usbprint")) d.devClass = 7;
        d.id = d.vendorId * 65536 + d.productId;
        d.extra = "Servicio de Windows: " + (svc.length() > 0 ? svc : "-") + "\nID de instancia: " + id;
        return d;
    }

    // ---------------------------------------------------------------- Linux

    private void scanLinux() {
        Vector nd = new Vector();
        File root = new File(System.getProperty("pc.sys", "/sys/bus/usb/devices"));
        File[] fs = root.listFiles();
        if (fs != null) {
            for (int i = 0; i < fs.length; i++) {
                String n = fs[i].getName();
                if (n.indexOf(':') >= 0 || n.startsWith("usb")) continue;
                String vid = rd(new File(fs[i], "idVendor"));
                String pid = rd(new File(fs[i], "idProduct"));
                if (vid.length() == 0 || pid.length() == 0) continue;
                UsbDevInfo d = new UsbDevInfo();
                try {
                    d.vendorId = Integer.parseInt(vid, 16);
                    d.productId = Integer.parseInt(pid, 16);
                    d.devClass = Integer.parseInt(rd(new File(fs[i], "bDeviceClass")), 16);
                } catch (Throwable t) {
                    // campos que falten
                }
                d.deviceName = "/sys/bus/usb/devices/" + n;
                d.manufacturer = rd(new File(fs[i], "manufacturer"));
                d.productName = rd(new File(fs[i], "product"));
                d.serial = rd(new File(fs[i], "serial"));
                d.version = rd(new File(fs[i], "bcdDevice"));
                d.id = d.vendorId * 65536 + d.productId;
                for (int k = 0; k < fs.length; k++) {
                    String m = fs[k].getName();
                    if (m.startsWith(n + ":")) {
                        String c = rd(new File(fs[k], "bInterfaceClass"));
                        if (c.equals("08")) {
                            d.mass = true;
                            String sc = rd(new File(fs[k], "bInterfaceSubClass"));
                            if (sc.equals("02") || sc.equals("05")) d.optical = true;
                        }
                    }
                }
                nd.addElement(d);
            }
        }
        Vector nv = new Vector();
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(
                    new FileInputStream(System.getProperty("pc.mounts", "/proc/mounts")), "UTF-8"));
            String ln;
            while ((ln = r.readLine()) != null) {
                Vector f = split(ln, ' ');
                if (f.size() < 3) continue;
                String dev = (String) f.elementAt(0);
                String mnt = unescape((String) f.elementAt(1));
                String fst = (String) f.elementAt(2);
                boolean sr = dev.startsWith("/dev/sr");
                if (!(sr || dev.startsWith("/dev/sd"))) continue;
                if (!(mnt.startsWith("/media") || mnt.startsWith("/run/media") || mnt.startsWith("/mnt"))) continue;
                String name = mnt.substring(mnt.lastIndexOf('/') + 1);
                nv.addElement(new String[] { mnt, name + " (" + (sr ? "CD/DVD" : "USB") + ", " + fst + ")",
                        sr ? "cd" : "usb", dev });
            }
            r.close();
        } catch (Throwable t) {
            // sin /proc/mounts
        }
        devs = nd;
        vols = nv;
    }

    private static String unescape(String s) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 3 < s.length() + 0 && i + 3 <= s.length() - 0) {
                try {
                    sb.append((char) Integer.parseInt(s.substring(i + 1, i + 4), 8));
                    i += 3;
                    continue;
                } catch (Throwable t) {
                    // literal
                }
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private static String rd(File f) {
        try {
            FileInputStream in = new FileInputStream(f);
            try {
                byte[] b = new byte[256];
                int n = in.read(b);
                return n > 0 ? new String(b, 0, n, "UTF-8").trim() : "";
            } finally {
                in.close();
            }
        } catch (Throwable t) {
            return "";
        }
    }

    static Vector split(String s, char c) {
        Vector v = new Vector();
        int a = 0;
        for (int i = 0; i <= s.length(); i++) {
            if (i == s.length() || s.charAt(i) == c) {
                v.addElement(s.substring(a, i));
                a = i + 1;
            }
        }
        return v;
    }

    // ---------------------------------------------------------------- ejecutar programas

    private static String run(String[] cmd, final int ms) throws Exception {
        final Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        p.getOutputStream().close();
        Thread dog = new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(ms);
                    p.destroy();
                } catch (InterruptedException e) {
                    // terminó a tiempo
                }
            }
        });
        dog.start();
        InputStream in = p.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[4096];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        dog.interrupt();
        return new String(bo.toByteArray(), "UTF-8");
    }

    private String launch(String[] cmd) {
        try {
            new ProcessBuilder(cmd).start();
            return null;
        } catch (Throwable t) {
            return t.toString();
        }
    }

    // ---------------------------------------------------------------- UsbExtras

    public String requestPermissions() {
        return "En el PC no hace falta pedir permiso USB.";
    }

    public synchronized Vector storageNames() {
        refresh(false);
        Vector out = new Vector();
        for (int i = 0; i < vols.size(); i++) out.addElement(((String[]) vols.elementAt(i))[1]);
        if (vols.size() == 0 && scanError != null) out.addElement("(no pude leer las unidades: " + scanError + ")");
        return out;
    }

    private String[] vol(int i) {
        return i >= 0 && i < vols.size() ? (String[]) vols.elementAt(i) : null;
    }

    public String volumePath(int index) {
        String[] v = vol(index);
        return v == null ? "" : v[0];
    }

    public String volumeKind(int index) {
        String[] v = vol(index);
        return v == null ? "" : v[2];
    }

    public String openStorage(int index) {
        String[] v = vol(index);
        if (v == null) return openFileManager();
        return launch(win ? new String[] { "explorer.exe", v[0] } : new String[] { "xdg-open", v[0] });
    }

    public String openFileManager() {
        String home = System.getProperty("user.home", ".");
        return launch(win ? new String[] { "explorer.exe", home } : new String[] { "xdg-open", home });
    }

    public OpticalDisc openDisc(UsbDevInfo d) throws Exception {
        return openDisc(d, true);
    }

    public OpticalDisc openDisc(UsbDevInfo d, boolean optical) throws Exception {
        throw new Exception("En el PC las unidades aparecen en \"Almacenamiento\" con su letra.");
    }

    public String openAllFilesAccess() {
        return "En el PC no hace falta ningún permiso de archivos.";
    }

    public String openStorageSettings() {
        return "En el PC usa \"Quitar hardware de forma segura\" de Windows.";
    }

    public String openUrl(String url, String mime) {
        return launch(win ? new String[] { "cmd", "/c", "start", "", url } : new String[] { "xdg-open", url });
    }

    /** Reproduce el disco de la unidad con VLC (lee la unidad y descifra DVD por sí mismo). */
    public String playDisc(int index, boolean audio) {
        String[] v = vol(index);
        if (v == null) return "Unidad no encontrada";
        String vlc = findVlc();
        if (vlc == null) return "No encuentro VLC. Instálalo desde videolan.org y vuelve a intentarlo.";
        String mrl;
        if (win) mrl = (audio ? "cdda:///" : "dvd:///") + v[3];
        else mrl = (audio ? "cdda://" : "dvd://") + v[3];
        return launch(new String[] { vlc, mrl });
    }

    private String findVlc() {
        if (!win) return "vlc";
        String[] bases = { System.getenv("ProgramFiles"), System.getenv("ProgramFiles(x86)"), System.getenv("ProgramW6432"),
                "C:\\Program Files", "C:\\Program Files (x86)" };
        for (int i = 0; i < bases.length; i++) {
            if (bases[i] == null) continue;
            File f = new File(bases[i], "VideoLAN\\VLC\\vlc.exe");
            if (f.exists()) return f.getPath();
        }
        return null;
    }
}
