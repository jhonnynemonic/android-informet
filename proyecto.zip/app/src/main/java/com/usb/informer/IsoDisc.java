package com.usb.informer;
import java.io.OutputStream;
import java.util.Vector;

/** Lector de ISO 9660 (con Joliet si existe) sobre un OpticalDisc. */
public class IsoDisc implements FileSource, DiscTree {

    private Sectors d;
    public String volume = "";
    public boolean joliet;
    private long rootLba;
    private long rootSize;

    public IsoDisc(OpticalDisc disc) throws Exception {
        this((Sectors) disc);
    }

    public IsoDisc(Sectors disc) throws Exception {
        d = disc;
        if (d.sectorSize() != 2048) {
            throw new Exception("El disco no tiene sectores de datos de 2048 bytes");
        }
        byte[] pv = null, sv = null;
        for (int s = 16; s < 40; s++) {
            byte[] b = d.read(s, 1);
            if (!(b[1] == 'C' && b[2] == 'D' && b[3] == '0' && b[4] == '0' && b[5] == '1')) break;
            int type = b[0] & 0xFF;
            if (type == 255) break;
            if (type == 1 && pv == null) pv = b;
            else if (type == 2 && sv == null && b[88] == '%' && b[89] == '/'
                    && (b[90] == '@' || b[90] == 'C' || b[90] == 'E')) sv = b;
        }
        if (pv == null) throw new Exception("No es un disco ISO 9660 (formato no admitido o disco vacío)");
        byte[] r = (sv != null) ? sv : pv;
        joliet = (sv != null);
        volume = ascii(pv, 40, 32).trim();
        rootLba = le32(r, 156 + 2);
        rootSize = le32(r, 156 + 10);
    }

    public long position(FileItem f) { return ((long[]) f.ref)[0]; }

    public String label() { return volume.length() == 0 ? "Disco" : volume; }

    public Vector listRoot() throws Exception { return list(rootLba, rootSize); }

    public Vector list(FileItem dir) throws Exception {
        long[] r = (long[]) dir.ref;
        return list(r[0], r[1]);
    }

    private Vector list(long lba, long size) throws Exception {
        Vector dirs = new Vector();
        Vector files = new Vector();
        long sectors = (size + 2047) / 2048;
        if (sectors > 512) sectors = 512;
        for (int s = 0; s < sectors; s += 8) {
            int c = (int) Math.min(8, sectors - s);
            byte[] buf = d.read((int) lba + s, c);
            for (int sec = 0; sec < c; sec++) {
                int base = sec * 2048;
                int p = 0;
                while (p < 2048) {
                    int len = buf[base + p] & 0xFF;
                    if (len == 0 || p + len > 2048 || len < 34) break;
                    int o = base + p;
                    int nl = buf[o + 32] & 0xFF;
                    boolean special = (nl == 1 && (buf[o + 33] == 0 || buf[o + 33] == 1));
                    if (!special) {
                        FileItem e = new FileItem();
                        e.ref = new long[] { le32(buf, o + 2), le32(buf, o + 10) };
                        e.size = le32(buf, o + 10);
                        e.dir = (buf[o + 25] & 2) != 0;
                        e.name = decodeName(buf, o + 33, nl);
                        FileItem.sortedAdd(e.dir ? dirs : files, e);
                    }
                    p += len;
                }
            }
        }
        for (int i = 0; i < files.size(); i++) dirs.addElement(files.elementAt(i));
        return dirs;
    }

    /** Lee len bytes (máx. unos 32 KB) a partir de off dentro del archivo. Devuelve los bytes leídos. */
    public int readAt(FileItem f, long off, byte[] dst, int len) throws Exception {
        long[] r = (long[]) f.ref;
        if (off >= r[1]) return -1;
        int skip = (int) (off % 2048);
        len = (int) Math.min(len, Math.min(r[1] - off, 32 * 2048 - skip));
        int sectors = (skip + len + 2047) / 2048;
        byte[] b = d.read((int) (r[0] + off / 2048), sectors);
        System.arraycopy(b, skip, dst, 0, len);
        return len;
    }

    public String preview(FileItem e, int max) throws Exception {
        int n = (int) Math.min(e.size, max);
        if (n <= 0) return "(archivo vacío)";
        byte[] b = new byte[n];
        int got = readAt(e, 0, b, n);
        return Preview.make(b, Math.max(got, 0), e.size);
    }

    public void copy(FileItem f, OutputStream out, Progress p) throws Exception {
        long[] r = (long[]) f.ref;
        long pos = 0;
        while (pos < r[1]) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            int n = (int) Math.min(16, (r[1] - pos + 2047) / 2048);
            byte[] b = d.read((int) (r[0] + pos / 2048), n);
            int w = (int) Math.min((long) n * 2048, r[1] - pos);
            out.write(b, 0, w);
            pos += w;
            if (p != null) p.add(w);
        }
    }

    private String decodeName(byte[] b, int off, int len) {
        String s;
        if (joliet) {
            try {
                s = new String(b, off, len, "UTF-16BE");
            } catch (Throwable t) {
                s = ascii(b, off, len);
            }
        } else {
            StringBuffer sb = new StringBuffer();
            for (int i = off; i < off + len; i++) sb.append((char) (b[i] & 0xFF));
            s = sb.toString();
        }
        int semi = s.indexOf(';');
        if (semi >= 0) s = s.substring(0, semi);
        if (s.endsWith(".")) s = s.substring(0, s.length() - 1);
        return s;
    }

    private static long le32(byte[] b, int o) {
        return ((b[o] & 0xFFL) | ((b[o + 1] & 0xFFL) << 8) | ((b[o + 2] & 0xFFL) << 16) | ((b[o + 3] & 0xFFL) << 24));
    }

    private static String ascii(byte[] b, int off, int len) {
        StringBuffer sb = new StringBuffer();
        for (int i = off; i < off + len; i++) {
            int c = b[i] & 0xFF;
            sb.append(c >= 32 && c < 127 ? (char) c : ' ');
        }
        return sb.toString();
    }
}
