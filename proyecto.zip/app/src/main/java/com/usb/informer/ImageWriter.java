package com.usb.informer;
import java.io.IOException;
import java.io.OutputStream;

/** Flujo que escribe en bruto en un USB (como dd of=/dev/sdX). El último bloque se rellena con ceros. */
public class ImageWriter extends OutputStream {
    private OpticalDisc d;
    private byte[] buf = new byte[OpticalDisc.WRITE_CHUNK];
    private int fill;
    private int lba;
    public long written;
    private Progress p;

    public ImageWriter(OpticalDisc d, Progress p) {
        this(d, p, 0);
    }

    /** Empieza a escribir en el bloque startLba. */
    public ImageWriter(OpticalDisc d, Progress p, int startLba) {
        this.d = d;
        this.p = p;
        this.lba = startLba;
    }

    public void write(int b) throws IOException {
        write(new byte[] { (byte) b }, 0, 1);
    }

    public void write(byte[] b, int off, int len) throws IOException {
        while (len > 0) {
            int n = Math.min(len, buf.length - fill);
            System.arraycopy(b, off, buf, fill, n);
            fill += n;
            off += n;
            len -= n;
            if (fill == buf.length) flushBuf(buf.length);
        }
    }

    private void flushBuf(int bytes) throws IOException {
        if (p != null && p.cancelled()) throw new IOException("Cancelado");
        try {
            d.write(lba, buf, bytes);
        } catch (Exception e) {
            throw new IOException(e.getMessage());
        }
        lba += bytes / d.blockSize;
        written += Math.min(bytes, fill);
        if (p != null) p.add(Math.min(bytes, fill));
        fill = 0;
    }

    /** Escribe lo que quede (relleno con ceros hasta completar bloque) y vacía la caché. */
    public void finish() throws IOException {
        if (fill > 0) {
            int bs = d.blockSize;
            int total = ((fill + bs - 1) / bs) * bs;
            for (int i = fill; i < total; i++) buf[i] = 0;
            flushBuf(total);
        }
        d.flush();
    }
}
