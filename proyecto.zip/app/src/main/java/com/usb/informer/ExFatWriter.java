package com.usb.informer;
import java.util.Calendar;
import java.util.Vector;

/**
 * Formatea una partición como exFAT y copia dentro el árbol de una ISO.
 * Disposición: región de arranque (24 sectores con copia), FAT, y en el montón de clusters:
 * bitmap de asignación, tabla de mayúsculas, directorio raíz, resto de directorios y archivos (todo contiguo, con cadena en la FAT).
 */
public class ExFatWriter {
    private static class Node {
        String name;
        boolean dir;
        long size;
        FileItem src;
        Vector kids = new Vector();
        Node parent;
        long first;      // primer cluster (0 si está vacío)
        long clusters;
        long entBytes;   // bytes de entradas de directorio (solo carpetas)
    }

    private DiscTree iso;
    private OpticalDisc dev;
    private long partStart, partBlocks;
    private int bs;
    private String label;
    private Node root = new Node();
    private Vector all = new Vector();      // todos menos la raíz
    private Vector files = new Vector();
    public Vector skipped = new Vector();
    public long fileBytes;
    private String[] exclude;
    private char[] upcase = new char[65536];

    private int bpsShift, spcShift;
    private long clBytes, fatOffset, fatLength, heapOffset, clusterCount;
    private long bitmapFirst, bitmapBytes, bitmapClusters, upFirst, upClusters, rootFirst, rootClusters;
    private long dataStart, endCluster;
    private long serial;
    private byte[] fat;
    private int stamp;

    public ExFatWriter(DiscTree iso, OpticalDisc dev, long partStart, long partBlocks, String label) {
        this.iso = iso;
        this.dev = dev;
        this.partStart = partStart;
        this.partBlocks = partBlocks;
        this.label = label;
        bs = dev.blockSize;
        serial = System.currentTimeMillis() * 31 + 12345;
        byte[] up = loadRes("/upcase.bin", 131072);
        if (up != null) {
            for (int i = 0; i < 65536; i++) upcase[i] = (char) ((up[2 * i] & 0xFF) | ((up[2 * i + 1] & 0xFF) << 8));
        } else {
            for (int i = 0; i < 65536; i++) upcase[i] = Character.toUpperCase((char) i);
        }
        root.dir = true;
        root.name = "";
        Calendar c = Calendar.getInstance();
        int y = c.get(Calendar.YEAR) - 1980;
        if (y < 0) y = 0;
        stamp = (y << 25) | ((c.get(Calendar.MONTH) + 1) << 21) | (c.get(Calendar.DAY_OF_MONTH) << 16)
                | (c.get(Calendar.HOUR_OF_DAY) << 11) | (c.get(Calendar.MINUTE) << 5) | (c.get(Calendar.SECOND) / 2);
    }

    private static byte[] loadRes(String name, int size) {
        try {
            java.io.InputStream in = ExFatWriter.class.getResourceAsStream(name);
            if (in == null) return null;
            byte[] b = new byte[size];
            int n = 0;
            while (n < size) {
                int r = in.read(b, n, size - n);
                if (r <= 0) break;
                n += r;
            }
            in.close();
            return n == size ? b : null;
        } catch (Exception e) {
            return null;
        }
    }

    public void setExclude(String[] names) { exclude = names; }

    public void setGeometry(long start, long blocks, String lbl) {
        partStart = start;
        partBlocks = blocks;
        label = lbl;
    }

    public int fileCount() { return files.size(); }

    public long dataBytes() { return (endCluster - dataStart) * clBytes; }

    // ------------------------------------------------------------ 1. recorrer

    public void scan(Progress p) throws Exception {
        walk(root, iso.listRoot(), "", 0, p);
    }

    private void walk(Node dir, Vector items, String path, int depth, Progress p) throws Exception {
        if (depth > 40) return;
        for (int i = 0; i < items.size(); i++) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            FileItem it = (FileItem) items.elementAt(i);
            String nm = clean(it.name);
            if (nm.length() == 0) continue;
            if (depth == 0 && exclude != null) {
                boolean ex = false;
                for (int k = 0; k < exclude.length; k++) if (exclude[k].equalsIgnoreCase(nm)) ex = true;
                if (ex) continue;
            }
            if (taken(dir, nm)) {
                skipped.addElement(path + "/" + it.name + " (nombre repetido)");
                continue;
            }
            Node n = new Node();
            n.name = nm;
            n.parent = dir;
            n.src = it;
            n.dir = it.dir;
            dir.kids.addElement(n);
            all.addElement(n);
            if (it.dir) {
                walk(n, iso.list(it), path + "/" + nm, depth + 1, p);
            } else {
                n.size = it.size;
                files.addElement(n);
                fileBytes += it.size;
            }
        }
    }

    private boolean taken(Node dir, String nm) {
        for (int i = 0; i < dir.kids.size(); i++) {
            if (cmp(((Node) dir.kids.elementAt(i)).name, nm) == 0) return true;
        }
        return false;
    }

    private static String clean(String n) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < n.length() && sb.length() < 255; i++) {
            char c = n.charAt(i);
            if (c < 32 || "\"*/:<>?\\|".indexOf(c) >= 0) c = '_';
            sb.append(c);
        }
        String s = sb.toString();
        while (s.endsWith(" ") || s.endsWith(".")) s = s.substring(0, s.length() - 1);
        while (s.startsWith(" ")) s = s.substring(1);
        return s;
    }

    private int cmp(String a, String b) {
        int n = Math.min(a.length(), b.length());
        for (int i = 0; i < n; i++) {
            int x = upcase[a.charAt(i)], y = upcase[b.charAt(i)];
            if (x != y) return x < y ? -1 : 1;
        }
        return a.length() == b.length() ? 0 : (a.length() < b.length() ? -1 : 1);
    }

    // ------------------------------------------------------------ 2. planificar

    private static long ceil(long a, long b) { return (a + b - 1) / b; }

    private static int log2(long v) {
        int s = 0;
        while ((1L << s) < v) s++;
        return s;
    }

    private static int nameEntries(String n) { return (n.length() + 14) / 15; }

    public void layout() throws Exception {
        long volBytes = partBlocks * bs;
        if (volBytes < 8L * 1024 * 1024) throw new Exception("La partición exFAT es demasiado pequeña");
        // tamaño de cluster como Windows: 4 KB (<256 MB), 32 KB (<=32 GB), 128 KB (mayores)
        clBytes = volBytes < 256L * 1024 * 1024 ? 4096 : (volBytes <= 32L * 1024 * 1024 * 1024 ? 32768 : 131072);
        String forced = System.getProperty("usbinformer.exfatcl");   // solo para pruebas
        if (forced != null) clBytes = Long.parseLong(forced);
        if (clBytes < bs) clBytes = bs;
        bpsShift = log2(bs);
        spcShift = log2(clBytes / bs);
        long spc = clBytes / bs;
        long align = Math.max(1, (1024L * 1024) / bs);
        fatOffset = 24;
        long cc = partBlocks / spc;
        long heap = 0;
        for (int it = 0; it < 6; it++) {
            fatLength = ceil((cc + 2) * 4, bs);
            heap = ceil(fatOffset + fatLength, align) * align;
            long ncc = (partBlocks - heap) / spc;
            if (ncc == cc) break;
            cc = ncc;
        }
        heapOffset = heap;
        clusterCount = cc;
        if (clusterCount < 16) throw new Exception("La partición exFAT es demasiado pequeña");
        // directorios: tamaño de las entradas
        root.entBytes = 96;
        for (int i = 0; i < all.size(); i++) {
            Node n = (Node) all.elementAt(i);
            Node par = n.parent;
            par.entBytes += 32L * (2 + nameEntries(n.name));
        }
        // asignación contigua de clusters
        long next = 2;
        bitmapFirst = next;
        bitmapBytes = ceil(clusterCount, 8);
        bitmapClusters = ceil(bitmapBytes, clBytes);
        next += bitmapClusters;
        upFirst = next;
        upClusters = ceil(131072, clBytes);
        next += upClusters;
        rootFirst = next;
        rootClusters = Math.max(1, ceil(root.entBytes, clBytes));
        next += rootClusters;
        root.first = rootFirst;
        root.clusters = rootClusters;
        for (int i = 0; i < all.size(); i++) {
            Node n = (Node) all.elementAt(i);
            if (!n.dir) continue;
            n.clusters = Math.max(1, ceil(n.entBytes, clBytes));
            n.first = next;
            next += n.clusters;
        }
        dataStart = next;
        for (int i = 0; i < files.size(); i++) {
            Node f = (Node) files.elementAt(i);
            if (f.size == 0) { f.first = 0; f.clusters = 0; continue; }
            f.clusters = ceil(f.size, clBytes);
            f.first = next;
            next += f.clusters;
        }
        endCluster = next;
        if (endCluster - 2 > clusterCount) {
            throw new Exception("El contenido no cabe en la partición exFAT (faltan " + ((endCluster - 2 - clusterCount) * clBytes / 1048576) + " MB)");
        }
        // FAT
        fat = new byte[(int) (fatLength * bs)];
        put32(fat, 0, 0xFFFFFFF8L);
        put32(fat, 4, 0xFFFFFFFFL);
        chain(bitmapFirst, bitmapClusters);
        chain(upFirst, upClusters);
        chain(rootFirst, rootClusters);
        for (int i = 0; i < all.size(); i++) {
            Node n = (Node) all.elementAt(i);
            if (n.dir) chain(n.first, n.clusters);
        }
        for (int i = 0; i < files.size(); i++) {
            Node f = (Node) files.elementAt(i);
            if (f.clusters > 0) chain(f.first, f.clusters);
        }
    }

    private void chain(long first, long count) {
        for (long k = 0; k < count; k++) {
            long c = first + k;
            put32(fat, (int) (c * 4), k == count - 1 ? 0xFFFFFFFFL : c + 1);
        }
    }

    // ------------------------------------------------------------ 3. escribir

    private static void put16(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); }

    private static void put32(byte[] b, int o, long v) {
        b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24);
    }

    private static void put64(byte[] b, int o, long v) {
        put32(b, o, v & 0xFFFFFFFFL);
        put32(b, o + 4, (v >> 32) & 0xFFFFFFFFL);
    }

    private void wrSectors(long sector, byte[] data) throws Exception {
        long lba = partStart + sector;
        int need = (data.length + bs - 1) / bs * bs;
        if (need != data.length) {
            byte[] c = new byte[need];
            System.arraycopy(data, 0, c, 0, data.length);
            data = c;
        }
        int pos = 0;
        while (pos < data.length) {
            int n = Math.min(OpticalDisc.WRITE_CHUNK, data.length - pos);
            byte[] part = new byte[n];
            System.arraycopy(data, pos, part, 0, n);
            dev.write((int) (lba + pos / bs), part, n);
            pos += n;
        }
    }

    private long clusterSector(long c) { return heapOffset + (c - 2) * (clBytes / bs); }

    private long usedClusters() { return endCluster - 2; }

    private byte[] bootRegion() {
        byte[] r = new byte[12 * bs];
        byte[] b = r;
        b[0] = (byte) 0xEB; b[1] = 0x76; b[2] = (byte) 0x90;
        byte[] nm = { 'E', 'X', 'F', 'A', 'T', ' ', ' ', ' ' };
        System.arraycopy(nm, 0, b, 3, 8);
        put64(b, 64, partStart);
        put64(b, 72, partBlocks);
        put32(b, 80, fatOffset);
        put32(b, 84, fatLength);
        put32(b, 88, heapOffset);
        put32(b, 92, clusterCount);
        put32(b, 96, rootFirst);
        put32(b, 100, serial & 0xFFFFFFFFL);
        put16(b, 104, 0x0100);
        put16(b, 106, 0);
        b[108] = (byte) bpsShift;
        b[109] = (byte) spcShift;
        b[110] = 1;
        b[111] = (byte) 0x80;
        b[112] = (byte) Math.min(100, usedClusters() * 100 / clusterCount);
        for (int i = 120; i < 510; i++) b[i] = (byte) 0xF4;
        b[510] = 0x55; b[511] = (byte) 0xAA;
        for (int s = 1; s <= 8; s++) {
            int o = s * bs + bs - 4;
            b[o] = 0; b[o + 1] = 0; b[o + 2] = 0x55; b[o + 3] = (byte) 0xAA;
        }
        long cs = 0;
        for (int i = 0; i < 11 * bs; i++) {
            if (i == 106 || i == 107 || i == 112) continue;
            cs = (((cs & 1) != 0 ? 0x80000000L : 0) + (cs >> 1) + (b[i] & 0xFF)) & 0xFFFFFFFFL;
        }
        for (int i = 0; i < bs; i += 4) put32(b, 11 * bs + i, cs);
        return r;
    }

    private int nameHash(String n) {
        int h = 0;
        for (int i = 0; i < n.length(); i++) {
            int c = upcase[n.charAt(i)];
            h = (((h & 1) != 0 ? 0x8000 : 0) + (h >> 1) + (c & 0xFF)) & 0xFFFF;
            h = (((h & 1) != 0 ? 0x8000 : 0) + (h >> 1) + ((c >> 8) & 0xFF)) & 0xFFFF;
        }
        return h;
    }

    /** Escribe el conjunto de entradas de un archivo/carpeta en d (en la posición pos); devuelve los bytes usados. */
    private int putEntrySet(byte[] d, int pos, Node n) {
        int ne = nameEntries(n.name);
        int cnt = 1 + 1 + ne;
        byte[] e = new byte[32 * cnt];
        e[0] = (byte) 0x85;
        e[1] = (byte) (cnt - 1);
        put16(e, 4, n.dir ? 0x10 : 0x20);
        put32(e, 8, stamp & 0xFFFFFFFFL);
        put32(e, 12, stamp & 0xFFFFFFFFL);
        put32(e, 16, stamp & 0xFFFFFFFFL);
        e[22] = (byte) 0x80; e[23] = (byte) 0x80; e[24] = (byte) 0x80;
        e[32] = (byte) 0xC0;
        e[33] = 0x01;                                  // AllocationPossible, con cadena en la FAT
        e[35] = (byte) n.name.length();
        put16(e, 36, nameHash(n.name));
        long len = n.dir ? n.clusters * clBytes : n.size;
        put64(e, 40, len);
        put32(e, 52, n.first);
        put64(e, 56, len);
        for (int k = 0; k < ne; k++) {
            int o = 64 + 32 * k;
            e[o] = (byte) 0xC1;
            for (int j = 0; j < 15; j++) {
                int ci = k * 15 + j;
                if (ci < n.name.length()) put16(e, o + 2 + 2 * j, n.name.charAt(ci));
            }
        }
        int cs = 0;
        for (int i = 0; i < e.length; i++) {
            if (i == 2 || i == 3) continue;
            cs = (((cs & 1) != 0 ? 0x8000 : 0) + (cs >> 1) + (e[i] & 0xFF)) & 0xFFFF;
        }
        put16(e, 2, cs);
        System.arraycopy(e, 0, d, pos, e.length);
        return e.length;
    }

    private byte[] dirBytes(Node d) {
        byte[] b = new byte[(int) (d.clusters * clBytes)];
        int pos = 0;
        if (d == root) {
            b[0] = (byte) 0x83;
            int l = Math.min(11, label.length());
            b[1] = (byte) l;
            for (int i = 0; i < l; i++) put16(b, 2 + 2 * i, label.charAt(i));
            b[32] = (byte) 0x81;
            put32(b, 52, bitmapFirst);
            put64(b, 56, bitmapBytes);
            b[64] = (byte) 0x82;
            long ucs = 0;
            byte[] up = upBytes();
            for (int i = 0; i < up.length; i++) ucs = (((ucs & 1) != 0 ? 0x80000000L : 0) + (ucs >> 1) + (up[i] & 0xFF)) & 0xFFFFFFFFL;
            put32(b, 68, ucs);
            put32(b, 84, upFirst);
            put64(b, 88, 131072);
            pos = 96;
        }
        for (int i = 0; i < d.kids.size(); i++) pos += putEntrySet(b, pos, (Node) d.kids.elementAt(i));
        return b;
    }

    private byte[] upBytes() {
        byte[] up = new byte[131072];
        for (int i = 0; i < 65536; i++) put16(up, 2 * i, upcase[i]);
        return up;
    }

    public void write(Progress p) throws Exception {
        // región de arranque y su copia
        byte[] br = bootRegion();
        wrSectors(0, br);
        wrSectors(12, br);
        // FAT
        wrSectors(fatOffset, fat);
        // bitmap de asignación
        byte[] bm = new byte[(int) (bitmapClusters * clBytes)];
        long used = usedClusters();
        for (long i = 0; i < used; i++) bm[(int) (i / 8)] |= 1 << (i % 8);
        wrSectors(clusterSector(bitmapFirst), bm);
        // tabla de mayúsculas
        byte[] up = new byte[(int) (upClusters * clBytes)];
        System.arraycopy(upBytes(), 0, up, 0, 131072);
        wrSectors(clusterSector(upFirst), up);
        // directorios
        wrSectors(clusterSector(rootFirst), dirBytes(root));
        for (int i = 0; i < all.size(); i++) {
            Node n = (Node) all.elementAt(i);
            if (n.dir) wrSectors(clusterSector(n.first), dirBytes(n));
        }
        // datos
        ImageWriter w = new ImageWriter(dev, p, (int) (partStart + clusterSector(dataStart)));
        byte[] buf = new byte[32 * 2048];
        for (int i = 0; i < files.size(); i++) {
            Node f = (Node) files.elementAt(i);
            if (f.size == 0) continue;
            if (p != null) p.file(f.name);
            long off = 0;
            while (off < f.size) {
                if (p != null && p.cancelled()) throw new Exception("Cancelado");
                int n = iso.readAt(f.src, off, buf, (int) Math.min(buf.length, f.size - off));
                if (n <= 0) throw new Exception("No pude leer " + f.name + " de la ISO (en " + off + " de " + f.size + ")");
                w.write(buf, 0, n);
                off += n;
            }
            long pad = f.clusters * clBytes - f.size;
            while (pad > 0) {
                int k = (int) Math.min(pad, buf.length);
                byte[] z = new byte[k];
                w.write(z, 0, k);
                pad -= k;
            }
        }
        w.finish();
        dev.flush();
    }

    public void verify(Progress p) throws Exception {
        for (int i = 0; i < files.size(); i++) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            Node f = (Node) files.elementAt(i);
            if (f.size == 0) continue;
            long off = 0;
            byte[] exp = new byte[32 * 2048];
            while (off < f.size) {
                int want = (int) Math.min(exp.length, f.size - off);
                int n = iso.readAt(f.src, off, exp, want);
                if (n <= 0) throw new Exception("No pude releer " + f.name + " de la ISO");
                long lba = partStart + clusterSector(f.first) + off / bs;
                int skip = (int) (off % bs);
                int blocks = (skip + n + bs - 1) / bs;
                byte[] got = dev.read((int) lba, blocks);
                for (int k = 0; k < n; k++) {
                    if (got[skip + k] != exp[k]) throw new Exception("Contenido distinto en " + f.name + " (desplazamiento " + (off + k) + ")");
                }
                off += n;
                if (p != null) p.add(n);
            }
        }
    }
}
