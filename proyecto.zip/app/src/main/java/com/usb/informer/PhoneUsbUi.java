package com.usb.informer;

import java.util.Vector;
import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.StringItem;

/** Copia normal de archivos o carpetas del teléfono a un USB FAT12/16/32 que ya tiene datos (no borra nada). */
public class PhoneUsbUi implements CommandListener {
    private final Display display;
    private UsbBackend backend;
    private UsbExtras x;
    private Displayable ret;
    private Vector items;
    private String what;
    private List devList;
    private Vector devChoices = new Vector();
    private Form confirm, working, note, result;
    private StringItem status;
    private Displayable noteNext;
    private Command backCmd = new Command("Atrás", Command.BACK, 1);
    private Command okCmd = new Command("Aceptar", Command.OK, 1);
    private Command copyCmd = new Command("Copiar al USB (omite los que ya existen)", Command.OK, 1);
    private Command copyVerCmd = new Command("Copiar y VERIFICAR", Command.SCREEN, 2);
    private Command replCmd = new Command("Copiar REEMPLAZANDO los existentes", Command.SCREEN, 3);
    private Command replVerCmd = new Command("Reemplazar y VERIFICAR", Command.SCREEN, 4);
    private Command homeCmd = new Command("Seguir", Command.OK, 1);

    private OpticalDisc tgt;
    private FsAdd fa;
    private PhoneTree tree;
    private long[] plan;
    private UsbDevInfo target;
    private volatile boolean cancel, running;
    private long done, total, last, startMs;

    public PhoneUsbUi(Display d) {
        display = d;
    }

    public void setBackend(UsbBackend b, UsbExtras e) {
        backend = b;
        x = e;
    }

    private static String msg(Throwable t) {
        String m = t.getMessage();
        return m != null && m.length() > 0 ? m : t.toString();
    }

    private static String size(long b) { return Phone.sizeText(b); }

    private void showNote(String title, String text, Displayable next) {
        note = new Form(title);
        note.append(new StringItem(null, text));
        note.addCommand(okCmd);
        note.setCommandListener(this);
        noteNext = next;
        display.setCurrent(note);
    }

    private void closeDisc() {
        if (tgt != null) try { tgt.close(); } catch (Throwable t) { }
        tgt = null;
        fa = null;
    }

    /** items: FileItem con ref = java.io.File. what: texto para mostrar (carpeta o archivo). */
    public void start(Vector its, String desc, Displayable back) {
        if (x == null || backend == null) return;
        ret = back;
        items = its;
        what = desc;
        if (running) {
            showNote("Copiar al USB", "Ya hay una copia en marcha.", back);
            return;
        }
        devChoices.removeAllElements();
        devList = new List("¿A qué USB copiar?", Choice.IMPLICIT);
        Vector devs = backend.getDevices();
        for (int i = 0; i < devs.size(); i++) {
            UsbDevInfo d = (UsbDevInfo) devs.elementAt(i);
            if (!d.mass || d.optical) continue;
            devChoices.addElement(d);
            devList.append(d.label() + (d.needsPermission ? " (sin permiso USB)" : ""), null);
        }
        if (devChoices.size() == 0) {
            showNote("Copiar al USB", "No hay ningún USB de almacenamiento conectado.", back);
            return;
        }
        devList.addCommand(backCmd);
        devList.setCommandListener(this);
        display.setCurrent(devList);
    }

    private void choose(int i) {
        if (i < 0 || i >= devChoices.size()) return;
        target = (UsbDevInfo) devChoices.elementAt(i);
        if (target.needsPermission) {
            showNote("Copiar al USB", "Primero concede el permiso USB a ese dispositivo (menú principal: Pedir permiso USB).", devList);
            return;
        }
        FtpUi.stopFtpIfUsb();   // el USB debe quedar libre para escribir
        final Form busy = new Form("Copiar al USB");
        busy.append("Abriendo el USB y leyendo su contenido...");
        display.setCurrent(busy);
        new Thread(new Runnable() {
            public void run() {
                try {
                    closeDisc();
                    tgt = x.openDisc(target, false);
                    fa = FsAdd.open(tgt);
                    tree = new PhoneTree(items, "Teléfono");
                    cancel = false;
                    Progress p = new Progress() {
                        public boolean cancelled() { return cancel; }
                        public void add(long n) { }
                        public void file(String s) { }
                    };
                    fa.skipped.removeAllElements();
                    plan = fa.plan(items, tree, p);
                    showConfirm();
                } catch (Throwable t) {
                    closeDisc();
                    showNote("Copiar al USB", msg(t), devList);
                }
            }
        }).start();
    }

    private void showConfirm() {
        long needBytes = (plan[3] + 8) * fa.clusterBytes();
        boolean fits = needBytes <= fa.freeBytes();
        StringBuffer sb = new StringBuffer();
        sb.append("DESTINO (NO se borra nada, se AÑADE):\n").append(target.label()).append("\n");
        sb.append("Sistema: ").append(fa.typeName()).append(fa.label.length() > 0 ? "  \"" + fa.label + "\"" : "").append("\n");
        sb.append("Espacio libre: ").append(size(fa.freeBytes())).append("\n");
        if (fa.partCount > 1) sb.append("Hay ").append(fa.partCount).append(" particiones escribibles; se usa la que tiene más espacio libre.\n");
        sb.append("\nORIGEN: ").append(what).append("\n");
        sb.append(plan[0]).append(" archivos en ").append(plan[1]).append(" carpetas, ").append(size(plan[2])).append("\n\n");
        if (!fits) {
            sb.append("NO CABE: hacen falta unos ").append(size(needBytes)).append(" (con el espacio que ocupan los clusters).\n\n");
        }
        if (fa.skipped.size() > 0) {
            sb.append("NO SE COPIARÁN ").append(fa.skipped.size()).append(":\n");
            for (int i = 0; i < fa.skipped.size() && i < 6; i++) sb.append("- ").append((String) fa.skipped.elementAt(i)).append("\n");
            sb.append("\n");
        }
        sb.append("Si ya existe un archivo con el mismo nombre:\n"
                + "- \"Copiar al USB\": se deja el del USB.\n"
                + "- \"Copiar REEMPLAZANDO\": se borra el del USB y se escribe el nuevo (si se interrumpe, ese archivo se pierde).\n"
                + "Las carpetas con el mismo nombre se combinan.\n\n"
                + "No desconectes el USB ni cierres la app mientras copia.");
        confirm = new Form("Confirmar copia");
        confirm.append(new StringItem(null, sb.toString()));
        if (fits && plan[0] + plan[1] > 0) {
            confirm.addCommand(copyCmd);
            confirm.addCommand(copyVerCmd);
            confirm.addCommand(replCmd);
            confirm.addCommand(replVerCmd);
        }
        confirm.addCommand(backCmd);
        confirm.setCommandListener(this);
        display.setCurrent(confirm);
    }

    private void startCopy(final boolean verify, final boolean replace) {
        cancel = false;
        running = true;
        done = 0;
        total = Math.max(1, plan[2]);
        startMs = System.currentTimeMillis();
        last = 0;
        OpStatus.begin("Copiando al USB: " + what);
        working = new Form("Copiando al USB");
        status = new StringItem(null, "Empezando...");
        working.append(status);
        working.addCommand(backCmd);
        working.setCommandListener(this);
        display.setCurrent(working);
        try { display.flashBacklight(8000); } catch (Throwable t) { }
        final Form mine = working;
        final FsAdd f = fa;
        f.skipped.removeAllElements();
        new Thread(new Runnable() {
            public void run() {
                String m;
                boolean good = false;
                Progress p = new Progress() {
                    String cur = "";
                    long lightT;

                    public boolean cancelled() { return cancel; }

                    public void file(String n) { cur = n; }

                    public void add(long n) {
                        done += n;
                        long now = System.currentTimeMillis();
                        if (now - lightT > 3000) {
                            lightT = now;
                            try { display.flashBacklight(8000); } catch (Throwable t) { }
                        }
                        if (now - last > 500) {
                            last = now;
                            long secs = (now - startMs) / 1000 + 1;
                            long pct = done * 100 / total;
                            status.setText((cur.length() > 0 ? cur + "\n" : "") + pct + " %  (" + size(done) + " de " + size(total) + ")\n"
                                    + size(done / secs) + "/s\n\n(Atrás = cancelar)");
                            OpStatus.progress(size(done) + " de " + size(total) + "  ·  " + size(done / secs) + "/s", done, total);
                        }
                    }
                };
                try {
                    f.overwrite = replace;
                    f.addTree(items, tree, p, verify);
                    m = "Copiado al USB: " + f.files + " archivos y " + f.dirs + " carpetas nuevas (" + size(f.bytes) + ")"
                            + (verify ? ", VERIFICADO." : ".");
                    if (f.replaced > 0) m += "\nReemplazados " + f.replaced + " archivos que ya existían.";
                    good = true;
                } catch (Throwable t) {
                    m = cancel ? "Copia cancelada. Lo ya copiado queda en el USB (" + f.files + " archivos)."
                            : "Error: " + msg(t) + "\n\nLo ya copiado queda en el USB (" + f.files + " archivos).";
                }
                if (f.skipped.size() > 0) {
                    m += "\n\nNo copiados (" + f.skipped.size() + "):";
                    for (int i = 0; i < f.skipped.size() && i < 10; i++) m += "\n- " + (String) f.skipped.elementAt(i);
                }
                if (good) m += "\n\nAntes de quitar el USB, expúlsalo desde su menú (Expulsar / quitar con seguridad).";
                running = false;
                try { tree.close(); } catch (Throwable t) { }
                closeDisc();
                String first = m;
                int nl = first.indexOf('\n');
                if (nl > 0) first = first.substring(0, nl);
                OpStatus.end(good ? OpStatus.OK : (cancel ? OpStatus.CANCEL : OpStatus.FAIL), first.length() > 110 ? first.substring(0, 110) + "..." : first);
                result = new Form(good ? "Copia terminada" : "Copia no completada");
                result.append(new StringItem(null, m));
                result.addCommand(homeCmd);
                result.setCommandListener(PhoneUsbUi.this);
                display.setCurrent(result);
            }
        }).start();
    }

    public void commandAction(Command c, Displayable d) {
        if (d == note) {
            display.setCurrent(noteNext != null ? noteNext : ret);
        } else if (d == devList) {
            if (c == backCmd) display.setCurrent(ret);
            else choose(devList.getSelectedIndex());
        } else if (d == confirm) {
            if (c == copyCmd) startCopy(false, false);
            else if (c == copyVerCmd) startCopy(true, false);
            else if (c == replCmd) startCopy(false, true);
            else if (c == replVerCmd) startCopy(true, true);
            else {
                closeDisc();
                display.setCurrent(devList != null ? (Displayable) devList : ret);
            }
        } else if (d == working) {
            if (c == backCmd) cancel = true;   // la hebra de copia muestra el resultado al parar
        } else if (d == result) {
            display.setCurrent(ret);
        }
    }
}
