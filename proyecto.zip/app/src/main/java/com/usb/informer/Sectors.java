package com.usb.informer;
/** Algo que se puede leer por sectores: un disco, o una imagen ISO que está dentro de un archivo. */
public interface Sectors {
    int sectorSize();

    byte[] read(int lba, int count) throws Exception;
}
