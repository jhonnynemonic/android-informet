package com.usb.informer;
import java.io.OutputStream;

/** Imagen guardada como archivo dentro de una fuente de archivos (teléfono, otro USB, CD). */
public class FsImage implements ImageSource {
    private FileSource fs;
    private FileItem item;

    public FsImage(FileSource fs, FileItem item) {
        this.fs = fs;
        this.item = item;
    }

    public String name() { return item.name; }

    public long size() { return item.size; }

    public void pump(OutputStream out, Progress p) throws Exception {
        fs.copy(item, out, p);
    }
}
