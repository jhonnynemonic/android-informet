package com.usb.informer;

import java.util.Vector;

/** Añadir archivos a un USB que ya tiene datos, sin formatear. Implementaciones: FAT12/16/32, exFAT y ext2/ext3. */
public abstract class FsAdd {
    public String label = "";
    public int files, dirs, partCount;
    public long bytes;
    public Vector skipped = new Vector();

    /** Motivo por el que un sistema de archivos reconocido no se puede escribir (se muestra tal cual). */
    public static class Refuse extends Exception {
        public Refuse(String m) { super(m); }
    }

    public abstract String typeName();

    public abstract long freeBytes();

    public abstract long clusterBytes();

    /** Tamaño máximo de un archivo en este sistema. */
    protected abstract long maxFile();

    public abstract void addTree(Vector items, DiscTree t, Progress p, boolean verify) throws Exception;

    /** Abre el sistema de archivos escribible del USB (FAT, exFAT o ext2/ext3). Si hay varios, usa el que tenga más espacio libre. */
    public static FsAdd open(OpticalDisc d) throws Exception {
        Vector cands = new Vector();
        cands.addElement(new Long(0));
        Vector parts = UsbVolume.partitionLbas(d);
        for (int i = 0; i < parts.size(); i++) cands.addElement(parts.elementAt(i));
        Vector found = new Vector();
        String other = null, refuse = null;
        for (int i = 0; i < cands.size(); i++) {
            long lba = ((Long) cands.elementAt(i)).longValue();
            FsAdd f = null;
            try {
                f = FatAdd.tryOpen(d, lba);
                if (f == null) f = ExFatAdd.tryOpen(d, lba);
                if (f == null) f = ExtAdd.tryOpen(d, lba);
            } catch (Refuse r) {
                if (refuse == null) refuse = r.getMessage();
                f = null;
            } catch (Throwable t) {
                f = null;
            }
            if (f != null) {
                found.addElement(f);
            } else if (other == null) {
                BlockFs m = UsbVolume.tryMount(d, lba);
                if (m != null) other = m.typeName();
            }
        }
        if (found.size() == 0) {
            if (refuse != null) throw new Exception(refuse);
            if (other != null) {
                throw new Exception("Este USB está en " + other + ". Solo se puede añadir archivos a USB en FAT12, FAT16, FAT32, exFAT, ext2 o ext3 "
                        + "(los demás, de momento, solo se leen).");
            }
            throw new Exception("No reconozco un sistema FAT, exFAT ni ext2/ext3 en este USB.");
        }
        FsAdd best = (FsAdd) found.elementAt(0);
        for (int i = 1; i < found.size(); i++) {
            FsAdd f = (FsAdd) found.elementAt(i);
            if (f.freeBytes() > best.freeBytes()) best = f;
        }
        best.partCount = found.size();
        return best;
    }

    /** {archivos, carpetas, bytes, clusters necesarios}. Los archivos demasiado grandes se anotan en skipped. */
    public long[] plan(Vector items, DiscTree t, Progress p) throws Exception {
        long[] r = new long[4];
        planWalk(items, t, "", r, p);
        return r;
    }

    /** Bloques que ocupa un archivo de ese tamaño (los sistemas con bloques de índice suman los suyos). */
    protected long fileClusters(long size) {
        long cb = clusterBytes();
        return (size + cb - 1) / cb;
    }

    private void planWalk(Vector items, DiscTree t, String path, long[] r, Progress p) throws Exception {
        long cb = clusterBytes();
        for (int i = 0; i < items.size(); i++) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            FileItem it = (FileItem) items.elementAt(i);
            if (it.dir) {
                r[1]++;
                r[3]++;
                planWalk(t.list(it), t, path + it.name + "/", r, p);
            } else if (it.size > maxFile()) {
                skipped.addElement(path + it.name + " (demasiado grande para " + typeName() + ")");
            } else {
                r[0]++;
                r[2] += it.size;
                r[3] += fileClusters(it.size);
            }
        }
    }
}
