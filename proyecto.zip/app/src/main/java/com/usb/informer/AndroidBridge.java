package com.usb.informer;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** Ayudas de reflexión para hablar con las clases de Android desde el MIDlet. */
public class AndroidBridge {

    public static Object call(Object target, String cls, String method, Class[] types, Object[] args) throws Exception {
        Method m = Class.forName(cls).getMethod(method, types);
        try {
            return m.invoke(target, args);
        } catch (InvocationTargetException e) {
            Throwable t = e.getTargetException();
            if (t instanceof Exception) throw (Exception) t;
            throw e;
        }
    }

    public static Object call0(Object target, String cls, String method) throws Exception {
        return call(target, cls, method, new Class[0], new Object[0]);
    }

    public static Object callStatic(String cls, String method, Class[] types, Object[] args) throws Exception {
        return call(null, cls, method, types, args);
    }

    public static Object callStatic0(String cls, String method) throws Exception {
        return call(null, cls, method, new Class[0], new Object[0]);
    }

    public static int num(Object o) {
        return (o instanceof Number) ? ((Number) o).intValue() : 0;
    }

    public static boolean bool(Object o) {
        return (o instanceof Boolean) && ((Boolean) o).booleanValue();
    }

    public static String str(Object o) {
        return o == null ? null : o.toString();
    }

    public static Integer i(int v) {
        return new Integer(v);
    }

    /** Contexto de Android (de J2ME Loader o de la aplicación en curso), o null. */
    /** Contexto fijado por la aplicación Android (MainActivity). */
    public static volatile Object appContext;

    public static Object context() {
        if (appContext != null) return appContext;
        String[][] tries = {
            { "javax.microedition.util.ContextHolder", "getAppContext" },
            { "javax.microedition.util.ContextHolder", "getApplicationContext" },
            { "android.app.ActivityThread", "currentApplication" },
            { "android.app.AppGlobals", "getInitialApplication" },
            { "javax.microedition.util.ContextHolder", "getActivity" }
        };
        for (int k = 0; k < tries.length; k++) {
            try {
                Object o = callStatic0(tries[k][0], tries[k][1]);
                if (o != null) return o;
            } catch (Throwable t) {
                // probamos el siguiente
            }
        }
        return null;
    }
}
