package com.usb.informer;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 * Backend JSR-80 (javax.usb). Todo se hace por reflexión para que el MIDlet
 * no dependa de javax.usb al compilar ni al instalarse: si la API no existe,
 * esta clase simplemente no se carga.
 */
public class Jsr80Backend implements UsbBackend {
    private static final String P = "javax.usb.";
    private Object services;
    private UsbListener listener;
    private Object proxy;

    public String getName() { return "JSR-80 (USB real)"; }

    public String start(UsbListener l) {
        listener = l;
        try {
            Class hm = Class.forName(P + "UsbHostManager");
            Method m = hm.getMethod("getUsbServices", new Class[0]);
            services = m.invoke(null, new Object[0]);

            Class li = Class.forName(P + "event.UsbServicesListener");
            proxy = Proxy.newProxyInstance(li.getClassLoader(), new Class[] { li }, new Handler());
            Class us = Class.forName(P + "UsbServices");
            us.getMethod("addUsbServicesListener", new Class[] { li }).invoke(services, new Object[] { proxy });
            return null;
        } catch (Throwable t) {
            services = null;
            return why(t);
        }
    }

    public void stop() {
        try {
            if (services != null && proxy != null) {
                Class li = Class.forName(P + "event.UsbServicesListener");
                Class us = Class.forName(P + "UsbServices");
                us.getMethod("removeUsbServicesListener", new Class[] { li }).invoke(services, new Object[] { proxy });
            }
        } catch (Throwable t) {
            // nada que hacer
        }
        listener = null;
    }

    public Vector getDevices() {
        Vector out = new Vector();
        if (services == null) return out;
        try {
            Object root = call(services, "UsbServices", "getRootUsbHub");
            collect(root, out);
        } catch (Throwable t) {
            // devolvemos lo que haya
        }
        return out;
    }

    private void collect(Object hub, Vector out) throws Exception {
        List list = (List) call(hub, "UsbHub", "getAttachedUsbDevices");
        for (Iterator it = list.iterator(); it.hasNext();) {
            Object dev = it.next();
            out.addElement(describe(dev));
            if (isTrue(call(dev, "UsbDevice", "isUsbHub"))) collect(dev, out);
        }
    }

    private UsbDevInfo describe(Object dev) {
        UsbDevInfo i = new UsbDevInfo();
        try {
            Object dd = call(dev, "UsbDevice", "getUsbDeviceDescriptor");
            i.vendorId = num(call(dd, "UsbDeviceDescriptor", "idVendor")) & 0xFFFF;
            i.productId = num(call(dd, "UsbDeviceDescriptor", "idProduct")) & 0xFFFF;
            i.version = UsbUtil.bcdVersion(num(call(dd, "UsbDeviceDescriptor", "bcdDevice")) & 0xFFFF);
            i.devClass = num(call(dd, "UsbDeviceDescriptor", "bDeviceClass")) & 0xFF;
            i.subClass = num(call(dd, "UsbDeviceDescriptor", "bDeviceSubClass")) & 0xFF;
            i.protocol = num(call(dd, "UsbDeviceDescriptor", "bDeviceProtocol")) & 0xFF;
        } catch (Throwable t) {
            i.version = "?";
        }
        i.deviceName = "javax.usb:" + UsbUtil.hex(i.vendorId, 4).substring(2) + ":" + UsbUtil.hex(i.productId, 4).substring(2);
        i.id = (i.vendorId << 16) | i.productId;
        i.manufacturer = str(dev, "getManufacturerString");
        i.productName = str(dev, "getProductString");
        i.serial = str(dev, "getSerialNumberString");
        try {
            Object cfg = call(dev, "UsbDevice", "getActiveUsbConfiguration");
            if (cfg != null) i.configs.addElement(describeConfig(cfg));
        } catch (Throwable t) {
            // sin configuración legible
        }
        return i;
    }

    private UsbNode describeConfig(Object cfg) throws Exception {
        Object cd = call(cfg, "UsbConfiguration", "getUsbConfigurationDescriptor");
        UsbNode cn = UsbUtil.configNode(
                num(call(cd, "UsbConfigurationDescriptor", "bConfigurationValue")) & 0xFF,
                num(call(cd, "UsbConfigurationDescriptor", "bNumInterfaces")) & 0xFF,
                num(call(cd, "UsbConfigurationDescriptor", "bmAttributes")) & 0xFF,
                num(call(cd, "UsbConfigurationDescriptor", "bMaxPower")) & 0xFF);
        List ifs = (List) call(cfg, "UsbConfiguration", "getUsbInterfaces");
        for (Iterator it = ifs.iterator(); it.hasNext();) {
            Object ui = it.next();
            Object id = call(ui, "UsbInterface", "getUsbInterfaceDescriptor");
            UsbNode in = UsbUtil.interfaceNode(
                    num(call(id, "UsbInterfaceDescriptor", "bInterfaceNumber")) & 0xFF,
                    num(call(id, "UsbInterfaceDescriptor", "bAlternateSetting")) & 0xFF,
                    num(call(id, "UsbInterfaceDescriptor", "bInterfaceClass")) & 0xFF,
                    num(call(id, "UsbInterfaceDescriptor", "bInterfaceSubClass")) & 0xFF,
                    num(call(id, "UsbInterfaceDescriptor", "bInterfaceProtocol")) & 0xFF,
                    num(call(id, "UsbInterfaceDescriptor", "bNumEndpoints")) & 0xFF);
            List eps = (List) call(ui, "UsbInterface", "getUsbEndpoints");
            for (Iterator e = eps.iterator(); e.hasNext();) {
                Object ue = e.next();
                Object ed = call(ue, "UsbEndpoint", "getUsbEndpointDescriptor");
                in.add(UsbUtil.endpointNode(
                        num(call(ed, "UsbEndpointDescriptor", "bEndpointAddress")) & 0xFF,
                        num(call(ed, "UsbEndpointDescriptor", "bmAttributes")) & 0xFF,
                        num(call(ed, "UsbEndpointDescriptor", "wMaxPacketSize")) & 0xFFFF,
                        num(call(ed, "UsbEndpointDescriptor", "bInterval")) & 0xFF));
            }
            cn.add(in);
        }
        return cn;
    }

    private String str(Object dev, String method) {
        try {
            Object o = call(dev, "UsbDevice", method);
            return o == null ? null : o.toString();
        } catch (Throwable t) {
            return null;
        }
    }

    private static Object call(Object target, String iface, String method) throws Exception {
        Class c = Class.forName(P + iface);
        Method m = c.getMethod(method, new Class[0]);
        try {
            return m.invoke(target, new Object[0]);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getTargetException();
            if (cause instanceof Exception) throw (Exception) cause;
            throw e;
        }
    }

    private static int num(Object o) {
        return (o instanceof Number) ? ((Number) o).intValue() : 0;
    }

    private static boolean isTrue(Object o) {
        return (o instanceof Boolean) && ((Boolean) o).booleanValue();
    }

    private static String why(Throwable t) {
        if (t instanceof InvocationTargetException && ((InvocationTargetException) t).getTargetException() != null) {
            t = ((InvocationTargetException) t).getTargetException();
        }
        return t.toString();
    }

    /** Recibe los eventos de conexión y desconexión de javax.usb. */
    private class Handler implements InvocationHandler {
        public Object invoke(Object p, Method m, Object[] args) throws Throwable {
            String n = m.getName();
            if (n.equals("usbDeviceAttached") || n.equals("usbDeviceDetached")) {
                try {
                    Object dev = call(args[0], "event.UsbServicesEvent", "getUsbDevice");
                    UsbDevInfo info = describe(dev);
                    UsbListener l = listener;
                    if (l != null) {
                        if (n.equals("usbDeviceAttached")) l.deviceAttached(info);
                        else l.deviceDetached(info);
                    }
                } catch (Throwable t) {
                    // evento ilegible: se ignora
                }
                return null;
            }
            if (n.equals("hashCode")) return new Integer(System.identityHashCode(p));
            if (n.equals("equals")) return (args[0] == p) ? Boolean.TRUE : Boolean.FALSE;
            if (n.equals("toString")) return "Jsr80Listener";
            return null;
        }
    }
}
