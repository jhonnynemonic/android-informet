package com.usb.informer;
/**
 * Disco virtual a partir de un archivo VHD (fijo o dinámico) que está en el teléfono, en otro USB o en un FTP.
 * Se comporta como un disco de 512 bytes por sector, así que se monta con UsbVolume como cualquier USB
 * (particiones MBR/GPT, FAT, exFAT, NTFS). Solo lectura. No admite VHD diferenciales ni VHDX.
 */
public class VhdDisc extends OpticalDisc {
    private WindowSectors src;
    private long fileSize, vsize;
    private int type;
    private long blockSz, bmp;
    private int[] bat;
    public String kind = "";

    public VhdDisc(Sectors s) throws Exception {
        super(null, null);
        if (!(s instanceof WindowSectors)) throw new Exception("Origen no válido para un VHD");
        src = (WindowSectors) s;
        fileSize = src.length();
        blockSize = 512;
        byte[] h = src.readSlot(0, 8, 0);
        if (h[0] == 'v' && h[1] == 'h' && h[2] == 'd' && h[3] == 'x' && h[4] == 'f') {
            throw new Exception("Es un VHDX (formato nuevo de Windows). De momento solo leo VHD (fijo o dinámico).");
        }
        byte[] f = null;
        if (fileSize >= 512) f = src.readSlot(fileSize - 512, 512, 0);
        if (f == null || !cookie(f, 0, "conectix")) {
            byte[] f0 = src.readSlot(0, 512, 0);
            if (!cookie(f0, 0, "conectix")) throw new Exception("No parece un archivo VHD (no veo la firma 'conectix').");
            f = f0;
        }
        vsize = be64(f, 48);
        type = (int) be32(f, 60);
        if (vsize <= 0) throw new Exception("VHD con tamaño no válido");
        if (type == 2) {
            kind = "fijo";
            if (fileSize < vsize) throw new Exception("VHD fijo incompleto: el archivo mide menos que el disco (" + fileSize + " < " + vsize + ")");
        } else if (type == 3) {
            kind = "dinámico";
            long ho = be64(f, 16);
            byte[] hd = src.readSlot(ho, 1024, 0);
            if (!cookie(hd, 0, "cxsparse")) throw new Exception("VHD dinámico con cabecera dañada");
            long to = be64(hd, 16);
            int n = (int) be32(hd, 28);
            blockSz = be32(hd, 32);
            if (n <= 0 || n > 4000000 || blockSz < 512 || blockSz > (256L << 20)) throw new Exception("VHD dinámico con datos no válidos");
            bmp = ((blockSz / 512 + 7) / 8 + 511) / 512 * 512;
            byte[] t = src.readSlot(to, n * 4, 0);
            bat = new int[n];
            for (int i = 0; i < n; i++) bat[i] = (int) be32(t, i * 4);
            if ((vsize + blockSz - 1) / blockSz > n) throw new Exception("VHD dinámico: la tabla de bloques es más corta que el disco");
        } else if (type == 4) {
            throw new Exception("Es un VHD diferencial (necesita un VHD padre). No está soportado.");
        } else {
            throw new Exception("Tipo de VHD desconocido (" + type + ")");
        }
        blocks = (int) Math.min(vsize / 512, (long) Integer.MAX_VALUE);
        vendor = "VHD";
        product = kind;
    }

    public long virtualSize() { return vsize; }

    /** Tabla de particiones del disco virtual: "GPT", "MBR" o "NONE" (sistema de archivos directo, sin particiones). */
    public String style() {
        try {
            if (UsbVolume.tryMount(this, 0) != null) return "NONE";
            byte[] s0 = read(0, 1);
            if ((s0[510] & 0xFF) != 0x55 || (s0[511] & 0xFF) != 0xAA) return "NONE";
            boolean any = false;
            for (int i = 0; i < 4; i++) {
                int t = s0[446 + 16 * i + 4] & 0xFF;
                if (t == 0) continue;
                if (t == 0xEE) {
                    byte[] h = read(1, 1);
                    if (h[0] == 'E' && h[1] == 'F' && h[2] == 'I' && h[3] == ' ' && h[4] == 'P') return "GPT";
                }
                any = true;
            }
            return any ? "MBR" : "NONE";
        } catch (Throwable t) {
            return "NONE";
        }
    }

    public void open() { }

    public void open(boolean optical) { }

    public void close() { }

    public synchronized byte[] read(int lba, int count) throws Exception {
        int len = count * 512;
        byte[] out = new byte[len];
        long voff = (long) lba * 512;
        int slot = len <= 32768 ? 2 : 1;       // metadatos (FAT, carpetas) y datos usan ventanas distintas
        int got = 0;
        while (got < len && voff + got < vsize) {
            long o = voff + got;
            int n = (int) Math.min(len - got, vsize - o);
            if (type == 2) {
                byte[] b = src.readSlot(o, n, slot);
                System.arraycopy(b, 0, out, got, n);
            } else {
                long idx = o / blockSz;
                int in = (int) (o % blockSz);
                n = (int) Math.min(n, blockSz - in);
                int ent = bat[(int) idx];
                if (ent != -1) {
                    byte[] b = src.readSlot((ent & 0xFFFFFFFFL) * 512 + bmp + in, n, slot);
                    System.arraycopy(b, 0, out, got, n);
                }
            }
            got += n;
        }
        return out;
    }

    private static boolean cookie(byte[] b, int o, String c) {
        for (int i = 0; i < c.length(); i++) if (b[o + i] != (byte) c.charAt(i)) return false;
        return true;
    }

    private static long be32(byte[] b, int o) {
        return ((b[o] & 0xFFL) << 24) | ((b[o + 1] & 0xFFL) << 16) | ((b[o + 2] & 0xFFL) << 8) | (b[o + 3] & 0xFFL);
    }

    private static long be64(byte[] b, int o) {
        return (be32(b, o) << 32) | be32(b, o + 4);
    }
}
