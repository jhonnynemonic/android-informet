package com.usb.informer;

/** Estado global de la operación en curso, que se muestra en una barra fija arriba de todas las pantallas. */
public final class OpStatus {
    public static final int IDLE = 0, RUNNING = 1, OK = 2, FAIL = 3, CANCEL = 4;

    public static volatile int state = IDLE;
    public static volatile String title = "";
    public static volatile String detail = "";
    public static volatile int percent = -1;   // -1 = indeterminado
    public static volatile long startMs, endMs;
    /** La UI se registra aquí; se llama (desde cualquier hilo) cada vez que cambia algo. */
    public static volatile Runnable listener;

    private static long lastNotify;

    private OpStatus() { }

    public static void begin(String what) {
        title = what;
        detail = "Empezando...";
        percent = -1;
        startMs = System.currentTimeMillis();
        endMs = 0;
        state = RUNNING;
        notifyUi(true);
    }

    /** Cambia el texto de la fase sin tocar el porcentaje (p. ej. "Verificando..."). */
    public static void phase(String what) {
        if (state != RUNNING) return;
        title = what;
        notifyUi(true);
    }

    public static void progress(String text, long done, long total) {
        if (state != RUNNING) return;
        percent = total > 0 ? (int) Math.min(100, done * 100 / total) : -1;
        detail = text;
        notifyUi(false);
    }

    public static void detail(String text) {
        if (state != RUNNING) return;
        detail = text;
        notifyUi(false);
    }

    /** Termina la operación. result: OK, FAIL o CANCEL. */
    public static void end(int result, String text) {
        if (state != RUNNING) return;
        detail = text == null ? "" : text;
        if (result == OK) percent = 100;
        endMs = System.currentTimeMillis();
        state = result;
        notifyUi(true);
    }

    public static void dismiss() {
        if (state == RUNNING) return;
        state = IDLE;
        notifyUi(true);
    }

    public static String elapsed() {
        long e = (endMs != 0 ? endMs : System.currentTimeMillis()) - startMs;
        long s = e / 1000;
        return s >= 3600 ? (s / 3600) + " h " + (s / 60 % 60) + " min " + (s % 60) + " s"
                : s >= 60 ? (s / 60) + " min " + (s % 60) + " s" : s + " s";
    }

    private static void notifyUi(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - lastNotify < 400) return;
        lastNotify = now;
        Runnable r = listener;
        if (r != null) try { r.run(); } catch (Throwable t) { }
    }
}
