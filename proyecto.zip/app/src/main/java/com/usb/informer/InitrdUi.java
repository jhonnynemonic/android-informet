package com.usb.informer;

import java.io.OutputStream;
import java.util.Calendar;
import java.util.Vector;
import java.util.zip.GZIPOutputStream;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.StringItem;
import javax.microedition.lcdui.TextField;

/**
 * Convierte el contenido de un USB ext2/ext3/ext4 en un initrd: archivo cpio (newc) comprimido con gzip, con permisos,
 * propietarios, enlaces simbólicos y dispositivos. Solo LEE el USB; el archivo se guarda en Descargas/USB-Informer.
 */
public class InitrdUi implements CommandListener {
    private Display display;
    private UsbExtras x;
    private Displayable ret;
    private UsbDevInfo dev;

    private Command backCmd = new Command("Atrás", Command.BACK, 1);
    private Command okCmd = new Command("Aceptar", Command.OK, 1);
    private Command startCmd = new Command("Crear initrd", Command.OK, 1);

    private Form busy, info, working, result, note;
    private TextField nameField;
    private StringItem status;
    private Displayable noteNext;
    private OpticalDisc disc;
    private ExtFs fs;
    private int extCount;
    private volatile boolean cancel;
    private volatile boolean running;
    private long done, total, last, startMs;
    private String curFile = "";

    public InitrdUi(Display d) {
        display = d;
    }

    public void setBackend(UsbExtras e) {
        x = e;
    }

    private static String msg(Throwable t) {
        String m = t.getMessage();
        return m != null && m.length() > 0 ? m : t.toString();
    }

    private static String size(long n) {
        return Phone.sizeText(n);
    }

    private void showNote(String title, String text, Displayable next) {
        note = new Form(title);
        note.append(new StringItem(null, text));
        note.addCommand(okCmd);
        note.setCommandListener(this);
        noteNext = next;
        display.setCurrent(note);
    }

    private void closeDisc() {
        if (disc != null) {
            try { disc.close(); } catch (Throwable t) { }
        }
        disc = null;
        fs = null;
    }

    private static String two(int v) {
        return v < 10 ? "0" + v : "" + v;
    }

    private static String defaultName() {
        Calendar c = Calendar.getInstance();
        return "initrd-usb-" + c.get(Calendar.YEAR) + two(c.get(Calendar.MONTH) + 1) + two(c.get(Calendar.DAY_OF_MONTH))
                + "-" + two(c.get(Calendar.HOUR_OF_DAY)) + two(c.get(Calendar.MINUTE)) + ".cpio.gz";
    }

    public void start(UsbDevInfo d, Displayable back) {
        if (x == null) return;
        if (running) {
            showNote("Crear initrd", "Ya hay una operación en curso.", back);
            return;
        }
        ret = back;
        dev = d;
        closeDisc();
        if (d.needsPermission) {
            showNote("Crear initrd", "Primero concede el permiso USB a este dispositivo (menú principal: Pedir permiso USB).", back);
            return;
        }
        busy = new Form("Crear initrd");
        busy.append("Abriendo el USB y buscando un sistema ext...");
        busy.addCommand(backCmd);
        busy.setCommandListener(this);
        final Form mine = busy;
        display.setCurrent(busy);
        new Thread(new Runnable() {
            public void run() {
                try {
                    OpticalDisc dd = x.openDisc(dev, false);
                    if (display.getCurrent() != mine) {
                        dd.close();
                        return;
                    }
                    disc = dd;
                    Vector cands = new Vector();
                    cands.addElement(new Long(0));
                    Vector parts = UsbVolume.partitionLbas(dd);
                    for (int i = 0; i < parts.size(); i++) cands.addElement(parts.elementAt(i));
                    ExtFs best = null;
                    extCount = 0;
                    for (int i = 0; i < cands.size(); i++) {
                        try {
                            ExtFs e = new ExtFs(dd, ((Long) cands.elementAt(i)).longValue());
                            extCount++;
                            if (best == null || e.usedBytes() > best.usedBytes()) best = e;
                        } catch (Throwable t) {
                            // esa partición no es ext
                        }
                    }
                    if (best == null) {
                        closeDisc();
                        showNote("Crear initrd", "Este USB no tiene un sistema de archivos ext2/ext3/ext4. "
                                + "Esta opción convierte en initrd el contenido de un USB ext.", ret);
                        return;
                    }
                    fs = best;
                    showInfo();
                } catch (Throwable t) {
                    closeDisc();
                    showNote("Crear initrd", "No puedo abrir el USB: " + msg(t), ret);
                }
            }
        }).start();
    }

    private void showInfo() {
        info = new Form("Crear initrd");
        StringBuffer sb = new StringBuffer();
        sb.append("USB: ").append(dev.label());
        sb.append("\nSistema: ").append(fs.typeName());
        if (fs.label().length() > 0 && !fs.label().equals("USB")) sb.append("  \"").append(fs.label()).append("\"");
        sb.append("\nContenido a empaquetar: unos ").append(size(fs.usedBytes()));
        if (extCount > 1) sb.append("\nHay ").append(extCount).append(" particiones ext; se usa la que más ocupa.");
        sb.append("\n\nSe guarda un archivo cpio (formato newc) comprimido con gzip, con permisos, propietarios, "
                + "enlaces simbólicos y dispositivos; se omite lost+found. Es un initrd que puedes usar con un kernel de Linux. "
                + "Los enlaces duros salen como archivos separados y los de más de 4 GB se omiten. "
                + "El USB no se modifica.");
        info.append(new StringItem(null, sb.toString()));
        nameField = new TextField("Nombre del archivo", defaultName(), 100, TextField.ANY);
        info.append(nameField);
        info.addCommand(startCmd);
        info.addCommand(backCmd);
        info.setCommandListener(this);
        display.setCurrent(info);
    }

    private static class Count extends OutputStream {
        final OutputStream o;
        long n;

        Count(OutputStream o) { this.o = o; }

        public void write(int b) throws java.io.IOException {
            o.write(b);
            n++;
        }

        public void write(byte[] b, int off, int len) throws java.io.IOException {
            o.write(b, off, len);
            n += len;
        }

        public void close() throws java.io.IOException {
            o.close();
        }
    }

    private void startCopy() {
        String name = Phone.safe(nameField.getString().trim());
        String low = name.toLowerCase();
        if (!low.endsWith(".gz")) name += low.endsWith(".cpio") ? ".gz" : ".cpio.gz";
        final String fname = name;
        cancel = false;
        running = true;
        done = 0;
        total = Math.max(1, fs.usedBytes());
        startMs = System.currentTimeMillis();
        last = 0;
        curFile = "";
        OpStatus.begin("Creando initrd del USB ext");
        working = new Form("Creando initrd");
        status = new StringItem(null, "Empezando...");
        working.append(status);
        working.addCommand(backCmd);
        working.setCommandListener(this);
        display.setCurrent(working);
        try { display.flashBacklight(8000); } catch (Throwable t) { }
        final ExtFs f = fs;
        new Thread(new Runnable() {
            public void run() {
                Phone.Out out = null;
                boolean ok = false;
                String m;
                long outSize = 0;
                try {
                    out = Phone.create("", fname);
                    Count cnt = new Count(out.os);
                    GZIPOutputStream gz = new GZIPOutputStream(new java.io.BufferedOutputStream(cnt, 65536), 65536);
                    Progress p = new Progress() {
                        public boolean cancelled() { return cancel; }
                        public void add(long n) {
                            done += n;
                            progress();
                        }
                        public void file(String s) { curFile = s; }
                    };
                    f.exportCpio(gz, p);
                    gz.close();
                    outSize = cnt.n;
                    ok = true;
                    StringBuffer sb = new StringBuffer();
                    sb.append("Initrd creado: ").append(size(outSize)).append(" (comprimido)\n\nGuardado en: ").append(out.where)
                            .append("\n(archivo ").append(fname).append(")\n\n");
                    sb.append(f.cpioFiles).append(" archivos, ").append(f.cpioDirs).append(" carpetas, ").append(f.cpioLinks)
                            .append(" enlaces simbólicos, ").append(f.cpioOther).append(" dispositivos/tuberías.");
                    if (f.cpioSkipped.size() > 0) {
                        sb.append("\n\nNO SE INCLUYERON ").append(f.cpioSkipped.size()).append(":\n");
                        for (int i = 0; i < f.cpioSkipped.size() && i < 8; i++) sb.append("- ").append((String) f.cpioSkipped.elementAt(i)).append("\n");
                    }
                    sb.append("\nPara probarlo: kernel + este archivo como initrd (por ejemplo en el arranque PXE o en un USB de arranque). "
                            + "También puedes grabarlo con \"Grabar INITRD (cpio/.img) en ext2\".");
                    m = sb.toString();
                } catch (Throwable t) {
                    if (out != null) out.abort();
                    m = cancel ? "Cancelado. El archivo incompleto se ha borrado."
                            : "ERROR: " + msg(t) + "\n\nEl archivo incompleto se ha borrado.";
                }
                running = false;
                closeDisc();
                OpStatus.end(ok ? OpStatus.OK : (cancel ? OpStatus.CANCEL : OpStatus.FAIL),
                        ok ? fname + " (" + size(outSize) + ")" : (cancel ? "detenido, archivo borrado" : "revisa el mensaje"));
                result = new Form(ok ? "Initrd creado" : "No se creó");
                result.append(new StringItem(null, m));
                result.addCommand(okCmd);
                result.setCommandListener(InitrdUi.this);
                display.setCurrent(result);
            }
        }).start();
    }

    private void progress() {
        long now = System.currentTimeMillis();
        if (now - last > 500) {
            last = now;
            long secs = (now - startMs) / 1000 + 1;
            long pct = Math.min(99, done * 100 / total);
            status.setText("Leyendo el USB y comprimiendo...\n" + pct + " %  (" + size(done) + " de unos " + size(total) + ")\n"
                    + size(done / secs) + "/s\n" + curFile + "\n\n(Atrás = cancelar)");
            OpStatus.progress(size(done) + " de unos " + size(total) + "  ·  " + size(done / secs) + "/s", Math.min(done, total), total);
        }
    }

    public void commandAction(Command c, Displayable d) {
        if (d == note) {
            display.setCurrent(noteNext != null ? noteNext : ret);
        } else if (d == busy) {
            closeDisc();
            display.setCurrent(ret);
        } else if (d == info) {
            if (c == startCmd) {
                startCopy();
            } else {
                closeDisc();
                display.setCurrent(ret);
            }
        } else if (d == working) {
            if (running) {
                cancel = true;
                if (status != null) status.setText("Cancelando...");
            } else {
                display.setCurrent(ret);
            }
        } else if (d == result) {
            display.setCurrent(ret);
        }
    }
}
