package com.usb.informer;
public class Preview {
    /** Texto de vista previa: contenido si parece texto, o los primeros bytes en hexadecimal. */
    public static String make(byte[] b, int n, long size) {
        if (n <= 0) return "(archivo vacío)";
        int bad = 0;
        for (int i = 0; i < n; i++) {
            int c = b[i] & 0xFF;
            if (!(c == 9 || c == 10 || c == 13 || (c >= 32 && c < 127) || c >= 160)) bad++;
        }
        StringBuffer sb = new StringBuffer();
        if (bad * 10 > n * 3) {
            int m = Math.min(n, 48);
            sb.append("(contenido binario) ");
            for (int i = 0; i < m; i++) {
                String h = Integer.toHexString(b[i] & 0xFF).toUpperCase();
                sb.append(h.length() < 2 ? "0" + h : h).append(' ');
            }
        } else {
            for (int i = 0; i < n; i++) {
                int c = b[i] & 0xFF;
                sb.append(c == 9 || c == 10 || c == 13 || c >= 32 ? (char) c : '.');
            }
        }
        if (size > n) sb.append("\n...");
        return sb.toString();
    }
}
