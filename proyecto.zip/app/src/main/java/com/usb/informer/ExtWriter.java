package com.usb.informer;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;

/**
 * Crea un USB con una partición ext2 (GPT) y vuelca en ella el contenido de un initrd cpio (newc, con o sin gzip):
 * carpetas, archivos, enlaces simbólicos (y duros), nodos de dispositivo, permisos, propietarios y fechas.
 * ext2 sin diario, bloques de 4 KB, inodos de 128 bytes, sparse_super + filetype + large_file.
 */
public class ExtWriter {
    public static final String TYPE_LINUX = "0fc63daf-8483-4772-8e79-3d69d8477de4";
    static final int BS = 4096, ISIZE = 128, BPG = 32768;

    public String label = "INITRD";
    public int fileCount, dirCount, linkCount, specialCount;
    public long fileBytes;
    public Vector skipped = new Vector();

    private final ImageSource src;
    private final OpticalDisc dev;

    static class Inode {
        int mode, uid, gid, rmaj, rmin;
        long mtime, size;
        byte[] target;
        LinkedHashMap kids;
        boolean live, written;
        int ino, links;
        int[] blocks;
        byte[] dirBytes;
        boolean isDir() { return (mode & 0170000) == 040000; }
        boolean isReg() { return (mode & 0170000) == 0100000; }
        boolean isLink() { return (mode & 0170000) == 0120000; }
    }

    private Inode root, lostFound;
    private final HashMap paths = new HashMap();
    private final HashMap hard = new HashMap();
    private final ArrayList entryInodes = new ArrayList();
    private final ArrayList liveList = new ArrayList();
    private final long now = System.currentTimeMillis() / 1000;

    // geometría
    private long pStart, pDevBlocks;
    private int fsBlocks, groups, gdtBlocks, ipg, itb, lastIno;
    private int[] overhead;               // bloques de metadatos al inicio de cada grupo
    private BitSet used;
    private int curG, curB;               // cursor de asignación de bloques de datos
    private long neededBlocks;
    private final byte[] uuid = new byte[16];
    private final byte[] diskGuid = new byte[16];
    private final byte[] partGuid = new byte[16];

    public ExtWriter(ImageSource src, OpticalDisc dev) {
        this.src = src;
        this.dev = dev;
        java.util.Random r = new java.util.Random(System.nanoTime() ^ System.currentTimeMillis());
        r.nextBytes(uuid);
        r.nextBytes(diskGuid);
        r.nextBytes(partGuid);
        uuid[6] = (byte) ((uuid[6] & 0x0F) | 0x40);
        uuid[8] = (byte) ((uuid[8] & 0x3F) | 0x80);
    }

    // ------------------------------------------------------------------ 1. leer el cpio

    private static String norm(String n) {
        StringBuffer sb = new StringBuffer();
        String[] parts = split(n);
        for (int i = 0; i < parts.length; i++) {
            if (parts[i].length() == 0 || parts[i].equals(".")) continue;
            if (parts[i].equals("..")) return null;
            if (sb.length() > 0) sb.append('/');
            sb.append(parts[i]);
        }
        return sb.toString();
    }

    private static String[] split(String s) {
        ArrayList l = new ArrayList();
        int st = 0;
        for (int i = 0; i <= s.length(); i++) {
            if (i == s.length() || s.charAt(i) == '/') {
                l.add(s.substring(st, i));
                st = i + 1;
            }
        }
        return (String[]) l.toArray(new String[0]);
    }

    private Inode newDir(int mode, int uid, int gid, long mtime) {
        Inode d = new Inode();
        d.mode = 040000 | (mode & 07777);
        d.uid = uid;
        d.gid = gid;
        d.mtime = mtime;
        d.kids = new LinkedHashMap();
        return d;
    }

    /** Primera pasada: lee todo el initrd y construye en memoria el árbol (sin guardar los datos). */
    public void scan(Progress p) throws Exception {
        root = newDir(0755, 0, 0, now);
        paths.put("", root);
        InputStream in = Pipe.open(src, p);
        try {
            CpioReader r = new CpioReader(in);
            CpioReader.Entry e;
            while ((e = r.next()) != null) {
                if (p != null && p.cancelled()) throw new Exception("Cancelado");
                Inode made = add(r, e);
                entryInodes.add(made);
            }
        } finally {
            in.close();
        }
        // alcanzables, números de enlaces y totales
        mark(root);
        if (root.kids.size() == 0 && entryInodes.size() == 0) throw new Exception("El archivo está vacío: no parece un initrd cpio.");
    }

    private Inode add(CpioReader r, CpioReader.Entry e) throws Exception {
        String name = norm(e.name);
        if (name == null) { skip("ruta no válida: " + e.name); r.skipRest(); return null; }
        int type = e.mode & 0170000;
        if (name.length() == 0) {
            if (type == 040000) {
                root.mode = 040000 | (e.mode & 07777);
                root.uid = e.uid;
                root.gid = e.gid;
                root.mtime = e.mtime;
            }
            r.skipRest();
            return null;
        }
        String[] parts = split(name);
        for (int i = 0; i < parts.length; i++) {
            if (parts[i].length() > 255) { skip("nombre demasiado largo: " + name); r.skipRest(); return null; }
        }
        // carpetas intermedias
        Inode parent = root;
        StringBuffer pre = new StringBuffer();
        for (int i = 0; i < parts.length - 1; i++) {
            if (pre.length() > 0) pre.append('/');
            pre.append(parts[i]);
            String key = pre.toString();
            Inode d = (Inode) paths.get(key);
            if (d == null || !parent.kids.containsValue(d)) {
                d = newDir(0755, 0, 0, now);
                parent.kids.put(parts[i], d);
                paths.put(key, d);
            } else if (!d.isDir()) {
                skip(name + " (dentro de un enlace o archivo)");
                r.skipRest();
                return null;
            }
            parent = d;
        }
        String base = parts[parts.length - 1];
        Inode old = (Inode) parent.kids.get(base);
        Inode ino;
        if (type == 040000) {
            if (old != null && old.isDir()) ino = old;
            else {
                ino = newDir(e.mode, e.uid, e.gid, e.mtime);
                parent.kids.put(base, ino);
            }
            ino.mode = 040000 | (e.mode & 07777);
            ino.uid = e.uid;
            ino.gid = e.gid;
            ino.mtime = e.mtime;
            paths.put(name, ino);
            r.skipRest();
            return ino;
        }
        String hkey = null;
        if (e.nlink > 1) hkey = e.dmaj + ":" + e.dmin + ":" + e.ino;
        ino = hkey != null ? (Inode) hard.get(hkey) : null;
        if (ino == null) {
            ino = new Inode();
            ino.mode = e.mode;
            ino.uid = e.uid;
            ino.gid = e.gid;
            ino.mtime = e.mtime;
            ino.rmaj = e.rmaj;
            ino.rmin = e.rmin;
            if (hkey != null) hard.put(hkey, ino);
        }
        if (type == 0100000) {
            if (e.size > 0) ino.size = e.size;
            if (ino.size > 4000000000L) throw new Exception("El archivo " + name + " ocupa más de 4 GB: ext2 con bloques de 4 KB no lo admite aquí");
        } else if (type == 0120000) {
            if (e.size > 4000) throw new Exception("Enlace simbólico demasiado largo: " + name);
            byte[] t = new byte[(int) e.size];
            r.readFully(t, t.length);
            ino.target = t;
            ino.size = t.length;
        } else if (type != 020000 && type != 060000 && type != 010000 && type != 0140000) {
            skip("tipo de archivo desconocido: " + name);
            return null;
        }
        r.skipRest();
        parent.kids.put(base, ino);
        paths.put(name, ino);
        return ino;
    }

    private void skip(String s) {
        if (skipped.size() < 200) skipped.addElement(s);
    }

    private void mark(Inode d) {
        // recorrido en anchura/profundidad iterativo para no desbordar la pila
        ArrayList stack = new ArrayList();
        stack.add(d);
        d.live = true;
        liveList.add(d);
        while (!stack.isEmpty()) {
            Inode cur = (Inode) stack.remove(stack.size() - 1);
            int sub = 0;
            for (Iterator it = cur.kids.values().iterator(); it.hasNext();) {
                Inode k = (Inode) it.next();
                if (k.isDir()) {
                    sub++;
                    if (!k.live) {
                        k.live = true;
                        liveList.add(k);
                        stack.add(k);
                    }
                } else {
                    k.links++;
                    if (!k.live) {
                        k.live = true;
                        liveList.add(k);
                    }
                }
            }
            cur.links = 2 + sub;
        }
        fileCount = dirCount = linkCount = specialCount = 0;
        fileBytes = 0;
        for (int i = 0; i < liveList.size(); i++) {
            Inode n = (Inode) liveList.get(i);
            if (n.isDir()) dirCount++;
            else if (n.isReg()) { fileCount++; fileBytes += n.size; }
            else if (n.isLink()) linkCount++;
            else specialCount++;
        }
    }

    // ------------------------------------------------------------------ 2. geometría

    private static boolean hasBackup(int g) {
        if (g <= 1) return true;
        int[] b = { 3, 5, 7 };
        for (int i = 0; i < b.length; i++) {
            long v = b[i];
            while (v < g) v *= b[i];
            if (v == g) return true;
        }
        return false;
    }

    private static int dirBlocksFor(Inode d) {
        int pos = 0, blocks = 1;
        int[] first = { 12, 12 };           // "." y ".."
        for (int i = 0; i < 2; i++) pos += first[i];
        for (Iterator it = d.kids.keySet().iterator(); it.hasNext();) {
            String n = (String) it.next();
            int sz = 8 + ((n.length() + 3) & ~3);
            if (pos + sz > BS) { blocks++; pos = 0; }
            pos += sz;
        }
        return blocks;
    }

    private static int indirectFor(int n) {
        if (n <= 12) return 0;
        int rest = n - 12;
        if (rest <= 1024) return 1;
        rest -= 1024;
        return 2 + (rest + 1023) / 1024;
    }

    /** Calcula el reparto de la partición y comprueba que cabe todo. */
    public void layout() throws Exception {
        int dbs = dev.blockSize;
        long total = dev.blocks & 0xFFFFFFFFL;
        long align = (1024 * 1024) / dbs;
        pStart = Math.max(align, Gpt.firstUsable(dbs));
        pStart = (pStart + align - 1) / align * align;
        long last = Gpt.lastUsable(total, dbs);
        pDevBlocks = (last - pStart + 1) / align * align;
        if (pDevBlocks * dbs < 64L * 1024 * 1024) throw new Exception("El USB es demasiado pequeño (mínimo 64 MB)");
        long fb = pDevBlocks * dbs / BS;
        if (fb > 0x7FFFFFFFL) fb = 0x7FFFFFFFL;
        fsBlocks = (int) fb;

        // lost+found
        Object lf = root.kids.get("lost+found");
        if (lf != null && ((Inode) lf).isDir()) {
            lostFound = (Inode) lf;
        } else {
            lostFound = newDir(0700, 0, 0, now);
            if (lf == null) {
                root.kids.put("lost+found", lostFound);
                root.links++;
            }
            lostFound.live = true;
            lostFound.links = 2;
            if (lf == null) liveList.add(lostFound);
        }
        // inodos necesarios y bloques necesarios
        int needInodes = 10 + liveList.size();
        neededBlocks = 0;
        for (int i = 0; i < liveList.size(); i++) {
            Inode n = (Inode) liveList.get(i);
            int data;
            if (n.isDir()) data = n == lostFound && n.kids.size() == 0 ? 4 : dirBlocksFor(n);
            else if (n.isReg()) data = (int) ((n.size + BS - 1) / BS);
            else if (n.isLink()) data = n.size >= 60 ? 1 : 0;
            else data = 0;
            neededBlocks += data + indirectFor(data);
        }
        // grupos
        groups = (fsBlocks + BPG - 1) / BPG;
        for (int attempt = 0; attempt < 3; attempt++) {
            gdtBlocks = (groups * 32 + BS - 1) / BS;
            long want = Math.max((long) needInodes + needInodes / 4 + 64, (long) fsBlocks * BS / (fsBlocks > (8 << 18) ? 65536 : 32768));
            long perGroup = (want + groups - 1) / groups;
            perGroup = (perGroup + 31) / 32 * 32;
            if (perGroup < 32) perGroup = 32;
            if (perGroup > BS * 8) perGroup = BS * 8;
            ipg = (int) perGroup;
            itb = ipg * ISIZE / BS;
            int lastSize = fsBlocks - (groups - 1) * BPG;
            int ov = (hasBackup(groups - 1) ? 1 + gdtBlocks : 0) + 2 + itb;
            if (groups > 1 && lastSize < ov + 64) {
                fsBlocks -= lastSize;
                groups--;
                continue;
            }
            break;
        }
        if ((long) ipg * groups < needInodes) throw new Exception("Demasiados archivos para este USB");
        overhead = new int[groups];
        long freeData = 0;
        for (int g = 0; g < groups; g++) {
            overhead[g] = (hasBackup(g) ? 1 + gdtBlocks : 0) + 2 + itb;
            int size = Math.min(BPG, fsBlocks - g * BPG);
            freeData += size - overhead[g];
        }
        if (neededBlocks > freeData) {
            long miss = (neededBlocks - freeData) * BS;
            throw new Exception("El contenido no cabe en el USB: faltan " + Phone.sizeText(miss));
        }
        // números de inodo
        lostFound.ino = 11;
        root.ino = 2;
        int next = 12;
        for (int i = 0; i < liveList.size(); i++) {
            Inode n = (Inode) liveList.get(i);
            if (n == root || n == lostFound) continue;
            n.ino = next++;
        }
        lastIno = next - 1;
        // bloques de metadatos usados
        used = new BitSet(fsBlocks);
        for (int g = 0; g < groups; g++) used.set(g * BPG, g * BPG + overhead[g]);
        curG = 0;
        curB = overhead[0];
    }

    public long capacity() { return (long) fsBlocks * BS; }

    public long dataBytes() { return fileBytes + (long) groups * (itb + 3 + gdtBlocks) * BS; }

    public int inodeCount() { return ipg * groups; }

    // ------------------------------------------------------------------ 3. escribir

    private int allocBlock() throws Exception {
        while (true) {
            if (curG >= groups) throw new Exception("No queda espacio en el USB");
            int end = Math.min(BPG, fsBlocks - curG * BPG);
            if (curB >= end) {
                curG++;
                if (curG < groups) curB = overhead[curG];
                continue;
            }
            int b = curG * BPG + curB;
            curB++;
            used.set(b);
            return b;
        }
    }

    // escritura de bloques de datos con agrupación en trozos de 64 KB
    private byte[] wbuf = new byte[OpticalDisc.WRITE_CHUNK];
    private int wfill;
    private long wstart;                   // bloque ext2 donde empieza el trozo pendiente
    private Progress prog;

    private long lbaOf(long block) { return pStart + block * (BS / dev.blockSize); }

    private void putBlock(int block, byte[] data) throws Exception {
        if (wfill > 0 && block != wstart + wfill / BS) flushSink();
        if (wfill == 0) wstart = block;
        System.arraycopy(data, 0, wbuf, wfill, BS);
        wfill += BS;
        if (wfill == wbuf.length) flushSink();
    }

    private void flushSink() throws Exception {
        if (wfill == 0) return;
        if (prog != null && prog.cancelled()) throw new Exception("Cancelado");
        dev.write((int) lbaOf(wstart), wbuf, wfill);
        wfill = 0;
    }

    private void zero(long lba, long blocks) throws Exception {
        byte[] z = new byte[OpticalDisc.WRITE_CHUNK];
        int per = z.length / dev.blockSize;
        long done = 0;
        while (done < blocks) {
            if (prog != null && prog.cancelled()) throw new Exception("Cancelado");
            int n = (int) Math.min(per, blocks - done);
            dev.write((int) (lba + done), z, n * dev.blockSize);
            done += n;
        }
    }

    public void write(Progress p) throws Exception {
        prog = p;
        int dbs = dev.blockSize;
        long total = dev.blocks & 0xFFFFFFFFL;
        zero(0, pStart);
        zero(total - Gpt.entryBlocks(dbs) - 1, Gpt.entryBlocks(dbs) + 1);

        InputStream in = Pipe.open(src, p);
        try {
            CpioReader r = new CpioReader(in);
            CpioReader.Entry e;
            int idx = 0;
            byte[] buf = new byte[BS];
            while ((e = r.next()) != null) {
                if (p != null && p.cancelled()) throw new Exception("Cancelado");
                Inode ino = idx < entryInodes.size() ? (Inode) entryInodes.get(idx) : null;
                idx++;
                if (ino == null || !ino.live || !ino.isReg() || e.size <= 0 || ino.written || (e.mode & 0170000) != 0100000) {
                    r.skipRest();
                    continue;
                }
                long left = e.size;
                int nb = (int) ((e.size + BS - 1) / BS);
                ino.blocks = new int[nb];
                for (int i = 0; i < nb; i++) {
                    int n = (int) Math.min(BS, left);
                    r.readFully(buf, n);
                    for (int k = n; k < BS; k++) buf[k] = 0;
                    int b = allocBlock();
                    ino.blocks[i] = b;
                    putBlock(b, buf);
                    left -= n;
                    if (p != null) p.add(n);
                }
                ino.written = true;
            }
        } finally {
            in.close();
        }
        flushSink();
        finishMetadata();
        flushSink();
        dev.flush();
        Gpt.write(dev, diskGuid, new long[][] { { pStart, pStart + pDevBlocks - 1 } }, new String[] { TYPE_LINUX },
                new byte[][] { partGuid }, new String[] { label });
    }

    // ------------------------------------------------------------------ 4. metadatos

    private static void p16(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); }

    private static void p32(byte[] b, int o, long v) {
        b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24);
    }

    private static int ftype(Inode n) {
        switch (n.mode & 0170000) {
            case 0100000: return 1;
            case 040000: return 2;
            case 020000: return 3;
            case 060000: return 4;
            case 010000: return 5;
            case 0140000: return 6;
            case 0120000: return 7;
            default: return 0;
        }
    }

    private byte[] buildDir(Inode d, int parentIno, boolean empty) {
        ArrayList blocks = new ArrayList();
        byte[] cur = new byte[BS];
        int pos = 0, lastRec = -1;
        ArrayList names = new ArrayList();
        ArrayList inos = new ArrayList();
        ArrayList types = new ArrayList();
        names.add("."); inos.add(new Integer(d.ino)); types.add(new Integer(2));
        names.add(".."); inos.add(new Integer(parentIno)); types.add(new Integer(2));
        for (Iterator it = d.kids.entrySet().iterator(); it.hasNext();) {
            Map.Entry en = (Map.Entry) it.next();
            Inode k = (Inode) en.getValue();
            names.add(en.getKey());
            inos.add(new Integer(k.ino));
            types.add(new Integer(ftype(k)));
        }
        for (int i = 0; i < names.size(); i++) {
            byte[] nm;
            try { nm = ((String) names.get(i)).getBytes("ISO-8859-1"); } catch (Exception ex) { nm = new byte[0]; }
            int sz = 8 + ((nm.length + 3) & ~3);
            if (pos + sz > BS) {
                p16(cur, lastRec + 4, BS - lastRec);
                blocks.add(cur);
                cur = new byte[BS];
                pos = 0;
            }
            p32(cur, pos, ((Integer) inos.get(i)).intValue());
            p16(cur, pos + 4, sz);
            cur[pos + 6] = (byte) nm.length;
            cur[pos + 7] = (byte) ((Integer) types.get(i)).intValue();
            System.arraycopy(nm, 0, cur, pos + 8, nm.length);
            lastRec = pos;
            pos += sz;
        }
        p16(cur, lastRec + 4, BS - lastRec);
        blocks.add(cur);
        if (empty) {
            // lost+found vacío: 4 bloques (los extra, con un solo registro vacío que ocupa el bloque entero)
            while (blocks.size() < 4) {
                byte[] z = new byte[BS];
                p16(z, 4, BS);
                blocks.add(z);
            }
        }
        byte[] out = new byte[blocks.size() * BS];
        for (int i = 0; i < blocks.size(); i++) System.arraycopy(blocks.get(i), 0, out, i * BS, BS);
        return out;
    }

    private final TreeMap meta = new TreeMap();   // bloque -> contenido (carpetas, enlaces largos, bloques indirectos)
    private byte[][] itab;

    private void putMeta(int block, byte[] data) { meta.put(new Integer(block), data); }

    private int parentIno(Inode d, Map parents) {
        Inode p = (Inode) parents.get(d);
        return p == null ? d.ino : p.ino;
    }

    private void finishMetadata() throws Exception {
        // padres (para ".."); si una carpeta se alcanza desde varios sitios, vale el primero
        HashMap parents = new HashMap();
        for (int i = 0; i < liveList.size(); i++) {
            Inode n = (Inode) liveList.get(i);
            if (!n.isDir()) continue;
            for (Iterator it = n.kids.values().iterator(); it.hasNext();) {
                Inode k = (Inode) it.next();
                if (k.isDir() && !parents.containsKey(k)) parents.put(k, n);
            }
        }
        itab = new byte[groups][];
        // contenido de carpetas y enlaces largos
        for (int i = 0; i < liveList.size(); i++) {
            Inode n = (Inode) liveList.get(i);
            if (n.isDir()) {
                byte[] db = buildDir(n, n == root ? 2 : parentIno(n, parents), n == lostFound && n.kids.size() == 0);
                int nb = db.length / BS;
                n.blocks = new int[nb];
                for (int k = 0; k < nb; k++) {
                    int b = allocBlock();
                    n.blocks[k] = b;
                    byte[] part = new byte[BS];
                    System.arraycopy(db, k * BS, part, 0, BS);
                    putMeta(b, part);
                }
                n.size = (long) nb * BS;
            } else if (n.isLink() && n.size >= 60) {
                int b = allocBlock();
                n.blocks = new int[] { b };
                byte[] part = new byte[BS];
                System.arraycopy(n.target, 0, part, 0, n.target.length);
                putMeta(b, part);
            } else if (n.isReg() && n.blocks == null) {
                n.blocks = new int[0];
            }
        }
        // inodos
        for (int i = 0; i < liveList.size(); i++) {
            Inode n = (Inode) liveList.get(i);
            byte[] rec = new byte[ISIZE];
            int[] bl = n.blocks == null ? new int[0] : n.blocks;
            int nInd = 0;
            int[] iblock = new int[15];
            for (int k = 0; k < bl.length && k < 12; k++) iblock[k] = bl[k];
            if (bl.length > 12) {
                int ind = allocBlock();
                nInd++;
                iblock[12] = ind;
                byte[] ib = new byte[BS];
                int cnt = Math.min(1024, bl.length - 12);
                for (int k = 0; k < cnt; k++) p32(ib, 4 * k, bl[12 + k]);
                putMeta(ind, ib);
                if (bl.length > 12 + 1024) {
                    int dind = allocBlock();
                    nInd++;
                    iblock[13] = dind;
                    byte[] db = new byte[BS];
                    int rest = bl.length - 12 - 1024;
                    int nIb = (rest + 1023) / 1024;
                    for (int j = 0; j < nIb; j++) {
                        int ind2 = allocBlock();
                        nInd++;
                        p32(db, 4 * j, ind2);
                        byte[] b2 = new byte[BS];
                        int c2 = Math.min(1024, rest - j * 1024);
                        for (int k = 0; k < c2; k++) p32(b2, 4 * k, bl[12 + 1024 + j * 1024 + k]);
                        putMeta(ind2, b2);
                    }
                    putMeta(dind, db);
                }
            }
            int type = n.mode & 0170000;
            if (n.isLink() && n.size < 60 && n.target != null) {
                byte[] t = n.target;
                for (int k = 0; k < t.length; k++) rec[40 + k] = t[k];
            } else if (type == 020000 || type == 060000) {
                if (n.rmaj < 256 && n.rmin < 256) p32(rec, 40, (n.rmaj << 8) | n.rmin);
                else p32(rec, 44, (n.rmin & 0xFF) | (n.rmaj << 8) | ((n.rmin & ~0xFF) << 12));
            } else {
                for (int k = 0; k < 15; k++) p32(rec, 40 + 4 * k, iblock[k]);
            }
            p16(rec, 0, n.mode & 0xFFFF);
            p16(rec, 2, n.uid & 0xFFFF);
            p32(rec, 4, n.size & 0xFFFFFFFFL);
            p32(rec, 8, n.mtime);
            p32(rec, 12, n.mtime);
            p32(rec, 16, n.mtime);
            p16(rec, 24, n.gid & 0xFFFF);
            p16(rec, 26, n.isDir() ? n.links : Math.max(1, n.links));
            long sectors = (long) (bl.length + nInd) * (BS / 512);
            p32(rec, 28, sectors);
            if (n.isReg()) p32(rec, 108, n.size >>> 32);
            p16(rec, 120, n.uid >>> 16);
            p16(rec, 122, n.gid >>> 16);
            int g = (n.ino - 1) / ipg, idx = (n.ino - 1) % ipg;
            if (itab[g] == null) itab[g] = new byte[ipg * ISIZE];
            System.arraycopy(rec, 0, itab[g], idx * ISIZE, ISIZE);
        }
        // grupos: bitmaps + tabla de inodos
        int totalFreeBlocks = 0;
        int[] freeB = new int[groups], freeI = new int[groups], dirs = new int[groups];
        for (int i = 0; i < liveList.size(); i++) {
            Inode n = (Inode) liveList.get(i);
            if (n.isDir()) dirs[(n.ino - 1) / ipg]++;
        }
        for (int g = 0; g < groups; g++) {
            int size = Math.min(BPG, fsBlocks - g * BPG);
            freeB[g] = size - used.get(g * BPG, g * BPG + size).cardinality();
            totalFreeBlocks += freeB[g];
            int usedI = 0;
            for (int k = 0; k < ipg; k++) {
                int ino = g * ipg + k + 1;
                if (ino <= 10 || ino <= lastIno) usedI++;
            }
            freeI[g] = ipg - usedI;
        }
        int totalFreeInodes = 0;
        for (int g = 0; g < groups; g++) totalFreeInodes += freeI[g];
        byte[] gdt = new byte[gdtBlocks * BS];
        for (int g = 0; g < groups; g++) {
            int base = g * BPG + (hasBackup(g) ? 1 + gdtBlocks : 0);
            p32(gdt, g * 32, base);
            p32(gdt, g * 32 + 4, base + 1);
            p32(gdt, g * 32 + 8, base + 2);
            p16(gdt, g * 32 + 12, freeB[g]);
            p16(gdt, g * 32 + 14, freeI[g]);
            p16(gdt, g * 32 + 16, dirs[g]);
        }
        for (int g = 0; g < groups; g++) {
            int base = g * BPG + (hasBackup(g) ? 1 + gdtBlocks : 0);
            int size = Math.min(BPG, fsBlocks - g * BPG);
            byte[] bb = new byte[BS], ib = new byte[BS];
            for (int i = 0; i < BPG; i++) {
                boolean set = i >= size || used.get(g * BPG + i);
                if (set) bb[i >> 3] |= (byte) (1 << (i & 7));
            }
            for (int i = 0; i < BS * 8; i++) {
                boolean set = i >= ipg;
                if (!set) {
                    int ino = g * ipg + i + 1;
                    set = ino <= 10 || ino <= lastIno;
                }
                if (set) ib[i >> 3] |= (byte) (1 << (i & 7));
            }
            putRun(base, bb);
            putRun(base + 1, ib);
            if (itab[g] != null) putRun(base + 2, itab[g]);
            else zeroBlocks(base + 2, itb);
            flushRuns();
            if (hasBackup(g)) {
                byte[] sb = new byte[BS];
                superblock(sb, g == 0 ? 1024 : 0, g, totalFreeBlocks, totalFreeInodes);
                if (g == 0) {
                    // el bloque 0 empieza con 1 KB de arranque (ceros) y luego va el superbloque
                    putRun(0, sb);
                } else {
                    putRun(g * BPG, sb);
                }
                putRun(g * BPG + 1, gdt);
                flushRuns();
            }
            itab[g] = null;
        }
        // bloques de metadatos sueltos (carpetas, enlaces largos, indirectos), agrupando los consecutivos
        int runStart = -1;
        byte[] run = new byte[OpticalDisc.WRITE_CHUNK];
        int runFill = 0;
        for (Iterator it = meta.entrySet().iterator(); it.hasNext();) {
            Map.Entry en = (Map.Entry) it.next();
            int b = ((Integer) en.getKey()).intValue();
            if (runFill > 0 && (b != runStart + runFill / BS || runFill == run.length)) {
                dev.write((int) lbaOf(runStart), run, runFill);
                runFill = 0;
            }
            if (runFill == 0) runStart = b;
            System.arraycopy(en.getValue(), 0, run, runFill, BS);
            runFill += BS;
        }
        if (runFill > 0) dev.write((int) lbaOf(runStart), run, runFill);
        meta.clear();
    }

    // escritura de regiones contiguas "grandes" (bitmaps, tablas, superbloques)
    private int runBlock = -1;
    private byte[] runBuf = new byte[OpticalDisc.WRITE_CHUNK];
    private int runFill;

    private void putRun(int block, byte[] data) throws Exception {
        int off = 0;
        while (off < data.length) {
            if (runFill > 0 && (block + off / BS != runBlock + runFill / BS || runFill == runBuf.length)) flushRuns();
            if (runFill == 0) runBlock = block + off / BS;
            int n = Math.min(data.length - off, runBuf.length - runFill);
            System.arraycopy(data, off, runBuf, runFill, n);
            runFill += n;
            off += n;
            if (runFill == runBuf.length) flushRuns();
        }
    }

    private void flushRuns() throws Exception {
        if (runFill == 0) return;
        if (prog != null && prog.cancelled()) throw new Exception("Cancelado");
        dev.write((int) lbaOf(runBlock), runBuf, runFill);
        if (prog != null) prog.add(runFill);
        runFill = 0;
    }

    private void zeroBlocks(int block, int n) throws Exception {
        byte[] z = new byte[BS * 16];
        int done = 0;
        while (done < n) {
            int c = Math.min(16, n - done);
            byte[] part = c == 16 ? z : new byte[c * BS];
            putRun(block + done, part);
            done += c;
        }
    }

    private void superblock(byte[] b, int o, int group, int freeBlocks, int freeInodes) {
        p32(b, o + 0x00, (long) ipg * groups);
        p32(b, o + 0x04, fsBlocks);
        p32(b, o + 0x08, 0);
        p32(b, o + 0x0C, freeBlocks);
        p32(b, o + 0x10, freeInodes);
        p32(b, o + 0x14, 0);
        p32(b, o + 0x18, 2);
        p32(b, o + 0x1C, 2);
        p32(b, o + 0x20, BPG);
        p32(b, o + 0x24, BPG);
        p32(b, o + 0x28, ipg);
        p32(b, o + 0x2C, 0);
        p32(b, o + 0x30, now);
        p16(b, o + 0x34, 0);
        p16(b, o + 0x36, 0xFFFF);
        p16(b, o + 0x38, 0xEF53);
        p16(b, o + 0x3A, 1);
        p16(b, o + 0x3C, 1);
        p16(b, o + 0x3E, 0);
        p32(b, o + 0x40, now);
        p32(b, o + 0x44, 0);
        p32(b, o + 0x48, 0);
        p32(b, o + 0x4C, 1);
        p16(b, o + 0x50, 0);
        p16(b, o + 0x52, 0);
        p32(b, o + 0x54, 11);
        p16(b, o + 0x58, ISIZE);
        p16(b, o + 0x5A, group);
        p32(b, o + 0x5C, 0);
        p32(b, o + 0x60, 2);       // filetype
        p32(b, o + 0x64, 3);       // sparse_super + large_file
        System.arraycopy(uuid, 0, b, o + 0x68, 16);
        for (int i = 0; i < 16 && i < label.length(); i++) b[o + 0x78 + i] = (byte) label.charAt(i);
    }

    // ------------------------------------------------------------------ 5. verificar

    /** Vuelve a leer el initrd y compara el contenido de cada archivo con lo escrito en el USB. */
    public void verify(Progress p) throws Exception {
        // superbloque
        byte[] sb = dev.read((int) lbaOf(0), Math.max(1, BS / dev.blockSize));
        int magic = (sb[1024 + 0x38] & 0xFF) | ((sb[1024 + 0x39] & 0xFF) << 8);
        if (magic != 0xEF53) throw new Exception("La verificación falló: no se encuentra el superbloque ext2");
        InputStream in = Pipe.open(src, p);
        try {
            CpioReader r = new CpioReader(in);
            CpioReader.Entry e;
            int idx = 0;
            byte[] buf = new byte[BS];
            while ((e = r.next()) != null) {
                if (p != null && p.cancelled()) throw new Exception("Cancelado");
                Inode ino = idx < entryInodes.size() ? (Inode) entryInodes.get(idx) : null;
                idx++;
                if (ino == null || !ino.live || !ino.isReg() || e.size <= 0 || (e.mode & 0170000) != 0100000 || ino.blocks == null
                        || ino.size != e.size) {
                    r.skipRest();
                    continue;
                }
                long left = e.size;
                int i = 0;
                while (i < ino.blocks.length) {
                    // tramo de bloques consecutivos (hasta 64 KB)
                    int run = 1;
                    while (i + run < ino.blocks.length && run < OpticalDisc.WRITE_CHUNK / BS && ino.blocks[i + run] == ino.blocks[i] + run) run++;
                    byte[] dsk = dev.read((int) lbaOf(ino.blocks[i]), run * BS / dev.blockSize);
                    for (int k = 0; k < run; k++) {
                        int n = (int) Math.min(BS, left);
                        r.readFully(buf, n);
                        for (int j = 0; j < n; j++) {
                            if (dsk[k * BS + j] != buf[j]) throw new Exception("La verificación falló en un archivo (bloque " + (ino.blocks[i + k]) + ")");
                        }
                        left -= n;
                        if (p != null) p.add(n);
                    }
                    i += run;
                }
            }
        } finally {
            in.close();
        }
    }
}
