package com.usb.informer;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.util.zip.GZIPInputStream;

/** Lee un initrd/initramfs en formato cpio "newc" (070701/070702), con o sin gzip y con varios trozos concatenados. */
public class CpioReader {
    public static class Entry {
        public String name;
        public long ino, size, mtime;
        public int mode, uid, gid, nlink, dmaj, dmin, rmaj, rmin;
    }

    private final PushbackInputStream raw;
    private PushbackInputStream cur;
    private boolean plain;
    private long remaining, pad;

    public CpioReader(InputStream in) {
        raw = new PushbackInputStream(new BufferedInputStream(in, 65536), 16);
    }

    private static long hex(byte[] b, int off) throws IOException {
        long v = 0;
        for (int i = 0; i < 8; i++) {
            int c = b[off + i];
            int d = c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1;
            if (d < 0) throw new IOException("Cabecera cpio dañada");
            v = (v << 4) | d;
        }
        return v;
    }

    private boolean fill(PushbackInputStream s, byte[] b, int n) throws IOException {
        int got = 0;
        while (got < n) {
            int r = s.read(b, got, n - got);
            if (r < 0) {
                if (got == 0) return false;
                throw new IOException("initrd truncado");
            }
            got += r;
        }
        return true;
    }

    private void openSegment() throws IOException {
        int b0;
        while ((b0 = raw.read()) == 0) { }
        if (b0 < 0) { cur = null; return; }
        int b1 = raw.read();
        int b2 = raw.read();
        int b3 = raw.read();
        // devolver los bytes leídos, en orden
        if (b3 >= 0) raw.unread(b3);
        if (b2 >= 0) raw.unread(b2);
        if (b1 >= 0) raw.unread(b1);
        raw.unread(b0);
        plain = false;
        if (b0 == 0x1f && b1 == 0x8b) {
            cur = new PushbackInputStream(new GZIPInputStream(raw, 65536), 16);
        } else if (b0 == '0') {
            cur = raw;
            plain = true;
        } else if (b0 == 0xFD && b1 == '7' && b2 == 'z') {
            throw new IOException("Este initrd está comprimido con xz; la app solo lee gzip o sin comprimir");
        } else if (b0 == 0x28 && b1 == 0xB5 && b2 == 0x2F && b3 == 0xFD) {
            throw new IOException("Este initrd está comprimido con zstd; la app solo lee gzip o sin comprimir");
        } else if (b0 == 'B' && b1 == 'Z' && b2 == 'h') {
            throw new IOException("Este initrd está comprimido con bzip2; la app solo lee gzip o sin comprimir");
        } else if (b0 == 0x04 && b1 == 0x22 && b2 == 0x4D) {
            throw new IOException("Este initrd está comprimido con lz4; la app solo lee gzip o sin comprimir");
        } else {
            throw new IOException("No reconozco el formato (esperaba cpio, o cpio con gzip)");
        }
    }

    /** Siguiente entrada, o null al terminar. Salta lo que quede de los datos de la anterior. */
    public Entry next() throws IOException {
        skipRest();
        byte[] h = new byte[110];
        while (true) {
            if (cur == null) {
                openSegment();
                if (cur == null) return null;
            }
            // ceros de relleno entre archivos concatenados
            int c;
            while ((c = cur.read()) == 0) { }
            if (c < 0) { cur = null; continue; }
            cur.unread(c);
            if (plain && c != '0') { cur = null; continue; }   // detrás hay otro tipo de trozo (p. ej. gzip)
            if (!fill(cur, h, 110)) { cur = null; continue; }
            if (h[0] != '0' || h[1] != '7' || h[2] != '0' || h[3] != '7' || h[4] != '0' || (h[5] != '1' && h[5] != '2')) {
                if (h[5] == '7') throw new IOException("Formato cpio antiguo (odc) no soportado; hace falta newc");
                throw new IOException("Cabecera cpio no válida");
            }
            Entry e = new Entry();
            e.ino = hex(h, 6);
            e.mode = (int) hex(h, 14);
            e.uid = (int) hex(h, 22);
            e.gid = (int) hex(h, 30);
            e.nlink = (int) hex(h, 38);
            e.mtime = hex(h, 46);
            e.size = hex(h, 54);
            e.dmaj = (int) hex(h, 62);
            e.dmin = (int) hex(h, 70);
            e.rmaj = (int) hex(h, 78);
            e.rmin = (int) hex(h, 86);
            int nl = (int) hex(h, 94);
            if (nl < 1 || nl > 65536) throw new IOException("Nombre cpio demasiado largo");
            byte[] nm = new byte[nl];
            if (!fill(cur, nm, nl)) throw new IOException("initrd truncado");
            int skip = (int) ((4 - (110 + nl) % 4) % 4);
            for (int i = 0; i < skip; i++) cur.read();
            e.name = new String(nm, 0, nl - 1, "ISO-8859-1");
            if (e.name.equals("TRAILER!!!")) {
                continue;   // fin de este archivo cpio; puede haber otro detrás
            }
            remaining = e.size;
            pad = (4 - e.size % 4) % 4;
            return e;
        }
    }

    /** Lee datos de la entrada actual (devuelve -1 al acabar). */
    public int read(byte[] b, int off, int len) throws IOException {
        if (remaining <= 0) return -1;
        int n = (int) Math.min(len, remaining);
        int r = cur.read(b, off, n);
        if (r < 0) throw new IOException("initrd truncado");
        remaining -= r;
        return r;
    }

    public void readFully(byte[] b, int len) throws IOException {
        int got = 0;
        while (got < len) {
            int r = read(b, got, len - got);
            if (r < 0) throw new IOException("initrd truncado");
            got += r;
        }
    }

    public void skipRest() throws IOException {
        if (cur == null) { remaining = 0; pad = 0; return; }
        byte[] t = new byte[8192];
        while (remaining > 0) {
            int n = (int) Math.min(t.length, remaining);
            int r = cur.read(t, 0, n);
            if (r < 0) throw new IOException("initrd truncado");
            remaining -= r;
        }
        while (pad > 0) {
            if (cur.read() < 0) break;
            pad--;
        }
        pad = 0;
    }
}
