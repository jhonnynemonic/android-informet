package com.usb.informer;
import java.io.IOException;
import java.io.OutputStream;

/** Flujo que, en vez de escribir, compara lo recibido con lo que hay en el USB. */
public class ImageVerifier extends OutputStream {
    private OpticalDisc d;
    private long pos;
    private byte[] cache;
    private int cacheLba = -1;
    private Progress p;

    public ImageVerifier(OpticalDisc d, Progress p) {
        this.d = d;
        this.p = p;
    }

    public void write(int b) throws IOException {
        write(new byte[] { (byte) b }, 0, 1);
    }

    public void write(byte[] b, int off, int len) throws IOException {
        int bs = d.blockSize;
        int span = 64 * 1024 / bs;
        if (span < 1) span = 1;
        while (len > 0) {
            if (p != null && p.cancelled()) throw new IOException("Cancelado");
            int lba = (int) (pos / bs);
            int groupLba = lba - (lba % span);
            if (cache == null || cacheLba != groupLba) {
                int n = Math.min(span, d.blocks - groupLba);
                try {
                    cache = d.read(groupLba, n);
                } catch (Exception e) {
                    throw new IOException(e.getMessage());
                }
                cacheLba = groupLba;
            }
            int inCache = (int) (pos - (long) groupLba * bs);
            int n = Math.min(len, cache.length - inCache);
            for (int i = 0; i < n; i++) {
                if (cache[inCache + i] != b[off + i]) {
                    throw new IOException("La verificación falló en el byte " + (pos + i));
                }
            }
            pos += n;
            off += n;
            len -= n;
            if (p != null) p.add(n);
        }
    }
}
