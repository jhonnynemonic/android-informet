package com.usb.informer;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Vector;

/** Cliente FTP mínimo (modo pasivo) como fuente de archivos: sirve para leer una ISO de un servidor FTP, incluso el del propio teléfono. */
public class FtpFs implements FileSource {
    private String host, user, pass;
    private int port;
    private Socket ctl;
    private BufferedReader in;
    private OutputStream out;
    private boolean dirty = true;
    private boolean mlsd = true;
    private String cwd = "";

    public FtpFs(String host, int port, String user, String pass) {
        this.host = host;
        this.port = port;
        this.user = user.length() > 0 ? user : "anonymous";
        this.pass = pass.length() > 0 ? pass : "usbinformer@";
    }

    public String label() { return "FTP " + host; }

    // ------------------------------------------------------------ control

    /** Lee una respuesta completa (puede ser multilínea). Devuelve la última línea. */
    private String reply() throws IOException {
        String line = in.readLine();
        if (line == null) throw new IOException("El servidor FTP cerró la conexión");
        if (line.length() >= 4 && line.charAt(3) == '-') {
            String code = line.substring(0, 3) + " ";
            while (true) {
                String l = in.readLine();
                if (l == null) throw new IOException("El servidor FTP cerró la conexión");
                if (l.startsWith(code)) return l;
            }
        }
        return line;
    }

    private String cmd(String c) throws IOException {
        out.write((c + "\r\n").getBytes("UTF-8"));
        out.flush();
        return reply();
    }

    private static int code(String r) {
        try {
            return Integer.parseInt(r.substring(0, 3));
        } catch (Throwable t) {
            return 0;
        }
    }

    public synchronized void connect() throws Exception {
        close();
        ctl = new Socket();
        ctl.connect(new InetSocketAddress(host, port), 8000);
        ctl.setSoTimeout(30000);
        in = new BufferedReader(new InputStreamReader(ctl.getInputStream(), "UTF-8"));
        out = ctl.getOutputStream();
        String r = reply();
        if (code(r) != 220) throw new Exception("El servidor FTP no está listo: " + r);
        r = cmd("USER " + user);
        if (code(r) == 331) r = cmd("PASS " + pass);
        if (code(r) != 230) throw new Exception("Login FTP rechazado: " + r);
        cmd("OPTS UTF8 ON");
        r = cmd("TYPE I");
        if (code(r) != 200) throw new Exception("TYPE I rechazado: " + r);
        dirty = false;
        cwd = "";
    }

    public synchronized void close() {
        try {
            if (ctl != null) {
                try {
                    out.write("QUIT\r\n".getBytes());
                    out.flush();
                } catch (Throwable t) {
                    // ya cerrada
                }
                ctl.close();
            }
        } catch (Throwable t) {
            // nada
        }
        ctl = null;
        dirty = true;
    }

    private void ensure() throws Exception {
        if (dirty || ctl == null || ctl.isClosed()) connect();
    }

    private Socket pasv() throws Exception {
        String r = cmd("PASV");
        if (code(r) != 227) throw new Exception("PASV rechazado: " + r);
        int a = r.indexOf('(');
        int b = r.indexOf(')', a);
        if (a < 0 || b < 0) throw new Exception("Respuesta PASV no válida: " + r);
        String[] p = split(r.substring(a + 1, b), ',');
        if (p.length < 6) throw new Exception("Respuesta PASV no válida: " + r);
        int dp = Integer.parseInt(p[4].trim()) * 256 + Integer.parseInt(p[5].trim());
        Socket s = new Socket();
        s.connect(new InetSocketAddress(host, dp), 8000);   // siempre el mismo host que el control
        s.setSoTimeout(60000);
        return s;
    }

    private static String[] split(String s, char c) {
        Vector v = new Vector();
        int a = 0;
        for (int i = 0; i <= s.length(); i++) {
            if (i == s.length() || s.charAt(i) == c) {
                v.addElement(s.substring(a, i));
                a = i + 1;
            }
        }
        String[] r = new String[v.size()];
        for (int i = 0; i < r.length; i++) r[i] = (String) v.elementAt(i);
        return r;
    }

    private void chdir(String dir) throws Exception {
        if (dir.equals(cwd)) return;
        String r = cmd("CWD " + (dir.length() == 0 ? "/" : dir));
        if (code(r) != 250) throw new Exception("No puedo entrar en " + dir + ": " + r);
        cwd = dir;
    }

    // ------------------------------------------------------------ FileSource

    public synchronized Vector listRoot() throws Exception {
        ensure();
        return listDir("");
    }

    public synchronized Vector list(FileItem dir) throws Exception {
        ensure();
        return listDir((String) dir.ref);
    }

    private Vector listDir(String path) throws Exception {
        chdir(path);
        String text = null;
        boolean used = false;
        if (mlsd) {
            Socket d = pasv();
            String r = cmd("MLSD");
            if (code(r) == 150 || code(r) == 125) {
                text = readAll(d);
                r = reply();
                used = true;
            } else {
                d.close();
                mlsd = false;
            }
        }
        if (text == null) {
            Socket d = pasv();
            String r = cmd("LIST");
            if (code(r) != 150 && code(r) != 125) {
                d.close();
                throw new Exception("El servidor no permite listar: " + r);
            }
            text = readAll(d);
            reply();
        }
        return used ? parseMlsd(text, path) : parseList(text, path);
    }

    private String readAll(Socket d) throws IOException {
        try {
            InputStream is = d.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = is.read(b)) > 0) {
                bo.write(b, 0, n);
                if (bo.size() > 8 * 1024 * 1024) break;
            }
            return new String(bo.toByteArray(), "UTF-8");
        } finally {
            d.close();
        }
    }

    private static String join(String dir, String name) {
        return dir.endsWith("/") ? dir + name : dir + "/" + name;
    }

    private Vector parseMlsd(String text, String dir) {
        Vector dirs = new Vector();
        Vector files = new Vector();
        String[] lines = split(text, '\n');
        for (int i = 0; i < lines.length; i++) {
            String ln = lines[i].trim();
            int sp = ln.indexOf(' ');
            if (sp <= 0) continue;
            String facts = ln.substring(0, sp).toLowerCase();
            String name = ln.substring(sp + 1);
            if (name.equals(".") || name.equals("..")) continue;
            String type = "";
            long size = 0;
            String[] f = split(facts, ';');
            for (int k = 0; k < f.length; k++) {
                if (f[k].startsWith("type=")) type = f[k].substring(5);
                else if (f[k].startsWith("size=")) {
                    try {
                        size = Long.parseLong(f[k].substring(5));
                    } catch (Throwable t) {
                        // sin tamaño
                    }
                }
            }
            if (type.equals("cdir") || type.equals("pdir")) continue;
            add(dirs, files, name, type.equals("dir"), size, dir);
        }
        return merge(dirs, files);
    }

    /** Formato "ls -l" de Unix (el más habitual). */
    private Vector parseList(String text, String dir) {
        Vector dirs = new Vector();
        Vector files = new Vector();
        String[] lines = split(text, '\n');
        for (int i = 0; i < lines.length; i++) {
            String ln = lines[i].trim();
            if (ln.length() < 10 || ln.startsWith("total")) continue;
            char t = ln.charAt(0);
            if (t != 'd' && t != '-' && t != 'l') continue;
            // 8 campos separados por espacios antes del nombre: perm links owner group size mes dia hora/año
            int pos = 0;
            int field = 0;
            long size = 0;
            int len = ln.length();
            while (field < 8 && pos < len) {
                while (pos < len && ln.charAt(pos) == ' ') pos++;
                int st = pos;
                while (pos < len && ln.charAt(pos) != ' ') pos++;
                if (field == 4) {
                    try {
                        size = Long.parseLong(ln.substring(st, pos));
                    } catch (Throwable e) {
                        // sin tamaño
                    }
                }
                field++;
            }
            while (pos < len && ln.charAt(pos) == ' ') pos++;
            if (pos >= len) continue;
            String name = ln.substring(pos);
            int arrow = name.indexOf(" -> ");
            if (t == 'l' && arrow > 0) name = name.substring(0, arrow);
            if (name.equals(".") || name.equals("..")) continue;
            add(dirs, files, name, t == 'd', size, dir);
        }
        return merge(dirs, files);
    }

    private void add(Vector dirs, Vector files, String name, boolean isDir, long size, String dir) {
        FileItem it = new FileItem();
        it.name = name;
        it.dir = isDir;
        it.size = isDir ? 0 : size;
        it.ref = join(dir, name);
        FileItem.sortedAdd(isDir ? dirs : files, it);
    }

    private Vector merge(Vector dirs, Vector files) {
        for (int i = 0; i < files.size(); i++) dirs.addElement(files.elementAt(i));
        return dirs;
    }

    /** Lee un trozo del archivo (REST + RETR). Cierra después la conexión de control para no desincronizarla. */
    public synchronized byte[] readRange(FileItem f, long off, int len) throws Exception {
        long want = Math.min((long) len, f.size - off);
        Exception last = null;
        for (int t = 0; t < 8; t++) {
            try {
                byte[] b = readRange1(f, off, len);
                if (b.length >= want) return b;
                last = new Exception("Lectura FTP corta (" + b.length + " de " + want + ")");
            } catch (Exception e) {
                if (e.getMessage() != null && e.getMessage().indexOf("REST") >= 0) throw e;
                last = e;
            }
            close();
            try {
                Thread.sleep(500 + 1000 * t);   // espera y reconecta (wifi dormido, servidor lento...)
            } catch (InterruptedException ie) {
                throw last;
            }
        }
        throw last;
    }

    private byte[] readRange1(FileItem f, long off, int len) throws Exception {
        ensure();
        String path = (String) f.ref;
        int sl = path.lastIndexOf('/');
        chdir(sl > 0 ? path.substring(0, sl) : "");
        Socket d = pasv();
        try {
            String r = cmd("REST " + off);
            if (code(r) != 350) throw new Exception("El servidor FTP no admite leer por trozos (REST): " + r);
            r = cmd("RETR " + f.name);
            if (code(r) != 150 && code(r) != 125) throw new Exception("El servidor no deja leer el archivo: " + r);
            InputStream is = d.getInputStream();
            byte[] b = new byte[len];
            int got = 0;
            while (got < len) {
                int n = is.read(b, got, len - got);
                if (n <= 0) break;
                got += n;
            }
            if (got < len) {
                byte[] c = new byte[got];
                System.arraycopy(b, 0, c, 0, got);
                b = c;
            }
            return b;
        } finally {
            try {
                d.close();
            } catch (Throwable t) {
                // nada
            }
            close();
        }
    }

    public synchronized String preview(FileItem f, int max) throws Exception {
        final byte[] b = new byte[max];
        final int[] n = { 0 };
        OutputStream o = new OutputStream() {
            public void write(int v) throws IOException {
                write(new byte[] { (byte) v }, 0, 1);
            }

            public void write(byte[] d, int off, int len) throws IOException {
                int k = Math.min(len, b.length - n[0]);
                System.arraycopy(d, off, b, n[0], k);
                n[0] += k;
                if (n[0] >= b.length) throw new IOException("STOP");
            }
        };
        try {
            copy(f, o, null);
        } catch (IOException e) {
            if (n[0] < b.length) throw e;
        }
        return Preview.make(b, n[0], f.size);
    }

    public synchronized void copy(FileItem f, OutputStream o, Progress p) throws Exception {
        ensure();
        String path = (String) f.ref;
        int sl = path.lastIndexOf('/');
        chdir(sl > 0 ? path.substring(0, sl) : "");
        Socket d = pasv();
        String r = cmd("RETR " + f.name);
        if (code(r) != 150 && code(r) != 125) {
            d.close();
            throw new Exception("El servidor no deja leer el archivo: " + r);
        }
        boolean complete = false;
        try {
            InputStream is = d.getInputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = is.read(buf)) > 0) {
                if (p != null && p.cancelled()) throw new IOException("Cancelado");
                o.write(buf, 0, n);
                if (p != null) p.add(n);
            }
            complete = true;
        } finally {
            try {
                d.close();
            } catch (Throwable t) {
                // nada
            }
            if (complete) {
                String e = reply();
                if (code(e) != 226 && code(e) != 250) throw new Exception("Transferencia FTP incompleta: " + e);
            } else {
                // transferencia cortada: reconectamos para no desincronizar el canal de control
                close();
            }
        }
    }
}
