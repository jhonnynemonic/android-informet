package com.usb.informer;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.Vector;

/** Archivos y carpetas del teléfono (java.io.File) como árbol de origen para copiar a un USB. */
public class PhoneTree implements DiscTree {
    private final Vector roots;
    private final String name;
    private File openFile;
    private RandomAccessFile raf;

    /** roots: FileItem cuyo ref es un File. */
    public PhoneTree(Vector roots, String name) {
        this.roots = roots;
        this.name = name;
    }

    public String label() { return name; }

    public Vector listRoot() { return roots; }

    public Vector list(FileItem dir) throws Exception {
        File[] fs = ((File) dir.ref).listFiles();
        if (fs == null) throw new Exception("no puedo leer la carpeta " + dir.name);
        Vector dirs = new Vector(), files = new Vector();
        for (int i = 0; i < fs.length; i++) {
            FileItem it = new FileItem();
            it.name = fs[i].getName();
            it.dir = fs[i].isDirectory();
            it.size = it.dir ? 0 : fs[i].length();
            it.ref = fs[i];
            FileItem.sortedAdd(it.dir ? dirs : files, it);
        }
        for (int i = 0; i < files.size(); i++) dirs.addElement(files.elementAt(i));
        return dirs;
    }

    public synchronized int readAt(FileItem f, long off, byte[] dst, int len) throws Exception {
        File file = (File) f.ref;
        if (raf == null || !file.equals(openFile)) {
            close();
            raf = new RandomAccessFile(file, "r");
            openFile = file;
        }
        raf.seek(off);
        int n = raf.read(dst, 0, len);
        return n;
    }

    public long position(FileItem f) { return 0; }

    public synchronized void close() {
        if (raf != null) try { raf.close(); } catch (Throwable t) { }
        raf = null;
        openFile = null;
    }
}
