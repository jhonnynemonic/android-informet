package com.usb.informer;
import java.util.Vector;

/** Nodo del árbol del explorador USB (dispositivo > configuración > interfaz > endpoint). */
public class UsbNode {
    public String title;
    public String detail;
    public Vector children = new Vector();

    public UsbNode(String title, String detail) {
        this.title = title;
        this.detail = detail;
    }

    public UsbNode add(UsbNode n) {
        children.addElement(n);
        return n;
    }
}
