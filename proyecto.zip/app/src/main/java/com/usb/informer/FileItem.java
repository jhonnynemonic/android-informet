package com.usb.informer;
import java.util.Vector;

/** Elemento genérico (archivo o carpeta) de una fuente de archivos. */
public class FileItem {
    public String name;
    public boolean dir;
    public long size;
    public Object ref;
    /** Fuente a la que pertenece (solo lo usa UsbVolume cuando hay varias particiones). */
    public FileSource owner;

    public static void sortedAdd(Vector v, FileItem e) {
        int i = 0;
        String n = e.name.toLowerCase();
        while (i < v.size() && ((FileItem) v.elementAt(i)).name.toLowerCase().compareTo(n) <= 0) i++;
        v.insertElementAt(e, i);
    }
}
