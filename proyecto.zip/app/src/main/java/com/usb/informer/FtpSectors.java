package com.usb.informer;
/** ISO guardada en un servidor FTP (usa REST para leer trozos). */
public class FtpSectors extends WindowSectors {
    private FtpFs ftp;
    private FileItem f;

    public FtpSectors(FtpFs ftp, FileItem f) {
        super(f.size, 4 * 1024 * 1024);
        this.ftp = ftp;
        this.f = f;
    }

    protected byte[] fetch(long off, int len) throws Exception {
        return ftp.readRange(f, off, len);
    }
}
