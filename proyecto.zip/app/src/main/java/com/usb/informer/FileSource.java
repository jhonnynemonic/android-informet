package com.usb.informer;
import java.io.OutputStream;
import java.util.Vector;

/** Algo de lo que se pueden listar y copiar archivos: un disco ISO 9660 o un volumen montado. */
public interface FileSource {
    String label();
    Vector listRoot() throws Exception;
    Vector list(FileItem dir) throws Exception;
    String preview(FileItem f, int max) throws Exception;
    void copy(FileItem f, OutputStream out, Progress p) throws Exception;
}
