package com.usb.informer;
/** ISO guardada en un archivo de un USB leído directamente (FAT/exFAT). */
public class BlockSectors extends WindowSectors {
    private BlockFs fs;
    private FileItem f;

    public BlockSectors(BlockFs fs, FileItem f) {
        super(f.size, 1024 * 1024);
        this.fs = fs;
        this.f = f;
    }

    protected byte[] fetch(long off, int len) throws Exception {
        return fs.readFileRange(f, off, len);
    }
}
