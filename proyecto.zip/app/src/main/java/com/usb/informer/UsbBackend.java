package com.usb.informer;
import java.util.Vector;

public interface UsbBackend {
    String getName();
    /** Devuelve null si todo va bien, o un mensaje de error. */
    String start(UsbListener l);
    void stop();
    /** Vector de UsbDevInfo con los dispositivos conectados ahora. */
    Vector getDevices();
}
