package com.usb.informer;
import java.util.Vector;

/** Presenta un sistema de archivos montado (FAT/exFAT/NTFS, con una o varias particiones) como árbol para FatWriter. */
public class FsTree implements DiscTree {
    private FileSource fs;

    public FsTree(FileSource fs) {
        this.fs = fs;
    }

    public String label() {
        String l = fs.label();
        return l == null ? "" : l;
    }

    public Vector listRoot() throws Exception {
        return fs.listRoot();
    }

    public Vector list(FileItem dir) throws Exception {
        return fs.list(dir);
    }

    private BlockFs owner(FileItem f) {
        if (f.owner instanceof BlockFs) return (BlockFs) f.owner;
        if (fs instanceof BlockFs) return (BlockFs) fs;
        return null;
    }

    public int readAt(FileItem f, long off, byte[] dst, int len) throws Exception {
        BlockFs b = owner(f);
        if (b == null) throw new Exception("No sé leer " + f.name);
        if (off >= f.size) return -1;
        byte[] r = b.readFileRange(f, off, Math.min(len, 65536));
        if (r.length == 0) return -1;
        System.arraycopy(r, 0, dst, 0, r.length);
        return r.length;
    }

    public long position(FileItem f) {
        BlockFs b = owner(f);
        return b == null ? 0 : b.position(f);
    }
}
