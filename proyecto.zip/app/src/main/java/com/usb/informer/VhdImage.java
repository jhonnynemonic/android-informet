package com.usb.informer;
import java.io.OutputStream;

/** El disco virtual completo de un VHD como imagen: se vuelca a un USB sector a sector (clon exacto). */
public class VhdImage implements ImageSource {
    private VhdDisc disc;
    private String name;

    public VhdImage(VhdDisc disc, String name) {
        this.disc = disc;
        this.name = name;
    }

    public String name() { return name; }

    public long size() { return disc.virtualSize() / 512 * 512; }

    public void pump(OutputStream out, Progress p) throws Exception {
        long total = size();
        long lba = 0;
        int chunk = 2048;                       // 1 MB por vuelta
        while (lba * 512 < total) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            int n = (int) Math.min(chunk, total / 512 - lba);
            out.write(disc.read((int) lba, n), 0, n * 512);
            lba += n;
        }
    }
}
