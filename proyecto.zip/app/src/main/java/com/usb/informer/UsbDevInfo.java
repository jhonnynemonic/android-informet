package com.usb.informer;
import java.util.Vector;

/** Datos de un dispositivo USB, con los mismos campos que muestra la app de Android. */
public class UsbDevInfo {
    public String deviceName = "";
    public int vendorId;
    public int productId;
    public int id;
    public String version = "";
    public int devClass;
    public int subClass;
    public int protocol;
    public String manufacturer;
    public String productName;
    public String serial;
    /** Nodos de configuración (UsbNode) para el explorador. */
    public Vector configs = new Vector();
    /** Objeto nativo del backend (por ejemplo android.hardware.usb.UsbDevice). */
    public Object raw;
    public boolean needsPermission;
    /** true si parece una unidad de CD/DVD. */
    public boolean optical;
    /** true si tiene una interfaz de almacenamiento masivo (clase 8). */
    public boolean mass;
    /** Texto adicional que se añade al final de la ficha (o null). */
    public String extra;

    public String toText() {
        return "Device Name: " + deviceName + "\n"
                + "Vendor ID   : " + vendorId + " (" + UsbUtil.hex(vendorId, 4) + ")\n"
                + "Product ID  : " + productId + " (" + UsbUtil.hex(productId, 4) + ")\n"
                + "Version     : " + version + "\n"
                + "Subclass    : " + subClass + "\n"
                + "Protocol    : " + protocol + "\n"
                + "Manufacturer: " + UsbUtil.nz(manufacturer) + "\n"
                + "Class       : " + devClass + " (" + UsbUtil.className(devClass) + ")\n"
                + "ID          : " + id + "\n"
                + "Product Name: " + UsbUtil.nz(productName) + "\n"
                + "Serial      : " + UsbUtil.nz(serial)
                + (extra != null ? "\n" + extra : "");
    }

    public String label() {
        String p = (productName == null || productName.length() == 0) ? "USB" : productName;
        return UsbUtil.hex(vendorId, 4).substring(2) + ":" + UsbUtil.hex(productId, 4).substring(2) + " " + p;
    }

    private String descriptorText() {
        return "idVendor: " + UsbUtil.hex(vendorId, 4) + "\n"
                + "idProduct: " + UsbUtil.hex(productId, 4) + "\n"
                + "bcdDevice: " + version + "\n"
                + "bDeviceClass: " + UsbUtil.hex(devClass, 2) + " (" + UsbUtil.className(devClass) + ")\n"
                + "bDeviceSubClass: " + UsbUtil.hex(subClass, 2) + "\n"
                + "bDeviceProtocol: " + UsbUtil.hex(protocol, 2) + "\n"
                + "Fabricante: " + UsbUtil.nz(manufacturer) + "\n"
                + "Producto: " + UsbUtil.nz(productName) + "\n"
                + "Serie: " + UsbUtil.nz(serial) + "\n"
                + "Configuraciones leídas: " + configs.size();
    }

    /** Árbol para el explorador: dispositivo > descriptor + configuraciones > interfaces > endpoints. */
    public UsbNode toNode() {
        UsbNode root = new UsbNode(label(), toText());
        root.add(new UsbNode("Descriptor de dispositivo", descriptorText()));
        for (int i = 0; i < configs.size(); i++) root.add((UsbNode) configs.elementAt(i));
        return root;
    }
}
