package com.usb.informer;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.os.Bundle;
import android.view.WindowManager;

import javax.microedition.lcdui.UiHost;

/** Pantalla única de la aplicación: arranca el MIDlet "USB Informer" y le presta la interfaz. */
public class MainActivity extends Activity {
    private static UsbMidlet midlet;
    private static boolean askedFiles;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        AndroidBridge.appContext = getApplicationContext();
        UiHost.attach(this);
        if (midlet == null) {
            midlet = new UsbMidlet();
            UiHost.events(new Runnable() {
                public void run() {
                    try { midlet.startApp(); } catch (Throwable t) { t.printStackTrace(); }
                }
            });
        }
    }

    /** Pide una sola vez por arranque el permiso para ver los archivos del teléfono. */
    @Override
    protected void onResume() {
        super.onResume();
        if (askedFiles || hasFileAccess()) return;
        askedFiles = true;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
                } catch (Throwable t) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                }
            } else {
                requestPermissions(new String[] { "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE" }, 1);
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    private boolean hasFileAccess() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) return Environment.isExternalStorageManager();
            return checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return true;
        }
    }

    @Override
    public void onBackPressed() {
        if (!UiHost.onBack()) moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isFinishing() && midlet != null) {
            try { midlet.destroyApp(true); } catch (Throwable t) { t.printStackTrace(); }
            midlet = null;
        }
    }
}
