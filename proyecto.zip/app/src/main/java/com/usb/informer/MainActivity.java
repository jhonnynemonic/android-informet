package com.usb.informer;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;

import javax.microedition.lcdui.UiHost;

/** Pantalla única de la aplicación: arranca el MIDlet "USB Informer" y le presta la interfaz. */
public class MainActivity extends Activity {
    private static UsbMidlet midlet;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        AndroidBridge.appContext = getApplicationContext();
        UiHost.attach(this);
        if (midlet == null) {
            midlet = new UsbMidlet();
            UiHost.events(new Runnable() {
                public void run() {
                    try { midlet.startApp(); } catch (Throwable t) { t.printStackTrace(); }
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (!UiHost.onBack()) moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isFinishing() && midlet != null) {
            try { midlet.destroyApp(true); } catch (Throwable t) { t.printStackTrace(); }
            midlet = null;
        }
    }
}
