package com.usb.informer;
import java.util.Vector;

/** Lector UDF (1.02 a 2.01, partición normal). Es el sistema de archivos real de las ISO de Windows. */
public class UdfDisc implements DiscTree {
    private Sectors d;
    private long partStart;
    private String label = "";
    private long rootIcb;

    public static boolean present(Sectors s) {
        try {
            byte[] b = s.read(256, 1);
            return u16(b, 0) == 2;
        } catch (Throwable t) {
            return false;
        }
    }

    public UdfDisc(Sectors s) throws Exception {
        d = s;
        if (s.sectorSize() != 2048) throw new Exception("UDF: sector de 2048 bytes requerido");
        byte[] a = d.read(256, 1);
        if (u16(a, 0) != 2) throw new Exception("No hay UDF (falta el anclaje en el sector 256)");
        long vdsLen = u32(a, 16), vdsLoc = u32(a, 20);
        boolean havePd = false;
        long fsdLbn = -1;
        int mapPart = -1;
        long sectors = Math.min(vdsLen / 2048, 64);
        int pdNum = -1;
        for (int i = 0; i < sectors; i++) {
            byte[] b = d.read((int) (vdsLoc + i), 1);
            int id = u16(b, 0);
            if (id == 8 || id == 0) break;
            if (id == 5) {
                pdNum = u16(b, 22);
                partStart = u32(b, 188);
                havePd = true;
            } else if (id == 6) {
                if (u32(b, 212) != 2048) throw new Exception("UDF: tamaño de bloque no admitido");
                label = dstring(b, 84, 128);
                fsdLbn = u32(b, 252);
                int maps = (int) u32(b, 268);
                int o = 440;
                for (int m = 0; m < maps && m < 4; m++) {
                    int type = b[o] & 0xFF, len = b[o + 1] & 0xFF;
                    if (type == 2) {
                        String ident = new String(b, o + 5, Math.min(23, len - 5), "ISO-8859-1");
                        if (ident.indexOf("Metadata") >= 0) {
                            throw new Exception("UDF 2.50 con partición de metadatos: no soportado todavía");
                        }
                        if (ident.indexOf("Virtual") >= 0) throw new Exception("UDF virtual (multisesión): no soportado");
                    }
                    if (m == 0) mapPart = type == 1 ? u16(b, o + 4) : u16(b, o + 38);
                    o += len;
                }
            }
        }
        if (!havePd || fsdLbn < 0) throw new Exception("UDF: descriptores de volumen incompletos");
        byte[] fsd = d.read((int) (partStart + fsdLbn), 1);
        if (u16(fsd, 0) != 256) throw new Exception("UDF: no encuentro el File Set Descriptor");
        rootIcb = u32(fsd, 404);
        if (label.length() == 0) label = "Disco";
    }

    public String label() { return label; }

    public long position(FileItem f) {
        Object[] r = (Object[]) f.ref;
        long[] ext = (long[]) r[1];
        return ext != null && ext.length > 0 ? ext[0] : 0;
    }

    // ------------------------------------------------------------ entradas

    /** Devuelve {tipo, tamaño, alloc extents (lba abs, len)...} o null. */
    private Object[] readEntry(long lbn) throws Exception {
        byte[] b = d.read((int) (partStart + lbn), 1);
        int id = u16(b, 0);
        if (id != 261 && id != 266) throw new Exception("UDF: entrada de archivo no válida (" + id + ")");
        int ftype = b[27] & 0xFF;
        int flags = u16(b, 34);
        long info = u64(b, 56);
        int lEa, lAd, base;
        if (id == 261) {
            lEa = (int) u32(b, 168);
            lAd = (int) u32(b, 172);
            base = 176;
        } else {
            lEa = (int) u32(b, 208);
            lAd = (int) u32(b, 212);
            base = 216;
        }
        int at = flags & 7;
        if (at == 3) {
            byte[] emb = new byte[lAd];
            System.arraycopy(b, base + lEa, emb, 0, Math.min(lAd, 2048 - base - lEa));
            return new Object[] { new Integer(ftype), new Long(info), null, emb };
        }
        Vector ext = new Vector();
        byte[] ad = new byte[lAd];
        System.arraycopy(b, base + lEa, ad, 0, Math.min(lAd, 2048 - base - lEa));
        collect(ad, lAd, at, ext);
        long[] e = new long[ext.size()];
        for (int i = 0; i < e.length; i++) e[i] = ((Long) ext.elementAt(i)).longValue();
        return new Object[] { new Integer(ftype), new Long(info), e, null };
    }

    private void collect(byte[] ad, int len, int at, Vector out) throws Exception {
        int step = at == 0 ? 8 : (at == 1 ? 16 : 20);
        for (int o = 0; o + step <= len; o += step) {
            long l = u32(ad, o);
            int type = (int) (l >> 30);
            long n = l & 0x3FFFFFFFL;
            long lbn = u32(ad, o + 4);
            if (n == 0) break;
            if (type == 3) {
                byte[] aed = d.read((int) (partStart + lbn), 1);
                if (u16(aed, 0) != 258) throw new Exception("UDF: extensión de asignación rota");
                int lad = (int) u32(aed, 20);
                byte[] more = new byte[lad];
                System.arraycopy(aed, 24, more, 0, Math.min(lad, 2024));
                collect(more, lad, at, out);
                return;
            }
            // type 0 = grabado; 1 = reservado sin grabar (ceros); 2 = sin asignar (ceros)
            out.addElement(new Long(type == 0 ? partStart + lbn : -1));
            out.addElement(new Long(n));
        }
    }

    private byte[] readAll(Object[] e, long max) throws Exception {
        long size = ((Long) e[1]).longValue();
        if (size > max) throw new Exception("UDF: carpeta demasiado grande");
        byte[] out = new byte[(int) size];
        if (e[3] != null) {
            byte[] emb = (byte[]) e[3];
            System.arraycopy(emb, 0, out, 0, Math.min(emb.length, out.length));
            return out;
        }
        long[] ext = (long[]) e[2];
        int pos = 0;
        for (int i = 0; i + 1 < ext.length && pos < out.length; i += 2) {
            long lba = ext[i], n = ext[i + 1];
            int want = (int) Math.min(n, out.length - pos);
            if (lba >= 0) {
                int done = 0;
                while (done < want) {
                    int cnt = Math.min(32, (want - done + 2047) / 2048);
                    byte[] r = d.read((int) (lba + done / 2048), cnt);
                    int c = Math.min(r.length, want - done);
                    System.arraycopy(r, 0, out, pos + done, c);
                    done += cnt * 2048;
                }
            }
            pos += want;
        }
        return out;
    }

    public Vector listRoot() throws Exception {
        return listIcb(rootIcb);
    }

    public Vector list(FileItem dir) throws Exception {
        return listIcb(((long[]) ((Object[]) dir.ref)[0])[0]);
    }

    private Vector listIcb(long lbn) throws Exception {
        Object[] e = readEntry(lbn);
        byte[] data = readAll(e, 64L * 1024 * 1024);
        Vector dirs = new Vector();
        Vector files = new Vector();
        int p = 0;
        while (p + 38 <= data.length) {
            if (u16(data, p) != 257) break;
            int chars = data[p + 18] & 0xFF;
            int lfi = data[p + 19] & 0xFF;
            long icb = u32(data, p + 24);
            int liu = u16(data, p + 36);
            int total = (38 + liu + lfi + 3) & ~3;
            if ((chars & 0x0C) == 0 && lfi > 0) {
                String name = decodeName(data, p + 38 + liu, lfi);
                FileItem it = new FileItem();
                it.name = name;
                it.dir = (chars & 2) != 0;
                if (it.dir) {
                    it.ref = new Object[] { new long[] { icb }, null };
                    it.size = 0;
                    FileItem.sortedAdd(dirs, it);
                } else {
                    Object[] fe = readEntry(icb);
                    int ft = ((Integer) fe[0]).intValue();
                    if (ft != 5 && ft != 0) continue; // enlaces, dispositivos...
                    it.size = ((Long) fe[1]).longValue();
                    it.ref = new Object[] { new long[] { icb }, fe[2], fe[3], new Long(it.size) };
                    FileItem.sortedAdd(files, it);
                }
            }
            p += total;
        }
        for (int i = 0; i < files.size(); i++) dirs.addElement(files.elementAt(i));
        return dirs;
    }

    public int readAt(FileItem f, long off, byte[] dst, int len) throws Exception {
        Object[] r = (Object[]) f.ref;
        long size = f.size;
        if (off >= size) return -1;
        len = (int) Math.min(len, Math.min(size - off, 65536));
        byte[] emb = (byte[]) r[2];
        if (emb != null) {
            int c = (int) Math.min(len, emb.length - off);
            if (c <= 0) return -1;
            System.arraycopy(emb, (int) off, dst, 0, c);
            return c;
        }
        long[] ext = (long[]) r[1];
        long pos = 0;
        for (int i = 0; i + 1 < ext.length; i += 2) {
            long n = ext[i + 1];
            if (off < pos + n) {
                long inExt = off - pos;
                int c = (int) Math.min(len, n - inExt);
                if (ext[i] < 0) {
                    for (int k = 0; k < c; k++) dst[k] = 0;
                    return c;
                }
                long first = ext[i] + inExt / 2048;
                int skip = (int) (inExt % 2048);
                int sectors = (skip + c + 2047) / 2048;
                byte[] b = d.read((int) first, sectors);
                System.arraycopy(b, skip, dst, 0, c);
                return c;
            }
            pos += n;
        }
        return -1;
    }

    // ------------------------------------------------------------ utilidades

    private static String decodeName(byte[] b, int o, int len) {
        int comp = b[o] & 0xFF;
        StringBuffer sb = new StringBuffer();
        if (comp == 8) {
            for (int i = 1; i < len; i++) sb.append((char) (b[o + i] & 0xFF));
        } else if (comp == 16) {
            for (int i = 1; i + 1 < len; i += 2) sb.append((char) (((b[o + i] & 0xFF) << 8) | (b[o + i + 1] & 0xFF)));
        } else {
            for (int i = 1; i < len; i++) sb.append((char) (b[o + i] & 0xFF));
        }
        return sb.toString();
    }

    private static String dstring(byte[] b, int o, int max) {
        int len = b[o + max - 1] & 0xFF;
        if (len == 0) return "";
        return decodeName(b, o, Math.min(len, max - 1));
    }

    private static int u16(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8); }

    private static long u32(byte[] b, int o) {
        return (b[o] & 0xFFL) | ((b[o + 1] & 0xFFL) << 8) | ((b[o + 2] & 0xFFL) << 16) | ((b[o + 3] & 0xFFL) << 24);
    }

    private static long u64(byte[] b, int o) { return u32(b, o) | (u32(b, o + 4) << 32); }
}
