package com.usb.informer;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Vector;

/** Copia de archivos a la memoria del teléfono. */
public class Phone {
    /** true si no se pudo usar la carpeta Descargas y se usó la carpeta de la app. */
    public static boolean fallback;

    public static boolean isPc() {
        if (System.getProperty("usbinformer.android") != null) return false;
        try {
            Class.forName("android.os.Build");
            return false;
        } catch (Throwable t) {
            return true;
        }
    }

    /** Registro de diagnóstico (solo en PC): Descargas/USB-Informer/USB-Informer.log */
    public static void log(String text) {
        if (!isPc()) return;
        try {
            java.io.FileWriter w = new java.io.FileWriter(new File(destRoot(null), "USB-Informer.log"), true);
            try {
                w.write(new java.util.Date() + "  " + text + "\r\n");
            } finally {
                w.close();
            }
        } catch (Throwable t) {
            // sin registro
        }
    }

    public static File destRoot(Object ctx) {
        fallback = false;
        String t = System.getProperty("usbinformer.dest");
        if (t != null) {
            File f = new File(t);
            f.mkdirs();
            return f;
        }
        if (isPc()) {
            File home = new File(System.getProperty("user.home", "."));
            File dl = new File(home, "Downloads");
            File f = new File(dl.exists() ? dl : home, "USB-Informer");
            f.mkdirs();
            return f;
        }
        File dl = new File("/storage/emulated/0/Download/USB-Informer");
        if (writable(dl)) return dl;
        fallback = true;
        try {
            Object o = AndroidBridge.call(ctx, "android.content.Context", "getExternalFilesDir",
                    new Class[] { String.class }, new Object[] { null });
            if (o != null) {
                File g = new File(o.toString(), "USB-Informer");
                if (writable(g)) return g;
            }
        } catch (Throwable e) {
            // siguiente opción
        }
        try {
            Object o = AndroidBridge.call0(ctx, "android.content.Context", "getFilesDir");
            if (o != null) {
                File g = new File(o.toString(), "USB-Informer");
                if (writable(g)) return g;
            }
        } catch (Throwable e) {
            // siguiente opción
        }
        File g = new File(System.getProperty("java.io.tmpdir", "."), "USB-Informer");
        g.mkdirs();
        return g;
    }

    private static boolean writable(File d) {
        try {
            d.mkdirs();
            File p = new File(d, ".probe");
            FileOutputStream o = new FileOutputStream(p);
            o.write(1);
            o.close();
            p.delete();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static String safe(String name) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            sb.append("/\\:*?\"<>|".indexOf(c) >= 0 || c < 32 ? '_' : c);
        }
        String s = sb.toString().trim();
        return s.length() == 0 ? "archivo" : s;
    }

    public static File unique(File dir, String name) {
        File f = new File(dir, safe(name));
        int k = 1;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        while (f.exists()) {
            f = new File(dir, safe(base) + " (" + k + ")" + ext);
            k++;
        }
        return f;
    }

    /** Destino de una copia: Descargas vía MediaStore (sin permisos) o, si falla, una carpeta de archivos. */
    public static class Out {
        public java.io.OutputStream os;
        public String where = "";
        public long size;
        Object uri;
        Object resolver;
        File file;

        public void abort() {
            try {
                os.close();
            } catch (Throwable t) {
                // ignorar
            }
            try {
                if (file != null) file.delete();
                if (uri != null) {
                    AndroidBridge.call(resolver, "android.content.ContentResolver", "delete",
                            new Class[] { Class.forName("android.net.Uri"), String.class, String[].class },
                            new Object[] { uri, null, null });
                }
            } catch (Throwable t) {
                // ignorar
            }
        }
    }

    private static String mime(String n) {
        String l = n.toLowerCase();
        if (l.endsWith(".wav")) return "audio/x-wav";
        if (l.endsWith(".vob") || l.endsWith(".mpg")) return "video/mpeg";
        if (l.endsWith(".txt")) return "text/plain";
        if (l.endsWith(".jpg") || l.endsWith(".jpeg")) return "image/jpeg";
        if (l.endsWith(".png")) return "image/png";
        if (l.endsWith(".pdf")) return "application/pdf";
        return "application/octet-stream";
    }

    /** Crea un archivo de salida en Descargas/USB-Informer/<rel>/<name>. rel usa "/" como separador. */
    public static Out create(String rel, String name) throws Exception {
        Out o = new Out();
        String t = System.getProperty("usbinformer.dest");
        if (t == null && !isPc()) {
            try {
                Object ctx = AndroidBridge.context();
                Object res = AndroidBridge.call0(ctx, "android.content.Context", "getContentResolver");
                Class cvc = Class.forName("android.content.ContentValues");
                Object cv = cvc.newInstance();
                Class[] ss = { String.class, String.class };
                AndroidBridge.call(cv, "android.content.ContentValues", "put", ss, new Object[] { "_display_name", safe(name) });
                AndroidBridge.call(cv, "android.content.ContentValues", "put", ss, new Object[] { "mime_type", mime(name) });
                AndroidBridge.call(cv, "android.content.ContentValues", "put", ss,
                        new Object[] { "relative_path", "Download/USB-Informer" + (rel.length() > 0 ? "/" + rel : "") });
                Object base = AndroidBridge.callStatic("android.net.Uri", "parse", new Class[] { String.class },
                        new Object[] { "content://media/external/downloads" });
                Class uc = Class.forName("android.net.Uri");
                Object uri = AndroidBridge.call(res, "android.content.ContentResolver", "insert",
                        new Class[] { uc, cvc }, new Object[] { base, cv });
                if (uri != null) {
                    Object os = AndroidBridge.call(res, "android.content.ContentResolver", "openOutputStream",
                            new Class[] { uc }, new Object[] { uri });
                    if (os != null) {
                        o.os = (java.io.OutputStream) os;
                        o.uri = uri;
                        o.resolver = res;
                        o.where = "Descargas/USB-Informer" + (rel.length() > 0 ? "/" + rel : "");
                        return o;
                    }
                }
            } catch (Throwable e) {
                // seguimos con archivos normales
            }
        }
        File root = destRoot(AndroidBridge.context());
        File dir = rel.length() > 0 ? new File(root, rel) : root;
        dir.mkdirs();
        File f = unique(dir, name);
        o.file = f;
        o.os = new FileOutputStream(f);
        o.where = f.getParentFile().getPath();
        return o;
    }

    /** Copia un archivo o una carpeta (recursivamente) a rel. */
    public static void copyItem(FileSource src, FileItem it, String rel, Progress p, int[] count, int depth, String[] where) throws Exception {
        if (depth > 24) return;
        if (p != null && p.cancelled()) throw new Exception("Cancelado");
        String sub = rel.length() > 0 ? rel + "/" + safe(it.name) : safe(it.name);
        if (it.dir) {
            Vector ch;
            try {
                ch = src.list(it);
            } catch (Exception e) {
                skip(rel, it.name, e);
                return;
            }
            for (int i = 0; i < ch.size(); i++) {
                try {
                    copyItem(src, (FileItem) ch.elementAt(i), sub, p, count, depth + 1, where);
                } catch (Exception e) {
                    if (p != null && p.cancelled()) throw e;
                    skip(sub, ((FileItem) ch.elementAt(i)).name, e);
                }
            }
            return;
        }
        log("copiando " + it.name + " (" + it.size + " bytes)");
        Out out = create(rel, it.name);
        where[0] = out.where;
        if (p != null) p.file(it.name);
        boolean ok = false;
        try {
            src.copy(it, out.os, p);
            ok = true;
        } finally {
            if (ok) out.os.close();
            else out.abort();
        }
        count[0]++;
        log("ok " + it.name);
    }

    /** Elementos que no se pudieron leer (carpetas del sistema, archivos bloqueados...). */
    public static Vector skipped = new Vector();

    private static void skip(String rel, String name, Exception e) {
        String m = (rel.length() > 0 ? rel + "/" : "") + name;
        skipped.addElement(m);
        log("omitido " + m + ": " + e);
    }

    public static String skippedText() {
        if (skipped.size() == 0) return "";
        StringBuffer sb = new StringBuffer("\n\nOmitidos (sin acceso): " + skipped.size());
        for (int i = 0; i < skipped.size() && i < 5; i++) sb.append("\n- ").append((String) skipped.elementAt(i));
        if (skipped.size() > 5) sb.append("\n...");
        return sb.toString();
    }

    public static String sizeText(long n) {
        if (n < 1024) return n + " B";
        if (n < 1024 * 1024) return (n / 1024) + " KB";
        if (n < 1024L * 1024 * 1024) return (n / (1024 * 1024)) + "." + ((n % (1024 * 1024)) * 10 / (1024 * 1024)) + " MB";
        return (n / (1024L * 1024 * 1024)) + "." + ((n % (1024L * 1024 * 1024)) * 10 / (1024L * 1024 * 1024)) + " GB";
    }
}
