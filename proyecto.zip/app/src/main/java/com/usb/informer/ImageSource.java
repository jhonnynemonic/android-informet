package com.usb.informer;
import java.io.OutputStream;

/** Una imagen de disco (ISO) que se puede volcar a un USB. */
public interface ImageSource {
    String name();

    long size();

    /** Envía todo el contenido, en orden, a out. */
    void pump(OutputStream out, Progress p) throws Exception;
}
