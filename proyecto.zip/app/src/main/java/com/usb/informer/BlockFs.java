package com.usb.informer;
import java.io.OutputStream;
import java.util.Vector;

/** Base de un sistema de archivos leído directamente de un dispositivo de bloques USB (solo lectura). */
public abstract class BlockFs implements FileSource {
    protected OpticalDisc d;
    protected long baseBytes;
    protected String vol = "USB";
    private byte[] cache;
    private long cacheOff = -1;
    private static final int CH = 32768;

    public abstract String typeName();

    /** Tramos del archivo: Vector de long[] { desplazamiento en el sistema de archivos, longitud }. */
    protected abstract Vector extents(FileItem f) throws Exception;

    public String label() { return vol; }

    /** Posición del primer dato del archivo en el disco (para leer en orden). */
    public long position(FileItem f) {
        try {
            Vector r = extents(f);
            if (r.size() > 0) return baseBytes + ((long[]) r.elementAt(0))[0];
        } catch (Throwable t) {
            // sin posición: se lee donde toque
        }
        return 0;
    }

    /** Lectura sin caché de len bytes a partir de off (dentro del sistema de archivos). */
    protected byte[] readRaw(long off, int len) throws Exception {
        int bs = d.blockSize;
        long abs = baseBytes + off;
        byte[] out = new byte[len];
        int got = 0;
        while (got < len) {
            long a = abs + got;
            long blk = a / bs;
            int skip = (int) (a % bs);
            int n = Math.min(len - got, 128 * bs - skip);
            int count = (skip + n + bs - 1) / bs;
            byte[] b = d.read((int) blk, count);
            System.arraycopy(b, skip, out, got, n);
            got += n;
        }
        return out;
    }

    /** Lee n bytes de un tramo a partir de pos; los tramos con desplazamiento -1 son huecos (ceros). */
    protected byte[] readRun(long[] r, long pos, int n) throws Exception {
        if (r[0] < 0) return new byte[n];
        return readRaw(r[0] + pos, n);
    }

    /** Lectura con caché, para metadatos (tabla FAT, directorios). */
    protected byte[] readBytes(long off, int len) throws Exception {
        byte[] out = new byte[len];
        int got = 0;
        while (got < len) {
            long o = off + got;
            long co = (o / CH) * CH;
            if (cache == null || co != cacheOff) {
                try {
                    cache = readRaw(co, CH);
                    cacheOff = co;
                } catch (Exception e) {
                    byte[] rest = readRaw(o, len - got);
                    System.arraycopy(rest, 0, out, got, rest.length);
                    return out;
                }
            }
            int in = (int) (o - co);
            int n = Math.min(len - got, CH - in);
            System.arraycopy(cache, in, out, got, n);
            got += n;
        }
        return out;
    }

    private FileItem rangeItem;
    private Vector rangeRuns;

    /** Lee len bytes de un archivo desde off (acceso aleatorio). */
    public synchronized byte[] readFileRange(FileItem f, long off, int len) throws Exception {
        if (off >= f.size) return new byte[0];
        len = (int) Math.min(len, f.size - off);
        if (rangeItem != f) {
            rangeRuns = extents(f);
            rangeItem = f;
        }
        byte[] out = new byte[len];
        long runStart = 0;
        long cur = off;
        int got = 0;
        for (int i = 0; i < rangeRuns.size() && got < len; i++) {
            long[] r = (long[]) rangeRuns.elementAt(i);
            long runEnd = runStart + r[1];
            if (cur < runEnd) {
                int n = (int) Math.min(len - got, runEnd - cur);
                byte[] part = readRun(r, cur - runStart, n);
                System.arraycopy(part, 0, out, got, n);
                got += n;
                cur += n;
            }
            runStart = runEnd;
        }
        if (got < len) {
            byte[] c = new byte[got];
            System.arraycopy(out, 0, c, 0, got);
            return c;
        }
        return out;
    }

    public String preview(FileItem f, int max) throws Exception {
        int n = (int) Math.min(f.size, max);
        if (n <= 0) return "(archivo vacío)";
        byte[] b = new byte[n];
        int got = 0;
        Vector runs = extents(f);
        for (int i = 0; i < runs.size() && got < n; i++) {
            long[] r = (long[]) runs.elementAt(i);
            int take = (int) Math.min(r[1], n - got);
            byte[] part = readRun(r, 0, take);
            System.arraycopy(part, 0, b, got, take);
            got += take;
        }
        return Preview.make(b, got, f.size);
    }

    public void copy(FileItem f, OutputStream out, Progress p) throws Exception {
        long left = f.size;
        Vector runs = extents(f);
        for (int i = 0; i < runs.size() && left > 0; i++) {
            long[] r = (long[]) runs.elementAt(i);
            long len = Math.min(r[1], left);
            long pos = 0;
            while (pos < len) {
                if (p != null && p.cancelled()) throw new Exception("Cancelado");
                int n = (int) Math.min(65536, len - pos);
                byte[] b = readRun(r, pos, n);
                out.write(b);
                pos += n;
                left -= n;
                if (p != null) p.add(n);
            }
        }
    }

    protected static int le16(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8);
    }

    protected static long le32(byte[] b, int o) {
        return (b[o] & 0xFFL) | ((b[o + 1] & 0xFFL) << 8) | ((b[o + 2] & 0xFFL) << 16) | ((b[o + 3] & 0xFFL) << 24);
    }

    protected static long le64(byte[] b, int o) {
        return le32(b, o) | (le32(b, o + 4) << 32);
    }
}
