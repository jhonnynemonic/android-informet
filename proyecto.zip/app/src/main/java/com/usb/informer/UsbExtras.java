package com.usb.informer;
import java.util.Vector;

/** Funciones extra de un backend: permisos y acceso al contenido del USB. */
public interface UsbExtras {
    /** Pide permiso a Android para los dispositivos que no lo tengan. Devuelve un mensaje. */
    String requestPermissions();

    /** Descripciones de los volúmenes de almacenamiento (Vector de String). */
    Vector storageNames();

    /** Abre el explorador de archivos del sistema en ese volumen. null = bien, si no, el error. */
    String openStorage(int index);

    /** Abre el explorador de archivos del sistema sin elegir volumen. null = bien. */
    String openFileManager();

    /** Abre una unidad óptica para leer el disco directamente. */
    OpticalDisc openDisc(UsbDevInfo d) throws Exception;

    /** Abre el dispositivo de almacenamiento para leerlo directamente (optical=false: pendrive). */
    OpticalDisc openDisc(UsbDevInfo d, boolean optical) throws Exception;

    /** Ruta en el teléfono del volumen de almacenamiento número index. */
    String volumePath(int index);

    /** Abre los ajustes de Android para dar acceso a todos los archivos. null = bien. */
    String openAllFilesAccess();

    /** Abre una dirección (por ejemplo http://127.0.0.1:...) en otra app. null = bien. */
    String openUrl(String url, String mime);

    /** Tipo de volumen: "cd", "usb" o "android" (el teléfono). */
    String volumeKind(int index);

    /** Reproduce el disco de la unidad con un reproductor externo (PC). null = bien. */
    String playDisc(int index, boolean audio);

    /** Abre los ajustes de almacenamiento de Android (desde ahí se puede expulsar). null = bien. */
    String openStorageSettings();
}
