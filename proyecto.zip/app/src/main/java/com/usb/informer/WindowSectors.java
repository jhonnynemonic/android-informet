package com.usb.informer;
/**
 * Sectores de una imagen ISO guardada en un archivo, leídos por ventanas (acceso aleatorio con caché).
 * Hay dos ventanas: una para lecturas de un solo sector (fichas de archivo) y otra para lecturas largas
 * (carpetas y datos), para que no se pisen al recorrer el árbol.
 */
public abstract class WindowSectors implements Sectors {
    protected long size;
    private byte[][] win = new byte[3][];
    private long[] winOff = new long[3];
    private int winSize;

    protected WindowSectors(long size, int winSize) {
        this.size = size;
        this.winSize = winSize;
    }

    /** Devuelve hasta len bytes del archivo desde off (menos si llega al final). */
    protected abstract byte[] fetch(long off, int len) throws Exception;

    public int sectorSize() { return 2048; }

    public long length() { return size; }

    public byte[] read(int lba, int count) throws Exception {
        return readSlot((long) lba * 2048, count * 2048, count == 1 ? 0 : 1);
    }

    /** Lee len bytes desde off (cualquier posición) usando la ventana slot (0, 1 o 2). Lo que pasa del final sale a ceros. */
    public synchronized byte[] readSlot(long off, int len, int slot) throws Exception {
        byte[] out = new byte[len];
        int got = 0;
        while (got < len) {
            long o = off + got;
            byte[] w = win[slot];
            if (w == null || o < winOff[slot] || o >= winOff[slot] + w.length) {
                long ws = o - (o % 2048);
                long wl = Math.min((long) Math.max(winSize, len - got), size - ws);
                if (wl <= 0) break;
                w = fetch(ws, (int) wl);
                win[slot] = w;
                winOff[slot] = ws;
                if (w.length == 0) break;
            }
            int in = (int) (o - winOff[slot]);
            int n = Math.min(len - got, w.length - in);
            if (n <= 0) break;
            System.arraycopy(w, in, out, got, n);
            got += n;
        }
        return out;
    }
}
