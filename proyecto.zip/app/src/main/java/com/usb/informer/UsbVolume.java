package com.usb.informer;
import java.util.Vector;

/** Detecta particiones (sin partición, MBR o GPT) y monta el sistema de archivos de un USB. */
public class UsbVolume {

    public static FileSource mount(OpticalDisc d) throws Exception {
        Vector fs = new Vector();
        BlockFs whole = tryMount(d, 0);
        if (whole != null) return whole;
        byte[] s0 = d.read(0, 1);
        Vector parts = new Vector();
        if ((s0[510] & 0xFF) == 0x55 && (s0[511] & 0xFF) == 0xAA) {
            for (int i = 0; i < 4; i++) {
                int o = 446 + 16 * i;
                int type = s0[o + 4] & 0xFF;
                long lba = (s0[o + 8] & 0xFFL) | ((s0[o + 9] & 0xFFL) << 8) | ((s0[o + 10] & 0xFFL) << 16) | ((s0[o + 11] & 0xFFL) << 24);
                if (type == 0 || lba == 0) continue;
                if (type == 0xEE) gpt(d, parts);
                else if (type != 0x05 && type != 0x0F && type != 0x85) parts.addElement(new Long(lba));
            }
        }
        for (int i = 0; i < parts.size(); i++) {
            BlockFs f = tryMount(d, ((Long) parts.elementAt(i)).longValue());
            if (f != null) fs.addElement(f);
        }
        if (fs.size() == 0) {
            throw new Exception("No reconozco el sistema de archivos del USB. Solo se admiten FAT12/16/32, exFAT, NTFS y ext2/3/4 "
                    + "(de solo lectura).");
        }
        if (fs.size() == 1) return (BlockFs) fs.elementAt(0);
        return new Multi(fs);
    }

    private static void gpt(OpticalDisc d, Vector parts) {
        try {
            byte[] h = d.read(1, 1);
            if (!(h[0] == 'E' && h[1] == 'F' && h[2] == 'I' && h[3] == ' ' && h[4] == 'P')) return;
            long entLba = le(h, 72, 8);
            int n = (int) Math.min(le(h, 80, 4), 128);
            int sz = (int) le(h, 84, 4);
            if (sz < 128) return;
            int bytes = n * sz;
            int blocks = (bytes + d.blockSize - 1) / d.blockSize;
            byte[] e = d.read((int) entLba, Math.min(blocks, 64));
            for (int i = 0; i < n && (i + 1) * sz <= e.length; i++) {
                int o = i * sz;
                boolean zero = true;
                for (int k = 0; k < 16; k++) if (e[o + k] != 0) zero = false;
                if (zero) continue;
                parts.addElement(new Long(le(e, o + 32, 8)));
            }
        } catch (Throwable t) {
            // sin GPT legible
        }
    }

    private static long le(byte[] b, int o, int n) {
        long v = 0;
        for (int i = n - 1; i >= 0; i--) v = (v << 8) | (b[o + i] & 0xFFL);
        return v;
    }

    public static BlockFs tryMount(OpticalDisc d, long lba) {
        try {
            if (d.blockSize < 512) return null;
            byte[] b = d.read((int) lba, 1);
            try {
                byte[] sb = d.read((int) lba + 1024 / d.blockSize, 1);
                int o = 1024 % d.blockSize;
                if ((sb[o + 0x38] & 0xFF) == 0x53 && (sb[o + 0x39] & 0xFF) == 0xEF) return new ExtFs(d, lba);
            } catch (Throwable t) {
                // no es ext
            }
            if ((b[510] & 0xFF) != 0x55 || (b[511] & 0xFF) != 0xAA) return null;
            if (b[3] == 'N' && b[4] == 'T' && b[5] == 'F' && b[6] == 'S') return new NtfsFs(d, lba, b);
            if (b[3] == 'E' && b[4] == 'X' && b[5] == 'F' && b[6] == 'A' && b[7] == 'T') return new ExFatFs(d, lba, b);
            int bps = (b[11] & 0xFF) | ((b[12] & 0xFF) << 8);
            int spc = b[13] & 0xFF;
            if (bps < 512 || bps > 4096 || (bps & (bps - 1)) != 0 || spc == 0 || (spc & (spc - 1)) != 0) return null;
            return new FatFs(d, lba, b);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Varias particiones: cada una aparece como una carpeta en la raíz. */
    private static class Multi implements FileSource {
        private Vector fs;

        Multi(Vector fs) {
            this.fs = fs;
        }

        public String label() { return "USB"; }

        public Vector listRoot() {
            Vector out = new Vector();
            for (int i = 0; i < fs.size(); i++) {
                BlockFs f = (BlockFs) fs.elementAt(i);
                FileItem it = new FileItem();
                it.name = "Particion " + (i + 1) + " " + f.label() + " (" + f.typeName() + ")";
                it.dir = true;
                it.ref = f;
                it.owner = this;
                out.addElement(it);
            }
            return out;
        }

        public Vector list(FileItem dir) throws Exception {
            FileSource owner;
            Vector v;
            if (dir.ref instanceof BlockFs) {
                owner = (BlockFs) dir.ref;
                v = owner.listRoot();
            } else {
                owner = dir.owner;
                v = owner.list(dir);
            }
            for (int i = 0; i < v.size(); i++) ((FileItem) v.elementAt(i)).owner = owner;
            return v;
        }

        public String preview(FileItem f, int max) throws Exception {
            return f.owner.preview(f, max);
        }

        public void copy(FileItem f, java.io.OutputStream out, Progress p) throws Exception {
            f.owner.copy(f, out, p);
        }
    }
}
