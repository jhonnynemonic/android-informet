package com.usb.informer;
import java.io.OutputStream;

/** Imagen formada por todo el contenido de un CD/DVD (clonar el disco). */
public class DiscImage implements ImageSource {
    private OpticalDisc d;
    private String label;

    public DiscImage(OpticalDisc d, String label) {
        this.d = d;
        this.label = label;
    }

    public String name() { return "Disco " + label; }

    public long size() { return (long) d.blocks * d.blockSize; }

    public void pump(OutputStream out, Progress p) throws Exception {
        int lba = 0;
        while (lba < d.blocks) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            int n = Math.min(32, d.blocks - lba);
            byte[] b = d.read(lba, n);
            out.write(b);
            if (p != null) p.add(b.length);
            lba += n;
        }
    }
}
