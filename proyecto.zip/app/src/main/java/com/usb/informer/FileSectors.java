package com.usb.informer;
import java.io.File;
import java.io.RandomAccessFile;

/** ISO guardada en un archivo normal del teléfono. */
public class FileSectors extends WindowSectors {
    private File file;

    public FileSectors(File file) {
        super(file.length(), 1024 * 1024);
        this.file = file;
    }

    protected byte[] fetch(long off, int len) throws Exception {
        RandomAccessFile r = new RandomAccessFile(file, "r");
        try {
            r.seek(off);
            byte[] b = new byte[len];
            int got = 0;
            while (got < len) {
                int n = r.read(b, got, len - got);
                if (n <= 0) break;
                got += n;
            }
            if (got == len) return b;
            byte[] c = new byte[got];
            System.arraycopy(b, 0, c, 0, got);
            return c;
        } finally {
            r.close();
        }
    }
}
