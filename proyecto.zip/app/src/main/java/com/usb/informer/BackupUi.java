package com.usb.informer;

import java.io.File;
import java.security.MessageDigest;
import java.util.Calendar;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.StringItem;
import javax.microedition.lcdui.TextField;

/**
 * Crea una imagen .img del USB conectado (copia sector a sector, como dd if=/dev/sdX).
 * Solo LEE el USB; el archivo se guarda en Descargas/USB-Informer.
 */
public class BackupUi implements CommandListener {
    private Display display;
    private UsbExtras x;
    private Displayable ret;
    private UsbDevInfo dev;

    private Command backCmd = new Command("Atrás", Command.BACK, 1);
    private Command okCmd = new Command("Aceptar", Command.OK, 1);
    private Command startCmd = new Command("Crear imagen", Command.OK, 1);

    private Form busy, info, working, result, note;
    private TextField nameField;
    private StringItem status;
    private Displayable noteNext;
    private OpticalDisc disc;
    private volatile boolean cancel;
    private volatile boolean running;

    public BackupUi(Display d) {
        display = d;
    }

    public void setBackend(UsbExtras e) {
        x = e;
    }

    private static String msg(Throwable t) {
        String m = t.getMessage();
        return m != null && m.length() > 0 ? m : t.toString();
    }

    private static String size(long n) {
        return Phone.sizeText(n);
    }

    private void showNote(String title, String text, Displayable next) {
        note = new Form(title);
        note.append(new StringItem(null, text));
        note.addCommand(okCmd);
        note.setCommandListener(this);
        noteNext = next;
        display.setCurrent(note);
    }

    private void closeDisc() {
        if (disc != null) {
            try { disc.close(); } catch (Throwable t) { }
        }
        disc = null;
    }

    private static String two(int v) {
        return v < 10 ? "0" + v : "" + v;
    }

    private static String defaultName() {
        Calendar c = Calendar.getInstance();
        return "usb-" + c.get(Calendar.YEAR) + two(c.get(Calendar.MONTH) + 1) + two(c.get(Calendar.DAY_OF_MONTH))
                + "-" + two(c.get(Calendar.HOUR_OF_DAY)) + two(c.get(Calendar.MINUTE)) + ".img";
    }

    // ---------------------------------------------------------------- 1. abrir y avisar

    public void start(UsbDevInfo d, Displayable back) {
        if (x == null) return;
        if (running) {
            showNote("Crear imagen", "Ya hay una copia en curso.", back);
            return;
        }
        ret = back;
        dev = d;
        closeDisc();
        if (d.needsPermission) {
            showNote("Crear imagen", "Primero concede el permiso USB a este dispositivo (menú principal: Pedir permiso USB).", back);
            return;
        }
        busy = new Form("Crear imagen");
        busy.append("Abriendo el USB y leyendo su tamaño...");
        busy.addCommand(backCmd);
        busy.setCommandListener(this);
        final Form mine = busy;
        display.setCurrent(busy);
        new Thread(new Runnable() {
            public void run() {
                try {
                    OpticalDisc dd = x.openDisc(dev, false);
                    if (display.getCurrent() != mine) {
                        dd.close();
                        return;
                    }
                    disc = dd;
                    showInfo();
                } catch (Throwable t) {
                    closeDisc();
                    showNote("Crear imagen", "No puedo abrir el USB: " + msg(t), ret);
                }
            }
        }).start();
    }

    private static long freeSpace() {
        try {
            File f = new File("/storage/emulated/0/Download");
            if (!f.exists()) f = new File("/storage/emulated/0");
            long u = f.getUsableSpace();
            return u > 0 ? u : -1;
        } catch (Throwable t) {
            return -1;
        }
    }

    private long capacity() {
        return (disc.blocks & 0xFFFFFFFFL) * disc.blockSize;
    }

    private void showInfo() {
        long cap = capacity();
        long free = freeSpace();
        info = new Form("Crear imagen .img");
        StringBuffer sb = new StringBuffer();
        sb.append("USB: ").append(dev.label());
        if (disc.vendor.length() + disc.product.length() > 0) sb.append("\n").append((disc.vendor + " " + disc.product).trim());
        sb.append("\nTamaño: ").append(size(cap)).append("  (").append(disc.blocks & 0xFFFFFFFFL).append(" sectores de ").append(disc.blockSize).append(" bytes)");
        if (free >= 0) sb.append("\nEspacio libre en el teléfono: ").append(size(free));
        sb.append("\n\nSe copia el USB entero, con sus particiones, y se guarda en Descargas/USB-Informer. El USB no se modifica.");
        if (free >= 0 && free < cap + 64L * 1024 * 1024) {
            sb.append("\n\nATENCIÓN: no hay espacio libre suficiente para la imagen completa. Libera espacio antes de empezar.");
        }
        info.append(new StringItem(null, sb.toString()));
        nameField = new TextField("Nombre del archivo", defaultName(), 100, TextField.ANY);
        info.append(nameField);
        info.addCommand(startCmd);
        info.addCommand(backCmd);
        info.setCommandListener(this);
        display.setCurrent(info);
    }

    // ---------------------------------------------------------------- 2. copiar

    private long done, total, last, startMs;

    private void startCopy() {
        String name = Phone.safe(nameField.getString().trim());
        if (!name.toLowerCase().endsWith(".img")) name += ".img";
        final String fname = name;
        cancel = false;
        running = true;
        done = 0;
        total = capacity();
        startMs = System.currentTimeMillis();
        last = 0;
        working = new Form("Creando imagen");
        status = new StringItem(null, "Empezando...");
        working.append(status);
        working.addCommand(backCmd);
        working.setCommandListener(this);
        display.setCurrent(working);
        try { display.flashBacklight(8000); } catch (Throwable t) { }
        new Thread(new Runnable() {
            public void run() {
                Phone.Out out = null;
                boolean ok = false;
                String m;
                try {
                    out = Phone.create("", fname);
                    MessageDigest md = MessageDigest.getInstance("SHA-256");
                    int bs = disc.blockSize;
                    int span = Math.max(1, 65536 / bs);
                    long blocks = disc.blocks & 0xFFFFFFFFL;
                    long lba = 0;
                    while (lba < blocks) {
                        if (cancel) throw new Exception("Cancelado");
                        int n = (int) Math.min((long) span, blocks - lba);
                        byte[] b = disc.read((int) lba, n);
                        out.os.write(b, 0, b.length);
                        md.update(b, 0, b.length);
                        lba += n;
                        done += b.length;
                        progress();
                    }
                    out.os.close();
                    ok = true;
                    m = "Imagen creada: " + size(done) + "\n\nGuardada en: " + out.where + "\n(archivo " + fname + ")\n\nSHA-256:\n" + hex(md.digest())
                            + "\n\nPara grabarla de nuevo usa \"Grabar imagen ISO/IMG en este USB\".";
                } catch (Throwable t) {
                    if (out != null) out.abort();
                    m = cancel ? "Copia CANCELADA. El archivo incompleto se ha borrado."
                            : "ERROR: " + msg(t) + "\n\nEl archivo incompleto se ha borrado.";
                }
                running = false;
                closeDisc();
                result = new Form(ok ? "Imagen creada" : "Copia fallida");
                result.append(new StringItem(null, m));
                result.addCommand(okCmd);
                result.setCommandListener(BackupUi.this);
                display.setCurrent(result);
            }
        }).start();
    }

    private void progress() {
        long now = System.currentTimeMillis();
        if (now - last > 500) {
            last = now;
            long secs = (now - startMs) / 1000 + 1;
            long pct = total > 0 ? done * 100 / total : 0;
            status.setText("Leyendo el USB y guardando...\n" + pct + " %  (" + size(done) + " de " + size(total) + ")\n"
                    + size(done / secs) + "/s\n\n(Atrás = cancelar)");
        }
    }

    private static String hex(byte[] b) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < b.length; i++) {
            int v = b[i] & 0xFF;
            sb.append("0123456789abcdef".charAt(v >> 4)).append("0123456789abcdef".charAt(v & 15));
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------- eventos

    public void commandAction(Command c, Displayable d) {
        if (d == note) {
            display.setCurrent(noteNext != null ? noteNext : ret);
        } else if (d == busy) {
            closeDisc();
            display.setCurrent(ret);
        } else if (d == info) {
            if (c == startCmd) {
                startCopy();
            } else {
                closeDisc();
                display.setCurrent(ret);
            }
        } else if (d == working) {
            if (running) {
                cancel = true;
                if (status != null) status.setText("Cancelando...");
            } else {
                display.setCurrent(ret);
            }
        } else if (d == result) {
            display.setCurrent(ret);
        }
    }
}
