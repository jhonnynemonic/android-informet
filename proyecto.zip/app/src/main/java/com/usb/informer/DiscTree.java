package com.usb.informer;
import java.util.Vector;

/** Árbol de archivos de una ISO (ISO9660/Joliet o UDF). */
public interface DiscTree {
    String label();

    Vector listRoot() throws Exception;

    Vector list(FileItem dir) throws Exception;

    /** Lee hasta len bytes (máx. 64 KB) desde off; devuelve los leídos o -1 al final. */
    int readAt(FileItem f, long off, byte[] dst, int len) throws Exception;

    /** Posición del archivo en el disco (para leer en orden). */
    long position(FileItem f);
}
