package com.usb.informer;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

/**
 * Servidor HTTP local (solo 127.0.0.1) que sirve los VOB de un título de DVD, leídos
 * directamente del disco, para que un reproductor externo (VLC...) los abra como un flujo.
 */
public class DvdServer implements Runnable {
    private IsoDisc iso;
    private Vector files;
    private long[] starts;
    private long total;
    private ServerSocket ss;
    private volatile boolean stopped;
    public volatile int requests;
    public volatile long sent;
    public volatile String last = "";
    public volatile String error = "";

    public String status() {
        return "Peticiones: " + requests + "\nEnviado: " + Phone.sizeText(sent) + "\nÚltima: " + last
                + (error.length() > 0 ? "\nError: " + error : "");
    }

    public DvdServer(IsoDisc iso, Vector files) {
        this.iso = iso;
        this.files = files;
        starts = new long[files.size()];
        for (int i = 0; i < files.size(); i++) {
            starts[i] = total;
            total += ((FileItem) files.elementAt(i)).size;
        }
    }

    public String start() throws Exception {
        ss = new ServerSocket(0, 5, InetAddress.getByName("127.0.0.1"));
        new Thread(this).start();
        return "http://127.0.0.1:" + ss.getLocalPort() + "/video.vob";
    }

    public void stop() {
        stopped = true;
        try {
            if (ss != null) ss.close();
        } catch (Throwable t) {
            // nada
        }
    }

    public void run() {
        while (!stopped) {
            try {
                final Socket s = ss.accept();
                new Thread(new Runnable() {
                    public void run() {
                        serve(s);
                    }
                }).start();
            } catch (Throwable t) {
                break;
            }
        }
    }

    private int indexOf(long pos) {
        int idx = 0;
        for (int i = 0; i < starts.length; i++) {
            if (pos >= starts[i]) idx = i;
        }
        return idx;
    }

    private void serve(Socket s) {
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), "ISO-8859-1"));
            String line = r.readLine();
            if (line == null) return;
            requests++;
            last = line;
            boolean head = line.startsWith("HEAD");
            long from = 0, to = total - 1;
            boolean ranged = false;
            String h;
            while ((h = r.readLine()) != null && h.length() > 0) {
                String l = h.toLowerCase();
                int e = l.indexOf("bytes=");
                if (l.startsWith("range:") && e >= 0) {
                    String v = l.substring(e + 6).trim();
                    int dash = v.indexOf('-');
                    String a = v.substring(0, dash).trim();
                    String b = v.substring(dash + 1).trim();
                    ranged = true;
                    if (a.length() > 0) {
                        from = Long.parseLong(a);
                        if (b.length() > 0) to = Math.min(Long.parseLong(b), total - 1);
                    } else if (b.length() > 0) {
                        from = Math.max(0, total - Long.parseLong(b));
                    }
                }
            }
            OutputStream out = s.getOutputStream();
            if (from >= total || to < from) {
                out.write(("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */" + total
                        + "\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").getBytes("ISO-8859-1"));
                out.flush();
                return;
            }
            String hdr = (ranged ? "HTTP/1.1 206 Partial Content\r\n" : "HTTP/1.1 200 OK\r\n")
                    + "Content-Type: video/mpeg\r\nAccept-Ranges: bytes\r\n"
                    + (ranged ? "Content-Range: bytes " + from + "-" + to + "/" + total + "\r\n" : "")
                    + "Content-Length: " + (to - from + 1) + "\r\nConnection: close\r\n\r\n";
            out.write(hdr.getBytes("ISO-8859-1"));
            if (head) {
                out.flush();
                return;
            }
            final java.util.Vector q = new java.util.Vector();
            final long fromF = from, toF = to;
            final boolean[] fin = { false };
            final Throwable[] fail = { null };
            Thread prod = new Thread(new Runnable() {
                public void run() {
                    try {
                        long pos = fromF;
                        while (pos <= toF && !stopped && !fin[0]) {
                            int idx = indexOf(pos);
                            FileItem f = (FileItem) files.elementAt(idx);
                            long off = pos - starts[idx];
                            byte[] buf = new byte[65536];
                            int want = (int) Math.min(buf.length, Math.min(toF - pos + 1, f.size - off));
                            int n = iso.readAt(f, off, buf, want);
                            if (n <= 0) break;
                            byte[] chunk = new byte[n];
                            System.arraycopy(buf, 0, chunk, 0, n);
                            synchronized (q) {
                                while (q.size() >= 8 && !fin[0] && !stopped) q.wait(200);
                                q.addElement(chunk);
                                q.notifyAll();
                            }
                            pos += n;
                        }
                    } catch (Throwable t) {
                        fail[0] = t;
                        error = t.getMessage() != null ? t.getMessage() : t.toString();
                    }
                    synchronized (q) {
                        fin[0] = true;
                        q.notifyAll();
                    }
                }
            });
            prod.start();
            try {
                while (!stopped) {
                    byte[] chunk;
                    synchronized (q) {
                        while (q.size() == 0 && !fin[0]) q.wait(200);
                        if (q.size() == 0) break;
                        chunk = (byte[]) q.elementAt(0);
                        q.removeElementAt(0);
                        q.notifyAll();
                    }
                    out.write(chunk);
                    sent += chunk.length;
                }
            } finally {
                synchronized (q) {
                    fin[0] = true;
                    q.notifyAll();
                }
            }
            out.flush();
        } catch (Throwable t) {
            if (error.length() == 0) error = "conexión cerrada por el reproductor";
        } finally {
            try {
                s.close();
            } catch (Throwable t) {
                // nada
            }
        }
    }
}
