package com.usb.informer;

import java.util.Hashtable;
import java.util.Vector;

/**
 * Añade archivos y carpetas a un USB ext2 / ext3 que YA tiene datos, sin borrar nada.
 * Solo ext2 y ext3 "limpios" (sin journal pendiente, sin extents, sin flex_bg ni sumas de comprobación de ext4).
 * Orden de escritura: datos, bloques indirectos, inodo, mapas de bits y contadores y, por último, la entrada de carpeta.
 */
public class ExtAdd extends FsAdd {
    private final OpticalDisc d;
    private final int bs;
    private long base;
    private int fsBs, bpg, ipg, inodeSize, firstIno, ngroups, per, rev;
    private long firstDataBlock, blocksCount;
    private boolean filetype, largeFile;
    private byte[] gd;
    private byte[][] bbm, ibm;
    private boolean[] bbDirty, ibDirty, gdDirty;
    private int[] bHint, iHint;
    private long totalFreeB, totalFreeI;
    private String type = "ext2";
    private byte[] cacheBlk;
    private int cacheNo = -1;
    private long maxBlocks;

    private static final int MAXB = 4 * 1024 * 1024;   // máximo de bloques por archivo (limita la memoria)

    private static class Dir {
        int ino, group;
        byte[] inode;
        Vector blocks = new Vector();   // byte[] por bloque
        Vector phys = new Vector();     // Integer: bloque físico de cada uno
        Hashtable names = new Hashtable();
        boolean indexed;
    }

    private ExtAdd(OpticalDisc d) {
        this.d = d;
        this.bs = d.blockSize;
    }

    private static int le16(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8); }

    private static long le32(byte[] b, int o) {
        return (b[o] & 0xFFL) | ((b[o + 1] & 0xFFL) << 8) | ((b[o + 2] & 0xFFL) << 16) | ((b[o + 3] & 0xFFL) << 24);
    }

    private static void put16(byte[] b, int o, int v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
    }

    private static void put32(byte[] b, int o, long v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
        b[o + 2] = (byte) (v >> 16);
        b[o + 3] = (byte) (v >> 24);
    }

    public String typeName() { return type; }

    public long freeBytes() { return totalFreeB * fsBs; }

    public long clusterBytes() { return fsBs; }

    protected long maxFile() {
        long m = Math.min(maxBlocks, (long) MAXB) * fsBs;
        return rev >= 1 ? m : Math.min(m, 0x7FFFFFFFL);
    }

    protected long fileClusters(long size) {
        long n = (size + fsBs - 1) / fsBs;
        return n + countMeta(n);
    }

    private long countMeta(long n) {
        long left = n - 12;
        if (left <= 0) return 0;
        long m = 1;
        left -= Math.min(left, per);
        if (left <= 0) return m;
        long dcap = (long) per * per;
        long dd = Math.min(left, dcap);
        m += 1 + (dd + per - 1) / per;
        left -= dd;
        if (left <= 0) return m;
        m += 1 + (left + dcap - 1) / dcap + (left + per - 1) / per;
        return m;
    }

    public long[] plan(Vector items, DiscTree t, Progress p) throws Exception {
        long[] r = super.plan(items, t, p);
        if (r[0] + r[1] > totalFreeI) {
            throw new Exception("Al USB " + type + " le faltan inodos libres: hacen falta hasta " + (r[0] + r[1])
                    + " y quedan " + totalFreeI + " (cada archivo y cada carpeta usa uno).");
        }
        return r;
    }

    // ------------------------------------------------------------------ E/S

    private byte[] rd(long off, int len) throws Exception {
        long abs = base + off;
        byte[] out = new byte[len];
        int got = 0;
        while (got < len) {
            long a = abs + got;
            long blk = a / bs;
            int skip = (int) (a % bs);
            int n = Math.min(len - got, 128 * bs - skip);
            int count = (skip + n + bs - 1) / bs;
            byte[] b = d.read((int) blk, count);
            System.arraycopy(b, skip, out, got, n);
            got += n;
        }
        return out;
    }

    private void wr(long off, byte[] src, int so, int len) throws Exception {
        long abs = base + off;
        int done = 0;
        while (done < len) {
            long a = abs + done;
            long blk = a / bs;
            int skip = (int) (a % bs);
            int n = Math.min(len - done, 65536 - skip);
            int blocks = (skip + n + bs - 1) / bs;
            int total = blocks * bs;
            byte[] buf;
            if (skip == 0 && n == total) buf = new byte[total];
            else buf = d.read((int) blk, blocks);
            System.arraycopy(src, so + done, buf, skip, n);
            d.write((int) blk, buf, total);
            done += n;
        }
    }

    private byte[] rdBlk(int blk) throws Exception {
        if (blk == cacheNo) return cacheBlk;
        byte[] b = rd((long) blk * fsBs, fsBs);
        cacheBlk = b;
        cacheNo = blk;
        return b;
    }

    private void wrBlk(int blk, byte[] data) throws Exception {
        wr((long) blk * fsBs, data, 0, fsBs);
        if (blk == cacheNo) cacheNo = -1;
    }

    // ------------------------------------------------------------------ abrir

    public static ExtAdd tryOpen(OpticalDisc d, long lba) throws Exception {
        if (d.blockSize < 512) return null;
        ExtAdd f = new ExtAdd(d);
        f.base = lba * f.bs;
        byte[] sb = f.rd(1024, 1024);
        if (le16(sb, 0x38) != 0xEF53) return null;
        f.init(sb);
        return f;
    }

    private void init(byte[] sb) throws Exception {
        int logBs = (int) le32(sb, 0x18);
        if (logBs > 6) throw new Refuse("El USB ext tiene un tamaño de bloque no válido.");
        fsBs = 1024 << logBs;
        per = fsBs / 4;
        bpg = (int) le32(sb, 0x20);
        ipg = (int) le32(sb, 0x28);
        firstDataBlock = le32(sb, 0x14);
        blocksCount = le32(sb, 0x04);
        rev = (int) le32(sb, 0x4C);
        inodeSize = rev >= 1 ? le16(sb, 0x58) : 128;
        firstIno = rev >= 1 ? (int) le32(sb, 0x54) : 11;
        long compat = rev >= 1 ? le32(sb, 0x5C) : 0;
        long incompat = rev >= 1 ? le32(sb, 0x60) : 0;
        long roCompat = rev >= 1 ? le32(sb, 0x64) : 0;
        if (bpg <= 0 || ipg <= 0 || inodeSize < 128 || inodeSize > fsBs || bpg > fsBs * 8 || ipg > fsBs * 8 || firstIno < 1) {
            throw new Refuse("El superbloque del USB ext parece dañado.");
        }
        if ((incompat & 0x4) != 0) {
            throw new Refuse("El USB ext tiene el journal sin recuperar (no se desmontó bien). Conéctalo a un PC y ejecuta e2fsck antes de copiar.");
        }
        if ((incompat & ~2L) != 0 || (roCompat & ~7L) != 0 || (compat & ~0x3DL) != 0 || (compat & 0x2) != 0) {
            throw new Refuse("Este USB usa funciones de ext4 (extents, flex_bg, sumas de comprobación u otras). "
                    + "De momento solo se puede añadir a ext2 y ext3.");
        }
        int state = le16(sb, 0x3A);
        if ((state & 1) == 0 || (state & 2) != 0) {
            throw new Refuse("El USB ext no se desmontó correctamente o tiene errores. Conéctalo a un PC y ejecuta e2fsck -f antes de copiar.");
        }
        filetype = (incompat & 2) != 0;
        largeFile = (roCompat & 2) != 0;
        type = (compat & 4) != 0 ? "ext3" : "ext2";
        StringBuffer l = new StringBuffer();
        for (int i = 0; i < 16 && sb[0x78 + i] != 0; i++) l.append((char) (sb[0x78 + i] & 0xFF));
        label = l.toString();
        ngroups = (int) ((blocksCount - firstDataBlock + bpg - 1) / bpg);
        if (ngroups < 1 || (long) ngroups * 32 > 64L * 1024 * 1024) throw new Refuse("El USB ext tiene demasiados grupos de bloques.");
        long perBlk = per;
        maxBlocks = 12 + perBlk + perBlk * perBlk + perBlk * perBlk * perBlk;
        gd = rd((firstDataBlock + 1) * fsBs, ngroups * 32);
        bbm = new byte[ngroups][];
        ibm = new byte[ngroups][];
        bbDirty = new boolean[ngroups];
        ibDirty = new boolean[ngroups];
        gdDirty = new boolean[ngroups];
        bHint = new int[ngroups];
        iHint = new int[ngroups];
        for (int g = 0; g < ngroups; g++) {
            totalFreeB += le16(gd, g * 32 + 12);
            totalFreeI += le16(gd, g * 32 + 14);
            long bb = le32(gd, g * 32), ib = le32(gd, g * 32 + 4), it = le32(gd, g * 32 + 8);
            if (bb >= blocksCount || ib >= blocksCount || it >= blocksCount) throw new Refuse("La tabla de grupos del USB ext está dañada.");
        }
    }

    // ------------------------------------------------------------------ bloques e inodos libres

    private int groupBlocks(int g) {
        return g < ngroups - 1 ? bpg : (int) (blocksCount - firstDataBlock - (long) g * bpg);
    }

    private byte[] loadBB(int g) throws Exception {
        if (bbm[g] == null) bbm[g] = rd(le32(gd, g * 32) * fsBs, fsBs);
        return bbm[g];
    }

    private byte[] loadIB(int g) throws Exception {
        if (ibm[g] == null) ibm[g] = rd(le32(gd, g * 32 + 4) * fsBs, fsBs);
        return ibm[g];
    }

    private void addFreeB(int g, int delta) {
        put16(gd, g * 32 + 12, le16(gd, g * 32 + 12) + delta);
        totalFreeB += delta;
        bbDirty[g] = true;
        gdDirty[g] = true;
    }

    /** n bloques libres, empezando a buscar en el grupo goal. Si no hay bastantes, no deja nada reservado. */
    private int[] allocBlocks(int n, int goal) throws Exception {
        int[] out = new int[n];
        if (n == 0) return out;
        int k = 0;
        for (int gi = 0; gi < ngroups && k < n; gi++) {
            int g = (goal + gi) % ngroups;
            if (le16(gd, g * 32 + 12) == 0) continue;
            byte[] bm = loadBB(g);
            int lim = groupBlocks(g);
            int bit = bHint[g];
            int took = 0;
            while (k < n && bit < lim) {
                if ((bit & 7) == 0 && bm[bit >> 3] == (byte) 0xFF) {
                    bit += 8;
                    continue;
                }
                if ((bm[bit >> 3] & (1 << (bit & 7))) == 0) {
                    bm[bit >> 3] |= (byte) (1 << (bit & 7));
                    out[k++] = (int) (firstDataBlock + (long) g * bpg + bit);
                    took++;
                }
                bit++;
            }
            bHint[g] = Math.min(bit, lim);
            if (took > 0) addFreeB(g, -took);
        }
        if (k < n) {
            freeBlocks(out, 0, k);
            throw new Exception("No hay espacio libre suficiente en el USB");
        }
        return out;
    }

    private void freeBlocks(int[] a, int from, int to) {
        for (int i = from; i < to; i++) {
            long rel = a[i] - firstDataBlock;
            int g = (int) (rel / bpg);
            int bit = (int) (rel % bpg);
            try {
                byte[] bm = loadBB(g);
                bm[bit >> 3] &= (byte) ~(1 << (bit & 7));
                if (bit < bHint[g]) bHint[g] = bit;
                addFreeB(g, 1);
            } catch (Exception e) {
                // no se pudo leer el mapa: queda reservado (e2fsck lo recupera)
            }
        }
    }

    private int allocInode(int goal, boolean isDir) throws Exception {
        for (int gi = 0; gi < ngroups; gi++) {
            int g = (goal + gi) % ngroups;
            if (le16(gd, g * 32 + 14) == 0) continue;
            byte[] bm = loadIB(g);
            for (int bit = iHint[g]; bit < ipg; bit++) {
                if ((bit & 7) == 0 && bm[bit >> 3] == (byte) 0xFF) {
                    bit += 7;
                    continue;
                }
                if ((bm[bit >> 3] & (1 << (bit & 7))) != 0) continue;
                long ino = (long) g * ipg + bit + 1;
                if (ino < firstIno) continue;
                bm[bit >> 3] |= (byte) (1 << (bit & 7));
                iHint[g] = bit + 1;
                put16(gd, g * 32 + 14, le16(gd, g * 32 + 14) - 1);
                if (isDir) put16(gd, g * 32 + 16, le16(gd, g * 32 + 16) + 1);
                totalFreeI--;
                ibDirty[g] = true;
                gdDirty[g] = true;
                return (int) ino;
            }
        }
        throw new Exception("No quedan inodos libres en el USB");
    }

    private void freeInode(int ino, boolean isDir) {
        try {
            int g = (ino - 1) / ipg;
            int bit = (ino - 1) % ipg;
            byte[] bm = loadIB(g);
            bm[bit >> 3] &= (byte) ~(1 << (bit & 7));
            if (bit < iHint[g]) iHint[g] = bit;
            put16(gd, g * 32 + 14, le16(gd, g * 32 + 14) + 1);
            if (isDir) put16(gd, g * 32 + 16, Math.max(0, le16(gd, g * 32 + 16) - 1));
            totalFreeI++;
            ibDirty[g] = true;
            gdDirty[g] = true;
        } catch (Exception e) {
            // queda reservado; e2fsck lo recupera
        }
    }

    /** Escribe los mapas de bits y descriptores de grupo modificados. */
    private void flushMeta() throws Exception {
        for (int g = 0; g < ngroups; g++) {
            if (bbDirty[g]) {
                wr(le32(gd, g * 32) * fsBs, bbm[g], 0, fsBs);
                bbDirty[g] = false;
            }
            if (ibDirty[g]) {
                wr(le32(gd, g * 32 + 4) * fsBs, ibm[g], 0, fsBs);
                ibDirty[g] = false;
            }
        }
        for (int g = 0; g < ngroups; g++) {
            if (gdDirty[g]) {
                wr((firstDataBlock + 1) * fsBs + (long) g * 32, gd, g * 32, 32);
                gdDirty[g] = false;
            }
        }
    }

    private void writeSuper(boolean addLarge) throws Exception {
        byte[] sb = rd(1024, 1024);
        put32(sb, 0x0C, totalFreeB);
        put32(sb, 0x10, totalFreeI);
        put32(sb, 0x30, System.currentTimeMillis() / 1000);
        if (addLarge && rev >= 1) put32(sb, 0x64, le32(sb, 0x64) | 2);
        wr(1024, sb, 0, 1024);
    }

    // ------------------------------------------------------------------ inodos

    private long inodeOff(int ino) {
        int g = (ino - 1) / ipg;
        long idx = (ino - 1) % ipg;
        return le32(gd, g * 32 + 8) * fsBs + idx * inodeSize;
    }

    private byte[] readInode(int ino) throws Exception {
        return rd(inodeOff(ino), 128);
    }

    private static int now() { return (int) (System.currentTimeMillis() / 1000); }

    private byte[] newInode(int mode, byte[] parent, long size, int links, long blocks512) {
        byte[] b = new byte[inodeSize];
        put16(b, 0, mode);
        put16(b, 2, le16(parent, 2));
        put16(b, 0x18, le16(parent, 0x18));
        put32(b, 4, size & 0xFFFFFFFFL);
        if (rev >= 1 && (mode & 0170000) == 0100000) put32(b, 0x6C, size >>> 32);
        int t = now();
        put32(b, 8, t);
        put32(b, 12, t);
        put32(b, 16, t);
        put16(b, 0x1A, links);
        put32(b, 0x1C, blocks512);
        put32(b, 0x64, (long) (Math.random() * 2147483647.0));
        return b;
    }

    // ------------------------------------------------------------------ mapa de bloques de una carpeta

    private int bmap(byte[] ino, long lbn) throws Exception {
        if (lbn < 12) return (int) le32(ino, 0x28 + 4 * (int) lbn);
        lbn -= 12;
        if (lbn < per) {
            int ind = (int) le32(ino, 0x28 + 48);
            return ind == 0 ? 0 : (int) le32(rdBlk(ind), (int) lbn * 4);
        }
        lbn -= per;
        if (lbn < (long) per * per) {
            int dind = (int) le32(ino, 0x28 + 52);
            if (dind == 0) return 0;
            int ind = (int) le32(rdBlk(dind), (int) (lbn / per) * 4);
            return ind == 0 ? 0 : (int) le32(rdBlk(ind), (int) (lbn % per) * 4);
        }
        throw new Exception("carpeta demasiado grande");
    }

    /** Pone el bloque phys como bloque lógico lbn de la carpeta; devuelve cuántos bloques de índice ha tenido que crear. */
    private int setBlock(Dir dir, long lbn, int phys) throws Exception {
        byte[] ino = dir.inode;
        int meta = 0;
        if (lbn < 12) {
            put32(ino, 0x28 + 4 * (int) lbn, phys);
            return 0;
        }
        lbn -= 12;
        if (lbn < per) {
            int ind = (int) le32(ino, 0x28 + 48);
            if (ind == 0) {
                ind = allocBlocks(1, dir.group)[0];
                wrBlk(ind, new byte[fsBs]);
                put32(ino, 0x28 + 48, ind);
                meta++;
            }
            byte[] b = (byte[]) rdBlk(ind).clone();
            put32(b, (int) lbn * 4, phys);
            wrBlk(ind, b);
            return meta;
        }
        lbn -= per;
        if (lbn < (long) per * per) {
            int dind = (int) le32(ino, 0x28 + 52);
            if (dind == 0) {
                dind = allocBlocks(1, dir.group)[0];
                wrBlk(dind, new byte[fsBs]);
                put32(ino, 0x28 + 52, dind);
                meta++;
            }
            byte[] db = (byte[]) rdBlk(dind).clone();
            int idx = (int) (lbn / per);
            int ind = (int) le32(db, idx * 4);
            if (ind == 0) {
                ind = allocBlocks(1, dir.group)[0];
                wrBlk(ind, new byte[fsBs]);
                put32(db, idx * 4, ind);
                wrBlk(dind, db);
                meta++;
            }
            byte[] b = (byte[]) rdBlk(ind).clone();
            put32(b, (int) (lbn % per) * 4, phys);
            wrBlk(ind, b);
            return meta;
        }
        throw new Exception("La carpeta ya no puede crecer más");
    }

    // ------------------------------------------------------------------ carpetas

    private static String decode(byte[] b, int off, int len) {
        try { return new String(b, off, len, "UTF-8"); } catch (Exception e) { return new String(b, off, len); }
    }

    private Dir loadDir(int ino) throws Exception {
        byte[] in = readInode(ino);
        if ((le16(in, 0) & 0170000) != 040000) throw new Exception("no es una carpeta");
        long flags = le32(in, 0x20);
        if ((flags & 0x80000L) != 0 || (flags & 0x10000000L) != 0) throw new Exception("carpeta con extents o datos en el inodo");
        long size = le32(in, 4);
        if (size % fsBs != 0 || size == 0 || size > 64L * 1024 * 1024) throw new Exception("tamaño de carpeta no válido");
        Dir dir = new Dir();
        dir.ino = ino;
        dir.group = (ino - 1) / ipg;
        dir.inode = in;
        dir.indexed = (flags & 0x1000L) != 0;
        int n = (int) (size / fsBs);
        for (int i = 0; i < n; i++) {
            int pb = bmap(in, i);
            if (pb <= 0 || pb >= blocksCount) throw new Exception("carpeta con huecos o bloques fuera de rango");
            byte[] blk = rd((long) pb * fsBs, fsBs);
            int pos = 0;
            while (pos < fsBs) {
                int rec = le16(blk, pos + 4);
                int nl = blk[pos + 6] & 0xFF;
                if (rec < 8 || (rec & 3) != 0 || pos + rec > fsBs || 8 + nl > rec) throw new Exception("entrada de carpeta dañada");
                long child = le32(blk, pos);
                if (child != 0 && nl > 0) {
                    String nm = decode(blk, pos + 8, nl);
                    if (!nm.equals(".") && !nm.equals("..")) dir.names.put(nm, new Integer((int) child));
                }
                pos += rec;
            }
            dir.blocks.addElement(blk);
            dir.phys.addElement(new Integer(pb));
        }
        return dir;
    }

    private void wrInode128(int ino, byte[] in) throws Exception {
        wr(inodeOff(ino), in, 0, 128);
    }

    private void touchDir(Dir dir) throws Exception {
        if (dir.indexed) {
            // las carpetas con índice htree se vuelven lineales (siguen siendo válidas); así no hay que mantener el índice
            put32(dir.inode, 0x20, le32(dir.inode, 0x20) & ~0x1000L);
            wrInode128(dir.ino, dir.inode);
            dir.indexed = false;
        }
    }

    private void addEntry(Dir dir, String name, int ino, int ft) throws Exception {
        touchDir(dir);
        byte[] nb = name.getBytes("UTF-8");
        int need = 8 + ((nb.length + 3) & ~3);
        for (int i = 0; i < dir.blocks.size(); i++) {
            byte[] blk = (byte[]) dir.blocks.elementAt(i);
            int pos = 0;
            while (pos < fsBs) {
                int rec = le16(blk, pos + 4);
                long inode = le32(blk, pos);
                int nl = blk[pos + 6] & 0xFF;
                int at = -1, newRec = 0;
                if (inode == 0 && rec >= need) {
                    at = pos;
                    newRec = rec;
                } else if (inode != 0) {
                    int actual = 8 + ((nl + 3) & ~3);
                    if (rec - actual >= need) {
                        put16(blk, pos + 4, actual);
                        at = pos + actual;
                        newRec = rec - actual;
                    }
                }
                if (at >= 0) {
                    put32(blk, at, ino);
                    put16(blk, at + 4, newRec);
                    blk[at + 6] = (byte) nb.length;
                    blk[at + 7] = (byte) (filetype ? ft : 0);
                    System.arraycopy(nb, 0, blk, at + 8, nb.length);
                    wrBlk(((Integer) dir.phys.elementAt(i)).intValue(), blk);
                    dir.names.put(name, new Integer(ino));
                    return;
                }
                pos += rec;
            }
        }
        // no cabe: la carpeta crece un bloque
        int[] nbk = allocBlocks(1, dir.group);
        int meta = 0;
        try {
            byte[] blk = new byte[fsBs];
            put32(blk, 0, ino);
            put16(blk, 4, fsBs);
            blk[6] = (byte) nb.length;
            blk[7] = (byte) (filetype ? ft : 0);
            System.arraycopy(nb, 0, blk, 8, nb.length);
            wrBlk(nbk[0], blk);
            int lbn = dir.blocks.size();
            meta = setBlock(dir, lbn, nbk[0]);
            long size = le32(dir.inode, 4) + fsBs;
            put32(dir.inode, 4, size);
            put32(dir.inode, 0x1C, le32(dir.inode, 0x1C) + (long) (1 + meta) * (fsBs / 512));
            put32(dir.inode, 0x10, now());
            put32(dir.inode, 0x0C, now());
            wrInode128(dir.ino, dir.inode);
            flushMeta();
            dir.blocks.addElement(blk);
            dir.phys.addElement(new Integer(nbk[0]));
            dir.names.put(name, new Integer(ino));
        } catch (Exception e) {
            freeBlocks(nbk, 0, 1);
            throw e;
        }
    }

    // ------------------------------------------------------------------ copiar

    private static String cleanName(String n) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < n.length(); i++) {
            char c = n.charAt(i);
            if (c < 32 || c == '/') c = '_';
            sb.append(c);
        }
        String r = sb.toString();
        if (r.equals(".") || r.equals("..") || r.length() == 0) return "_";
        try {
            while (r.getBytes("UTF-8").length > 255) r = r.substring(0, r.length() - 1);
        } catch (Exception e) {
            if (r.length() > 255) r = r.substring(0, 255);
        }
        return r;
    }

    public void addTree(Vector items, DiscTree t, Progress p, boolean verify) throws Exception {
        try {
            Dir root = loadDir(2);
            copyItems(items, t, root, p, verify, "");
        } finally {
            try {
                flushMeta();
                writeSuper(false);
                d.flush();
            } catch (Exception e) {
                // el error original es el importante
            }
        }
    }

    private void copyItems(Vector items, DiscTree t, Dir dir, Progress p, boolean verify, String path) throws Exception {
        for (int i = 0; i < items.size(); i++) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            FileItem it = (FileItem) items.elementAt(i);
            String nm = cleanName(it.name);
            Integer ex = (Integer) dir.names.get(nm);
            if (it.dir) {
                Dir sub;
                if (ex != null) {
                    try {
                        sub = loadDir(ex.intValue());
                    } catch (Exception e) {
                        skipped.addElement(path + it.name + " (ya existe y no es una carpeta que pueda ampliar: " + e.getMessage() + ")");
                        continue;
                    }
                } else {
                    if (le16(dir.inode, 0x1A) >= 32000) {
                        skipped.addElement(path + it.name + " (la carpeta destino ya tiene demasiadas subcarpetas)");
                        continue;
                    }
                    sub = mkdir(dir, nm);
                    dirs++;
                }
                copyItems(t.list(it), t, sub, p, verify, path + it.name + "/");
            } else {
                if (ex != null) {
                    skipped.addElement(path + it.name + " (ya existe en el USB; no se sobrescribe)");
                    continue;
                }
                copyFile(dir, nm, it, t, p, verify);
            }
        }
    }

    private Dir mkdir(Dir parent, String nm) throws Exception {
        int[] b = allocBlocks(1, parent.group);
        int ino = -1;
        try {
            ino = allocInode(parent.group, true);
            byte[] blk = new byte[fsBs];
            int ft = filetype ? 2 : 0;
            put32(blk, 0, ino);
            put16(blk, 4, 12);
            blk[6] = 1;
            blk[7] = (byte) ft;
            blk[8] = '.';
            put32(blk, 12, parent.ino);
            put16(blk, 16, fsBs - 12);
            blk[18] = 2;
            blk[19] = (byte) ft;
            blk[20] = '.';
            blk[21] = '.';
            wrBlk(b[0], blk);
            byte[] in = newInode(040755, parent.inode, fsBs, 2, fsBs / 512);
            put32(in, 0x28, b[0]);
            wr(inodeOff(ino), in, 0, inodeSize);
            flushMeta();
            addEntry(parent, nm, ino, 2);
            put16(parent.inode, 0x1A, le16(parent.inode, 0x1A) + 1);
            wrInode128(parent.ino, parent.inode);
            Dir dir = new Dir();
            dir.ino = ino;
            dir.group = (ino - 1) / ipg;
            dir.inode = new byte[128];
            System.arraycopy(in, 0, dir.inode, 0, 128);
            dir.blocks.addElement(blk);
            dir.phys.addElement(new Integer(b[0]));
            return dir;
        } catch (Exception e) {
            freeBlocks(b, 0, 1);
            if (ino > 0) freeInode(ino, true);
            try {
                flushMeta();
            } catch (Exception e2) {
                // sin más
            }
            throw e;
        }
    }

    private void copyFile(Dir dir, String nm, FileItem it, DiscTree t, Progress p, boolean verify) throws Exception {
        if (p != null) p.file(it.name);
        long n = (it.size + fsBs - 1) / fsBs;
        int meta = (int) countMeta(n);
        int[] all = allocBlocks((int) n + meta, dir.group);
        int ino = -1;
        try {
            // reparto de los bloques: datos e índices (como lo hace mke2fs: índice, luego sus datos)
            int[] data = new int[(int) n];
            int[] imap = new int[15];
            Vector metaW = new Vector();
            int[] st = { 0, 0 };   // st[0]: siguiente de all; st[1]: siguiente dato
            for (int i = 0; i < 12 && st[1] < n; i++) {
                imap[i] = all[st[0]++];
                data[st[1]++] = imap[i];
            }
            for (int lvl = 1; lvl <= 3 && st[1] < n; lvl++) imap[11 + lvl] = build(lvl, all, data, st, n, metaW);
            long blocks512 = (long) all.length * (fsBs / 512);
            if (it.size >= 0x7FFFFFFFL && !largeFile) {
                if (rev < 1) throw new Exception("Este USB ext2 es antiguo y no admite archivos de 2 GB o más");
                writeSuper(true);
                largeFile = true;
            }
            writeData(data, it, t, p);
            for (int i = 0; i < metaW.size(); i++) {
                Object[] w = (Object[]) metaW.elementAt(i);
                wrBlk(((Integer) w[0]).intValue(), (byte[]) w[1]);
            }
            if (verify) verifyData(data, it, t, p);
            ino = allocInode(dir.group, false);
            byte[] in = newInode(0100644, dir.inode, it.size, 1, blocks512);
            for (int i = 0; i < 15; i++) put32(in, 0x28 + 4 * i, imap[i]);
            wr(inodeOff(ino), in, 0, inodeSize);
            flushMeta();
            addEntry(dir, nm, ino, 1);
        } catch (Exception e) {
            freeBlocks(all, 0, all.length);
            if (ino > 0) freeInode(ino, false);
            try {
                flushMeta();
            } catch (Exception e2) {
                // sin más
            }
            throw e;
        }
        files++;
        bytes += it.size;
    }

    private int build(int level, int[] all, int[] data, int[] st, long n, Vector metaW) {
        int blk = all[st[0]++];
        byte[] c = new byte[fsBs];
        for (int k = 0; k < per && st[1] < n; k++) {
            int v;
            if (level == 1) {
                v = all[st[0]++];
                data[st[1]++] = v;
            } else {
                v = build(level - 1, all, data, st, n, metaW);
            }
            put32(c, k * 4, v);
        }
        metaW.addElement(new Object[] { new Integer(blk), c });
        return blk;
    }

    private int readFully(DiscTree t, FileItem it, long off, byte[] dst, int dstOff, int len, byte[] tmp) throws Exception {
        int got = 0;
        while (got < len) {
            int n = t.readAt(it, off + got, tmp, Math.min(len - got, tmp.length));
            if (n <= 0) throw new Exception("No pude leer " + it.name + " del teléfono (en " + (off + got) + " de " + it.size + ")");
            System.arraycopy(tmp, 0, dst, dstOff + got, n);
            got += n;
        }
        return got;
    }

    private void writeData(int[] data, FileItem it, DiscTree t, Progress p) throws Exception {
        byte[] buf = new byte[65536];
        byte[] tmp = new byte[65536];
        int perChunk = buf.length / fsBs;
        if (perChunk < 1) perChunk = 1;
        int i = 0;
        long off = 0;
        while (i < data.length) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            int run = 1;
            while (i + run < data.length && run < perChunk && data[i + run] == data[i] + run) run++;
            int want = run * fsBs;
            byte[] out = want <= buf.length ? buf : new byte[want];
            int real = (int) Math.min((long) want, it.size - off);
            if (real > 0) readFully(t, it, off, out, 0, real, tmp);
            for (int k = Math.max(real, 0); k < want; k++) out[k] = 0;
            wr((long) data[i] * fsBs, out, 0, want);
            if (p != null && real > 0) p.add(real);
            off += want;
            i += run;
        }
        if (it.size >= 8L * 1024 * 1024) d.flush();
    }

    private void verifyData(int[] data, FileItem it, DiscTree t, Progress p) throws Exception {
        byte[] exp = new byte[65536];
        byte[] tmp = new byte[65536];
        int perChunk = Math.max(1, exp.length / fsBs);
        int i = 0;
        long off = 0;
        while (i < data.length) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            int run = 1;
            while (i + run < data.length && run < perChunk && data[i + run] == data[i] + run) run++;
            int want = (int) Math.min((long) run * fsBs, it.size - off);
            if (want > 0) {
                byte[] got = rd((long) data[i] * fsBs, want);
                readFully(t, it, off, exp, 0, want, tmp);
                for (int k = 0; k < want; k++) {
                    if (got[k] != exp[k]) throw new Exception("Verificación fallida en " + it.name + " (byte " + (off + k) + ")");
                }
            }
            off += (long) run * fsBs;
            i += run;
        }
    }
}
