package com.usb.informer;
public interface UsbListener {
    void deviceAttached(UsbDevInfo d);
    void deviceDetached(UsbDevInfo d);
}
