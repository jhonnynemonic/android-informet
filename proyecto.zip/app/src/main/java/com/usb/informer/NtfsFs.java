package com.usb.informer;
import java.io.OutputStream;
import java.util.Vector;

/** NTFS de solo lectura (carpetas con índices, archivos residentes y no residentes, listas de atributos, dispersos). */
public class NtfsFs extends BlockFs {
    private static final long SPARSE = -(1L << 60);
    private int bps, spc;
    private long clusterBytes, mftLcn;
    private int recSize;
    private Vector mftRuns;       // long[] { lcn (o -1 si es disperso), longitud en clusters }
    private long mftSize;
    private int idxBlock;

    private static class Attr {
        int type;
        String name = "";
        boolean nonres;
        int flags;
        byte[] value;
        Vector runs = new Vector();
        long startVcn, real, init;
    }

    public NtfsFs(OpticalDisc disc, long startLba, byte[] b) throws Exception {
        d = disc;
        baseBytes = startLba * disc.blockSize;
        bps = le16(b, 11);
        spc = b[13] & 0xFF;
        if (bps < 512 || bps > 4096 || (bps & (bps - 1)) != 0 || spc == 0 || (spc & (spc - 1)) != 0) throw new Exception("no es NTFS");
        clusterBytes = (long) bps * spc;
        mftLcn = le64(b, 48);
        int rs = b[64];
        recSize = rs < 0 ? (1 << (-rs)) : (int) (rs * clusterBytes);
        int ib = b[68];
        idxBlock = ib < 0 ? (1 << (-ib)) : (int) (ib * clusterBytes);
        if (recSize < 256 || recSize > 65536 || idxBlock < 512 || idxBlock > 65536) throw new Exception("NTFS con parámetros raros");
        byte[] r0 = fix(readRaw(mftLcn * clusterBytes, recSize), recSize, "FILE");
        Vector a0 = attrs(r0, 0, false);
        for (int i = 0; i < a0.size(); i++) {
            Attr a = (Attr) a0.elementAt(i);
            if (a.type == 0x80 && a.name.length() == 0) {
                mftRuns = a.runs;
                mftSize = a.real;
            }
        }
        if (mftRuns == null) throw new Exception("NTFS: la MFT no tiene datos");
        // la MFT puede estar partida en una lista de atributos
        Vector full = loadAttrs(0);
        for (int i = 0; i < full.size(); i++) {
            Attr a = (Attr) full.elementAt(i);
            if (a.type == 0x80 && a.name.length() == 0) {
                mftRuns = a.runs;
                mftSize = a.real;
            }
        }
        try {
            Vector v = loadAttrs(3);
            for (int i = 0; i < v.size(); i++) {
                Attr a = (Attr) v.elementAt(i);
                if (a.type == 0x60 && a.value != null) {
                    StringBuffer sb = new StringBuffer();
                    for (int k = 0; k + 1 < a.value.length; k += 2) sb.append((char) le16(a.value, k));
                    if (sb.length() > 0) vol = sb.toString();
                }
            }
        } catch (Throwable t) {
            // sin nombre de volumen
        }
        if (vol.equals("USB")) vol = "NTFS";
    }

    public String typeName() { return "NTFS"; }

    protected byte[] readRaw(long off, int len) throws Exception {
        if (off < SPARSE / 2) return new byte[len];
        return super.readRaw(off, len);
    }

    // ------------------------------------------------------------ registros y atributos

    private byte[] fix(byte[] r, int size, String magic) throws Exception {
        for (int i = 0; i < 4; i++) if (r[i] != (byte) magic.charAt(i)) throw new Exception("NTFS: registro sin firma " + magic);
        int uo = le16(r, 4), uc = le16(r, 6);
        if (uc < 2 || uo + 2 * uc > size) throw new Exception("NTFS: matriz de actualización inválida");
        for (int i = 1; i < uc; i++) {
            int e = i * 512 - 2;
            if (e + 2 > size) break;
            if (r[e] != r[uo] || r[e + 1] != r[uo + 1]) throw new Exception("NTFS: registro dañado (fixup)");
            r[e] = r[uo + 2 * i];
            r[e + 1] = r[uo + 2 * i + 1];
        }
        return r;
    }

    private byte[] record(long n) throws Exception {
        long off = n * recSize;
        byte[] raw = readMft(off, recSize);
        return fix(raw, recSize, "FILE");
    }

    private byte[] readMft(long off, int len) throws Exception {
        byte[] out = new byte[len];
        long pos = 0;
        int got = 0;
        for (int i = 0; i < mftRuns.size() && got < len; i++) {
            long[] r = (long[]) mftRuns.elementAt(i);
            long rl = r[1] * clusterBytes;
            if (off + got < pos + rl) {
                long in = off + got - pos;
                int n = (int) Math.min(len - got, rl - in);
                byte[] part = r[0] < 0 ? new byte[n] : readBytes(r[0] * clusterBytes + in, n);
                System.arraycopy(part, 0, out, got, n);
                got += n;
            }
            pos += rl;
        }
        if (got < len) throw new Exception("NTFS: registro fuera de la MFT");
        return out;
    }

    /** Atributos del registro (sin expandir lista de atributos). */
    private Vector attrs(byte[] rec, long recNo, boolean any) throws Exception {
        Vector out = new Vector();
        int o = le16(rec, 20);
        int used = (int) le32(rec, 24);
        while (o + 8 <= recSize && o + 8 <= used) {
            int type = (int) le32(rec, o);
            if (type == 0xFFFFFFFF || type == 0) break;
            int len = (int) le32(rec, o + 4);
            if (len < 16 || o + len > recSize) throw new Exception("NTFS: atributo dañado");
            Attr a = new Attr();
            a.type = type;
            a.nonres = rec[o + 8] != 0;
            int nl = rec[o + 9] & 0xFF;
            int no = le16(rec, o + 10);
            a.flags = le16(rec, o + 12);
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < nl; i++) sb.append((char) le16(rec, o + no + 2 * i));
            a.name = sb.toString();
            if (!a.nonres) {
                int vl = (int) le32(rec, o + 16);
                int vo = le16(rec, o + 20);
                if (vo + vl > len) throw new Exception("NTFS: valor residente fuera del atributo");
                a.value = new byte[vl];
                System.arraycopy(rec, o + vo, a.value, 0, vl);
                a.real = vl;
            } else {
                a.startVcn = le64(rec, o + 16);
                int mo = le16(rec, o + 0x20);
                a.real = le64(rec, o + 0x30);
                a.init = le64(rec, o + 0x38);
                parseRuns(rec, o + mo, o + len, a.runs);
            }
            out.addElement(a);
            o += len;
        }
        return out;
    }

    private static void parseRuns(byte[] b, int o, int end, Vector out) {
        long lcn = 0;
        while (o < end && b[o] != 0) {
            int h = b[o] & 0xFF;
            int ln = h & 15, on = h >> 4;
            o++;
            long len = 0;
            for (int i = 0; i < ln; i++) len |= (b[o + i] & 0xFFL) << (8 * i);
            o += ln;
            if (on == 0) {
                out.addElement(new long[] { -1, len });
            } else {
                long delta = 0;
                for (int i = 0; i < on; i++) delta |= (b[o + i] & 0xFFL) << (8 * i);
                if ((b[o + on - 1] & 0x80) != 0) delta |= -1L << (8 * on);
                o += on;
                lcn += delta;
                out.addElement(new long[] { lcn, len });
            }
        }
    }

    /** Atributos de un registro con la lista de atributos expandida (varios registros de extensión). */
    private Vector loadAttrs(long recNo) throws Exception {
        byte[] rec = record(recNo);
        Vector base = attrs(rec, recNo, false);
        Attr list = null;
        for (int i = 0; i < base.size(); i++) if (((Attr) base.elementAt(i)).type == 0x20) list = (Attr) base.elementAt(i);
        if (list == null) return base;
        byte[] data = list.value != null ? list.value : readRunsAll(list.runs, list.real);
        Vector result = new Vector();
        for (int i = 0; i < base.size(); i++) {
            if (((Attr) base.elementAt(i)).type != 0x20) result.addElement(base.elementAt(i));
        }
        Vector seen = new Vector();
        int p = 0;
        while (p + 26 <= data.length) {
            int len = le16(data, p + 4);
            if (len < 26) break;
            long ref = le64(data, p + 16) & 0xFFFFFFFFFFFFL;
            if (ref != recNo && seen.indexOf(new Long(ref)) < 0) {
                seen.addElement(new Long(ref));
                Vector ext = attrs(record(ref), ref, true);
                for (int k = 0; k < ext.size(); k++) {
                    Attr a = (Attr) ext.elementAt(k);
                    if (a.type != 0x20) merge(result, a);
                }
            }
            p += len;
        }
        return result;
    }

    private void merge(Vector result, Attr a) {
        for (int i = 0; i < result.size(); i++) {
            Attr b = (Attr) result.elementAt(i);
            if (b.type == a.type && b.name.equals(a.name) && b.nonres && a.nonres) {
                if (a.startVcn > 0) {
                    for (int k = 0; k < a.runs.size(); k++) b.runs.addElement(a.runs.elementAt(k));
                    return;
                } else {
                    for (int k = 0; k < b.runs.size(); k++) a.runs.addElement(b.runs.elementAt(k));
                    result.setElementAt(a, i);
                    return;
                }
            }
        }
        result.addElement(a);
    }

    private byte[] readRunsAll(Vector runs, long size) throws Exception {
        byte[] out = new byte[(int) size];
        int got = 0;
        for (int i = 0; i < runs.size() && got < size; i++) {
            long[] r = (long[]) runs.elementAt(i);
            int n = (int) Math.min(size - got, r[1] * clusterBytes);
            byte[] part = r[0] < 0 ? new byte[n] : readRaw(r[0] * clusterBytes, n);
            System.arraycopy(part, 0, out, got, n);
            got += n;
        }
        return out;
    }

    // ------------------------------------------------------------ carpetas

    public Vector listRoot() throws Exception {
        return listDir(5);
    }

    public Vector list(FileItem dir) throws Exception {
        return listDir(((long[]) dir.ref)[0]);
    }

    private Vector listDir(long recNo) throws Exception {
        Vector at = loadAttrs(recNo);
        Attr root = null, alloc = null;
        for (int i = 0; i < at.size(); i++) {
            Attr a = (Attr) at.elementAt(i);
            if (a.name.equals("$I30")) {
                if (a.type == 0x90) root = a;
                if (a.type == 0xA0) alloc = a;
            }
        }
        if (root == null || root.value == null) throw new Exception("NTFS: no es una carpeta");
        byte[] ir = root.value;
        Vector items = new Vector();
        byte[] adata = null;
        int eo = (int) le32(ir, 16);
        int il = (int) le32(ir, 20);
        walkEntries(ir, 16 + eo, 16 + il, alloc, items, recNo, 0);
        return items;
    }

    private byte[] allocData;
    private long allocFor = -1;

    private void walkEntries(byte[] buf, int off, int end, Attr alloc, Vector items, long dirNo, int depth) throws Exception {
        if (depth > 20) return;
        while (off + 16 <= end) {
            long ref = le64(buf, off) & 0xFFFFFFFFFFFFL;
            int el = le16(buf, off + 8);
            int kl = le16(buf, off + 10);
            int fl = le16(buf, off + 12);
            if (el < 16) break;
            if ((fl & 1) != 0 && alloc != null) {
                long vcn = le64(buf, off + el - 8);
                byte[] blk = readIndexBlock(alloc, vcn, dirNo);
                int eo2 = (int) le32(blk, 0x18);
                int il2 = (int) le32(blk, 0x1C);
                walkEntries(blk, 0x18 + eo2, 0x18 + il2, alloc, items, dirNo, depth + 1);
            }
            if ((fl & 2) != 0) break;
            if (kl >= 66 && ref >= 24 || (kl >= 66 && dirNo != 5)) {
                int ns = buf[off + 16 + 65] & 0xFF;
                int nlen = buf[off + 16 + 64] & 0xFF;
                if (ns != 2 && nlen > 0 && 16 + 66 + 2 * nlen <= el) {
                    StringBuffer sb = new StringBuffer();
                    for (int i = 0; i < nlen; i++) sb.append((char) le16(buf, off + 16 + 66 + 2 * i));
                    long flags = le32(buf, off + 16 + 56);
                    FileItem it = new FileItem();
                    it.name = sb.toString();
                    it.dir = (flags & 0x10000000L) != 0;
                    it.size = it.dir ? 0 : le64(buf, off + 16 + 48);
                    it.ref = new long[] { ref };
                    FileItem.sortedAdd(items, it);
                }
            }
            off += el;
        }
    }

    private byte[] readIndexBlock(Attr alloc, long vcn, long dirNo) throws Exception {
        long byteOff = vcn * (idxBlock >= clusterBytes ? clusterBytes : 512);
        byte[] out = new byte[idxBlock];
        long pos = 0;
        int got = 0;
        for (int i = 0; i < alloc.runs.size() && got < idxBlock; i++) {
            long[] r = (long[]) alloc.runs.elementAt(i);
            long rl = r[1] * clusterBytes;
            if (byteOff + got < pos + rl) {
                long in = byteOff + got - pos;
                int n = (int) Math.min(idxBlock - got, rl - in);
                byte[] part = r[0] < 0 ? new byte[n] : readRaw(r[0] * clusterBytes + in, n);
                System.arraycopy(part, 0, out, got, n);
                got += n;
            }
            pos += rl;
        }
        if (got < idxBlock) throw new Exception("NTFS: bloque de índice fuera de la carpeta");
        return fix(out, idxBlock, "INDX");
    }

    // ------------------------------------------------------------ datos de archivos

    private Attr dataOf(FileItem f) throws Exception {
        Vector at = loadAttrs(((long[]) f.ref)[0]);
        for (int i = 0; i < at.size(); i++) {
            Attr a = (Attr) at.elementAt(i);
            if (a.type == 0x80 && a.name.length() == 0) {
                if ((a.flags & 0x0001) != 0) throw new Exception("Archivo comprimido de NTFS: no soportado");
                if ((a.flags & 0x4000) != 0) throw new Exception("Archivo cifrado de NTFS: no se puede leer");
                return a;
            }
        }
        throw new Exception("NTFS: el archivo no tiene datos");
    }

    protected Vector extents(FileItem f) throws Exception {
        Attr a = dataOf(f);
        Vector out = new Vector();
        if (a.value != null) throw new Exception("NTFS: archivo residente");
        f.size = a.real;
        for (int i = 0; i < a.runs.size(); i++) {
            long[] r = (long[]) a.runs.elementAt(i);
            out.addElement(new long[] { r[0] < 0 ? SPARSE : r[0] * clusterBytes, r[1] * clusterBytes });
        }
        return out;
    }

    public synchronized byte[] readFileRange(FileItem f, long off, int len) throws Exception {
        Attr a = dataOf(f);
        if (a.value != null) {
            if (off >= a.value.length) return new byte[0];
            int n = (int) Math.min(len, a.value.length - off);
            byte[] out = new byte[n];
            System.arraycopy(a.value, (int) off, out, 0, n);
            return out;
        }
        f.size = a.real;
        return super.readFileRange(f, off, len);
    }

    public String preview(FileItem f, int max) throws Exception {
        Attr a = dataOf(f);
        if (a.value != null) {
            int n = (int) Math.min(a.value.length, max);
            if (n <= 0) return "(archivo vacío)";
            return Preview.make(a.value, n, a.value.length);
        }
        f.size = a.real;
        return super.preview(f, max);
    }

    public void copy(FileItem f, OutputStream out, Progress p) throws Exception {
        Attr a = dataOf(f);
        if (a.value != null) {
            out.write(a.value);
            if (p != null) p.add(a.value.length);
            return;
        }
        f.size = a.real;
        super.copy(f, out, p);
    }
}
