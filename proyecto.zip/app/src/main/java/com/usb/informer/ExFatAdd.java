package com.usb.informer;

import java.util.Calendar;
import java.util.Hashtable;
import java.util.Vector;

/**
 * Añade archivos y carpetas a un USB exFAT que YA tiene datos, sin borrar nada.
 * Los archivos se guardan contiguos siempre que hay hueco (sin cadena en la FAT, como hace Windows);
 * si no, se usa la cadena FAT. Datos primero, mapa de bits y FAT después y, por último, la entrada de directorio.
 */
public class ExFatAdd extends FsAdd {
    private final OpticalDisc d;
    private final int bs;
    private long base;
    private int bps, spc, nfats;
    private long clusterBytes, nClusters, fatOff, fatBytes, heapOff, rootFirst;
    private long bmFirst, bmBytes;
    private byte[] fat, bitmap;
    private long fdLo = Long.MAX_VALUE, fdHi = -1, bdLo = Long.MAX_VALUE, bdHi = -1;
    private long freeC, hint = 2;
    private char[] upcase;
    private long activeFatOff;

    private static final long EOC = 0xFFFFFFFFL;

    private static class Ent {
        String name;
        boolean dir, noChain;
        long first, size;
        Dir owner;
        int off;
    }

    private static class Dir {
        Ent self;               // null en la raíz
        long first;
        boolean noChain;
        long dataLen;
        Vector chain = new Vector();
        byte[] data;
        Hashtable names = new Hashtable();
    }

    private ExFatAdd(OpticalDisc d) {
        this.d = d;
        this.bs = d.blockSize;
    }

    private static int le16(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8); }

    private static long le32(byte[] b, int o) {
        return (b[o] & 0xFFL) | ((b[o + 1] & 0xFFL) << 8) | ((b[o + 2] & 0xFFL) << 16) | ((b[o + 3] & 0xFFL) << 24);
    }

    private static long le64(byte[] b, int o) { return le32(b, o) | (le32(b, o + 4) << 32); }

    private static void put16(byte[] b, int o, int v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
    }

    private static void put32(byte[] b, int o, long v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
        b[o + 2] = (byte) (v >> 16);
        b[o + 3] = (byte) (v >> 24);
    }

    private static void put64(byte[] b, int o, long v) {
        put32(b, o, v & 0xFFFFFFFFL);
        put32(b, o + 4, v >>> 32);
    }

    protected long maxFile() { return Long.MAX_VALUE; }

    public String typeName() { return "exFAT"; }

    public long freeBytes() { return freeC * clusterBytes; }

    public long clusterBytes() { return clusterBytes; }

    // ------------------------------------------------------------------ abrir

    public static ExFatAdd tryOpen(OpticalDisc d, long lba) throws Exception {
        byte[] b = d.read((int) lba, 1);
        if (!(b[3] == 'E' && b[4] == 'X' && b[5] == 'F' && b[6] == 'A' && b[7] == 'T')) return null;
        if (b.length < 512 || (b[510] & 0xFF) != 0x55 || (b[511] & 0xFF) != 0xAA) return null;
        ExFatAdd f = new ExFatAdd(d);
        f.base = lba * f.bs;
        int shift = b[108] & 0xFF, sshift = b[109] & 0xFF;
        if (shift < 9 || shift > 12 || sshift > 25 - shift) return null;
        f.bps = 1 << shift;
        f.spc = 1 << sshift;
        f.clusterBytes = (long) f.bps * f.spc;
        f.fatOff = le32(b, 80) * f.bps;
        f.fatBytes = le32(b, 84) * f.bps;
        f.heapOff = le32(b, 88) * f.bps;
        f.nClusters = le32(b, 92);
        f.rootFirst = le32(b, 96);
        f.nfats = b[110] & 0xFF;
        f.activeFatOff = f.fatOff + ((le16(b, 106) & 1) != 0 && f.nfats > 1 ? f.fatBytes : 0);
        if (f.nClusters < 1 || f.rootFirst < 2) return null;
        long need = (f.nClusters + 2) * 4;
        if (need > 256L * 1024 * 1024 || need > f.fatBytes + 8) {
            if (need > 256L * 1024 * 1024) throw new Exception("La FAT de este USB exFAT es demasiado grande para cargarla en memoria.");
        }
        f.fat = f.rd(f.activeFatOff, (int) Math.min(need, f.fatBytes));
        f.loadRoot();
        return f;
    }

    private void loadRoot() throws Exception {
        Dir root = loadDirChain(rootFirst, false, 0, null);
        byte[] b = root.data;
        long upFirst = 0, upLen = 0;
        for (int o = 0; o + 32 <= b.length; o += 32) {
            int t = b[o] & 0xFF;
            if (t == 0) break;
            if (t == 0x81) {
                bmFirst = le32(b, o + 20);
                bmBytes = le64(b, o + 24);
            } else if (t == 0x82) {
                upFirst = le32(b, o + 20);
                upLen = le64(b, o + 24);
            } else if (t == 0x83) {
                int n = b[o + 1] & 0xFF;
                StringBuffer sb = new StringBuffer();
                for (int i = 0; i < n && i < 11; i++) sb.append((char) le16(b, o + 2 + 2 * i));
                label = sb.toString();
            }
        }
        if (bmFirst < 2 || bmBytes <= 0) throw new Exception("No encuentro el mapa de bits de espacio libre del exFAT.");
        long needBytes = (nClusters + 7) / 8;
        if (bmBytes < needBytes) throw new Exception("Mapa de bits de espacio del exFAT incoherente.");
        long bmClusters = (bmBytes + clusterBytes - 1) / clusterBytes;
        for (long i = 1; i < bmClusters; i++) {
            if (fatGet(bmFirst + i - 1) != bmFirst + i) throw new Exception("El mapa de bits del exFAT está fragmentado (no soportado).");
        }
        bitmap = rd(clusterOff(bmFirst), (int) needBytes);
        freeC = 0;
        for (long c = 2; c < nClusters + 2; c++) if (!bit(c)) freeC++;
        upcase = new char[65536];
        for (int i = 0; i < 65536; i++) upcase[i] = Character.toUpperCase((char) i);
        if (upFirst >= 2 && upLen > 0 && upLen < 400000) {
            try {
                byte[] u = rd(clusterOff(upFirst), (int) upLen);
                int idx = 0;
                for (int i = 0; i + 1 < u.length && idx < 65536; i += 2) {
                    int v = le16(u, i);
                    if (v == 0xFFFF && i + 3 < u.length) {
                        idx += le16(u, i + 2);    // tramo sin cambios
                        i += 2;
                    } else {
                        upcase[idx] = (char) v;
                        idx++;
                    }
                }
            } catch (Throwable t) {
                // tabla ilegible: se queda la de Java
            }
        }
    }

    // ------------------------------------------------------------------ E/S

    private long clusterOff(long c) { return heapOff + (c - 2) * clusterBytes; }

    private byte[] rd(long off, int len) throws Exception {
        long abs = base + off;
        byte[] out = new byte[len];
        int got = 0;
        while (got < len) {
            long a = abs + got;
            long blk = a / bs;
            int skip = (int) (a % bs);
            int n = Math.min(len - got, 128 * bs - skip);
            int count = (skip + n + bs - 1) / bs;
            byte[] b = d.read((int) blk, count);
            System.arraycopy(b, skip, out, got, n);
            got += n;
        }
        return out;
    }

    private void wr(long off, byte[] src, int so, int len) throws Exception {
        long abs = base + off;
        int done = 0;
        while (done < len) {
            long a = abs + done;
            long blk = a / bs;
            int skip = (int) (a % bs);
            int n = Math.min(len - done, 65536 - skip);
            int blocks = (skip + n + bs - 1) / bs;
            int total = blocks * bs;
            byte[] buf;
            if (skip == 0 && n == total) buf = new byte[total];
            else buf = d.read((int) blk, blocks);
            System.arraycopy(src, so + done, buf, skip, n);
            d.write((int) blk, buf, total);
            done += n;
        }
    }

    // ------------------------------------------------------------------ FAT y mapa de bits

    private long fatGet(long c) {
        int o = (int) (c * 4);
        if (o + 4 > fat.length) return 0;
        return le32(fat, o);
    }

    private void fatSet(long c, long v) {
        int o = (int) (c * 4);
        put32(fat, o, v);
        if (o < fdLo) fdLo = o;
        if (o + 3 > fdHi) fdHi = o + 3;
    }

    private void flushFat() throws Exception {
        if (fdHi < fdLo) return;
        long lo = fdLo / bs * bs;
        long hi = Math.min((long) fat.length, (fdHi / bs + 1) * bs);
        wr(activeFatOff + lo, fat, (int) lo, (int) (hi - lo));
        fdLo = Long.MAX_VALUE;
        fdHi = -1;
    }

    private boolean bit(long c) {
        long i = c - 2;
        return (bitmap[(int) (i >> 3)] & (1 << (int) (i & 7))) != 0;
    }

    private void setBit(long c, boolean v) {
        long i = c - 2;
        int o = (int) (i >> 3);
        if (v) bitmap[o] |= (byte) (1 << (int) (i & 7));
        else bitmap[o] &= (byte) ~(1 << (int) (i & 7));
        if (o < bdLo) bdLo = o;
        if (o > bdHi) bdHi = o;
    }

    private void flushBitmap() throws Exception {
        if (bdHi < bdLo) return;
        long lo = bdLo / bs * bs;
        long hi = Math.min((long) bitmap.length, (bdHi / bs + 1) * bs);
        wr(clusterOff(bmFirst) + lo, bitmap, (int) lo, (int) (hi - lo));
        bdLo = Long.MAX_VALUE;
        bdHi = -1;
    }

    /** Reserva n clusters; devuelve tramos {inicio, cuántos}. Contiguo si hay hueco. Solo en memoria. */
    private Vector alloc(long n) throws Exception {
        if (n > freeC) throw new Exception("No hay espacio libre suficiente en el USB");
        Vector runs = new Vector();
        long start = hint < 2 || hint >= nClusters + 2 ? 2 : hint;
        long found = -1;
        for (int pass = 0; pass < 2 && found < 0; pass++) {
            long from = pass == 0 ? start : 2, to = pass == 0 ? nClusters + 2 : Math.min(start + n, nClusters + 2);
            long run = 0, rs = from;
            for (long c = from; c < to; c++) {
                if (!bit(c)) {
                    if (run == 0) rs = c;
                    run++;
                    if (run == n) { found = rs; break; }
                } else {
                    run = 0;
                }
            }
        }
        if (found >= 0) {
            runs.addElement(new long[] { found, n });
            for (long c = found; c < found + n; c++) setBit(c, true);
            hint = found + n;
        } else {
            long c = start, got = 0, rs = -1, rl = 0, scanned = 0;
            while (got < n && scanned < nClusters) {
                if (!bit(c)) {
                    setBit(c, true);
                    if (rl > 0 && c == rs + rl) {
                        rl++;
                    } else {
                        if (rl > 0) runs.addElement(new long[] { rs, rl });
                        rs = c;
                        rl = 1;
                    }
                    got++;
                }
                c++;
                scanned++;
                if (c >= nClusters + 2) c = 2;
            }
            if (rl > 0) runs.addElement(new long[] { rs, rl });
            if (got < n) {
                release(runs);
                throw new Exception("No hay espacio libre suficiente en el USB");
            }
            hint = c;
            // cadena FAT entre todos los clusters
            for (int i = 0; i < runs.size(); i++) {
                long[] r = (long[]) runs.elementAt(i);
                for (long k = 0; k < r[1]; k++) {
                    boolean last = i == runs.size() - 1 && k == r[1] - 1;
                    long next = k + 1 < r[1] ? r[0] + k + 1 : (last ? EOC : ((long[]) runs.elementAt(i + 1))[0]);
                    fatSet(r[0] + k, next);
                }
            }
        }
        freeC -= n;
        return runs;
    }

    private void release(Vector runs) {
        long n = 0;
        for (int i = 0; i < runs.size(); i++) {
            long[] r = (long[]) runs.elementAt(i);
            for (long c = r[0]; c < r[0] + r[1]; c++) {
                setBit(c, false);
                if (runs.size() > 1) fatSet(c, 0);
            }
            n += r[1];
        }
        freeC += n;
    }

    // ------------------------------------------------------------------ directorios

    private Dir loadDirChain(long first, boolean noChain, long dataLen, Ent self) throws Exception {
        Dir dir = new Dir();
        dir.self = self;
        dir.first = first;
        dir.noChain = noChain;
        dir.dataLen = dataLen;
        if (noChain) {
            long n = (dataLen + clusterBytes - 1) / clusterBytes;
            for (long i = 0; i < n; i++) dir.chain.addElement(new Long(first + i));
        } else {
            long c = first;
            long guard = 0;
            while (c >= 2 && c < nClusters + 2 && guard++ < nClusters) {
                dir.chain.addElement(new Long(c));
                long nx = fatGet(c);
                if (nx >= 0xFFFFFFF8L || nx < 2) break;
                c = nx;
            }
        }
        dir.data = new byte[(int) (dir.chain.size() * clusterBytes)];
        int i = 0;
        while (i < dir.chain.size()) {
            int j = i;
            while (j + 1 < dir.chain.size() && ((Long) dir.chain.elementAt(j + 1)).longValue() == ((Long) dir.chain.elementAt(j)).longValue() + 1) j++;
            byte[] part = rd(clusterOff(((Long) dir.chain.elementAt(i)).longValue()), (int) ((j - i + 1) * clusterBytes));
            System.arraycopy(part, 0, dir.data, (int) (i * clusterBytes), part.length);
            i = j + 1;
        }
        indexDir(dir);
        return dir;
    }

    private void indexDir(Dir dir) {
        byte[] b = dir.data;
        for (int o = 0; o + 32 <= b.length; o += 32) {
            int t = b[o] & 0xFF;
            if (t == 0) break;
            if (t != 0x85) continue;
            int cnt = b[o + 1] & 0xFF;
            if (o + (cnt + 1) * 32 > b.length || cnt < 2) continue;
            int so = o + 32;
            if ((b[so] & 0xFF) != 0xC0) continue;
            int nameLen = b[so + 3] & 0xFF;
            StringBuffer sb = new StringBuffer();
            for (int k = 2; k <= cnt && sb.length() < nameLen; k++) {
                int no = o + k * 32;
                if ((b[no] & 0xFF) != 0xC1) break;
                for (int j = 0; j < 15 && sb.length() < nameLen; j++) sb.append((char) le16(b, no + 2 + 2 * j));
            }
            Ent e = new Ent();
            e.name = sb.toString();
            e.dir = (le16(b, o + 4) & 0x10) != 0;
            e.noChain = (b[so + 1] & 2) != 0;
            e.first = le32(b, so + 20);
            e.size = le64(b, so + 24);
            e.owner = dir;
            e.off = o;
            dir.names.put(e.name.toLowerCase(), e);
            o += cnt * 32;
        }
    }

    /** Borra un archivo existente: anula su conjunto de entradas y libera sus clusters. */
    private void deleteEntry(Dir dir, Ent e) throws Exception {
        int cnt = (dir.data[e.off + 1] & 0xFF) + 1;
        for (int k = 0; k < cnt; k++) dir.data[e.off + k * 32] &= (byte) 0x7F;
        writeDirBytes(dir, e.off, cnt * 32);
        dir.names.remove(e.name.toLowerCase());
        if (e.size > 0 && e.first >= 2) {
            long ncl = (e.size + clusterBytes - 1) / clusterBytes;
            long n = 0;
            if (e.noChain) {
                for (long i = 0; i < ncl && e.first + i < nClusters + 2; i++) {
                    setBit(e.first + i, false);
                    n++;
                }
            } else {
                long c = e.first;
                while (c >= 2 && c < nClusters + 2 && n <= nClusters) {
                    long nx = fatGet(c);
                    setBit(c, false);
                    fatSet(c, 0);
                    n++;
                    if (nx < 2 || nx >= 0xFFFFFFF7L) break;
                    c = nx;
                }
            }
            freeC += n;
            if (e.first < hint) hint = e.first;
        }
        flushBitmap();
        flushFat();
    }

    private int nameHash(String name) {
        int h = 0;
        for (int i = 0; i < name.length(); i++) {
            int c = upcase[name.charAt(i)];
            h = ((h & 1) != 0 ? 0x8000 : 0) + (h >> 1) + (c & 0xFF);
            h &= 0xFFFF;
            h = ((h & 1) != 0 ? 0x8000 : 0) + (h >> 1) + ((c >> 8) & 0xFF);
            h &= 0xFFFF;
        }
        return h;
    }

    private static int setChecksum(byte[] b, int off, int entries) {
        int sum = 0;
        for (int i = 0; i < entries * 32; i++) {
            if (i == 2 || i == 3) continue;
            sum = (((sum & 1) != 0 ? 0x8000 : 0) + (sum >> 1) + (b[off + i] & 0xFF)) & 0xFFFF;
        }
        return sum;
    }

    private static String cleanName(String n) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < n.length(); i++) {
            char c = n.charAt(i);
            if (c < 32 || "\\/:*?\"<>|".indexOf(c) >= 0) c = '_';
            sb.append(c);
        }
        String r = sb.toString();
        while (r.length() > 0 && (r.endsWith(" ") || r.endsWith("."))) r = r.substring(0, r.length() - 1);
        if (r.length() > 255) r = r.substring(0, 255);
        return r.length() == 0 ? "_" : r;
    }

    private static int stamp() {
        Calendar c = Calendar.getInstance();
        return ((c.get(Calendar.YEAR) - 1980) << 25) | ((c.get(Calendar.MONTH) + 1) << 21) | (c.get(Calendar.DAY_OF_MONTH) << 16)
                | (c.get(Calendar.HOUR_OF_DAY) << 11) | (c.get(Calendar.MINUTE) << 5) | (c.get(Calendar.SECOND) / 2);
    }

    private static int utcByte() {
        int off = (Calendar.getInstance().getTimeZone().getOffset(System.currentTimeMillis()) / 900000) & 0x7F;
        return 0x80 | off;
    }

    /** Crea el conjunto de entradas (archivo, flujo, nombres). Devuelve el desplazamiento dentro del directorio. */
    private int addEntry(Dir dir, String name, boolean isDir, long first, long size, boolean noChain) throws Exception {
        int nameEnts = (name.length() + 14) / 15;
        int total = 2 + nameEnts;
        byte[] e = new byte[total * 32];
        int ts = stamp();
        e[0] = (byte) 0x85;
        e[1] = (byte) (1 + nameEnts);
        put16(e, 4, isDir ? 0x10 : 0x20);
        put32(e, 8, ts);
        put32(e, 12, ts);
        put32(e, 16, ts);
        e[22] = (byte) utcByte();
        e[23] = (byte) utcByte();
        e[24] = (byte) utcByte();
        e[32] = (byte) 0xC0;
        e[33] = (byte) (first == 0 ? 0x01 : (noChain ? 0x03 : 0x01));
        e[35] = (byte) name.length();
        put16(e, 36, nameHash(name));
        put64(e, 40, size);
        put32(e, 52, first);
        put64(e, 56, size);
        for (int k = 0; k < nameEnts; k++) {
            int o = 64 + k * 32;
            e[o] = (byte) 0xC1;
            for (int j = 0; j < 15; j++) {
                int idx = k * 15 + j;
                put16(e, o + 2 + 2 * j, idx < name.length() ? name.charAt(idx) : 0);
            }
        }
        put16(e, 2, setChecksum(e, 0, total));
        int at = findSlots(dir, total);
        System.arraycopy(e, 0, dir.data, at * 32, e.length);
        writeDirBytes(dir, at * 32, e.length);
        Ent en = new Ent();
        en.name = name;
        en.dir = isDir;
        en.noChain = noChain && first != 0;
        en.first = first;
        en.size = size;
        en.owner = dir;
        en.off = at * 32;
        dir.names.put(name.toLowerCase(), en);
        return at * 32;
    }

    private int findSlots(Dir dir, int slots) throws Exception {
        for (;;) {
            int run = 0, startIdx = 0, total = dir.data.length / 32;
            for (int i = 0; i < total; i++) {
                int t = dir.data[i * 32] & 0x80;
                if (t == 0) {
                    if (run == 0) startIdx = i;
                    run++;
                    if (run == slots) return startIdx;
                } else {
                    run = 0;
                }
            }
            growDir(dir);
        }
    }

    /** Añade un cluster al final del directorio. */
    private void growDir(Dir dir) throws Exception {
        long last = ((Long) dir.chain.elementAt(dir.chain.size() - 1)).longValue();
        long nc;
        boolean inPlace = dir.noChain && last + 1 < nClusters + 2 && !bit(last + 1);
        if (inPlace) {
            nc = last + 1;
            setBit(nc, true);
            freeC--;
        } else {
            Vector r = alloc(1);
            nc = ((long[]) r.elementAt(0))[0];
            if (dir.noChain) {
                // pasa a usar cadena FAT: se enlazan los clusters que ya tenía
                for (int i = 0; i < dir.chain.size(); i++) {
                    long c = ((Long) dir.chain.elementAt(i)).longValue();
                    fatSet(c, i + 1 < dir.chain.size() ? ((Long) dir.chain.elementAt(i + 1)).longValue() : nc);
                }
                fatSet(nc, EOC);
            } else {
                fatSet(last, nc);
                fatSet(nc, EOC);
            }
        }
        wr(clusterOff(nc), new byte[(int) clusterBytes], 0, (int) clusterBytes);
        flushBitmap();
        flushFat();
        dir.chain.addElement(new Long(nc));
        byte[] nd = new byte[dir.data.length + (int) clusterBytes];
        System.arraycopy(dir.data, 0, nd, 0, dir.data.length);
        dir.data = nd;
        if (dir.self != null) {
            // actualiza longitud (y cadena) en la entrada del directorio, dentro de su padre
            Ent s = dir.self;
            Dir par = s.owner;
            int cnt = par.data[s.off + 1] & 0xFF;
            int so = s.off + 32;
            dir.dataLen = dir.chain.size() * clusterBytes;
            put64(par.data, so + 8, dir.dataLen);
            put64(par.data, so + 24, dir.dataLen);
            if (!inPlace && dir.noChain) {
                par.data[so + 1] = (byte) (par.data[so + 1] & ~2);   // ya no es contiguo
                dir.noChain = false;
                s.noChain = false;
            }
            put16(par.data, s.off + 2, setChecksum(par.data, s.off, cnt + 1));
            writeDirBytes(par, s.off, (cnt + 1) * 32);
        }
    }

    private void writeDirBytes(Dir dir, int off, int len) throws Exception {
        int end = off + len, pos = off;
        while (pos < end) {
            int ci = (int) (pos / clusterBytes);
            int inner = (int) (pos % clusterBytes);
            int n = (int) Math.min(end - pos, clusterBytes - inner);
            wr(clusterOff(((Long) dir.chain.elementAt(ci)).longValue()) + inner, dir.data, pos, n);
            pos += n;
        }
    }

    // ------------------------------------------------------------------ copiar

    public void addTree(Vector items, DiscTree t, Progress p, boolean verify) throws Exception {
        Dir root = loadDirChain(rootFirst, false, 0, null);
        try {
            copyItems(items, t, root, p, verify, "");
        } finally {
            try {
                flushBitmap();
                flushFat();
                d.flush();
            } catch (Exception e) {
                // el error original es el importante
            }
        }
    }

    private void copyItems(Vector items, DiscTree t, Dir dir, Progress p, boolean verify, String path) throws Exception {
        for (int i = 0; i < items.size(); i++) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            FileItem it = (FileItem) items.elementAt(i);
            String nm = cleanName(it.name);
            Ent ex = (Ent) dir.names.get(nm.toLowerCase());
            if (it.dir) {
                Dir sub;
                if (ex != null && ex.dir) {
                    sub = loadDirChain(ex.first, ex.noChain, ex.size, ex);
                } else if (ex != null) {
                    skipped.addElement(path + it.name + " (ya existe un archivo con ese nombre)");
                    continue;
                } else {
                    Vector runs = alloc(1);
                    long c = ((long[]) runs.elementAt(0))[0];
                    try {
                        wr(clusterOff(c), new byte[(int) clusterBytes], 0, (int) clusterBytes);
                        flushBitmap();
                        flushFat();
                        addEntry(dir, nm, true, c, clusterBytes, true);
                    } catch (Exception e) {
                        release(runs);
                        throw e;
                    }
                    Ent ne = (Ent) dir.names.get(nm.toLowerCase());
                    sub = loadDirChain(c, true, clusterBytes, ne);
                    dirs++;
                }
                copyItems(t.list(it), t, sub, p, verify, path + it.name + "/");
            } else {
                if (ex != null && ex.dir) {
                    skipped.addElement(path + it.name + " (ya existe una carpeta con ese nombre)");
                    continue;
                }
                if (ex != null) {
                    if (!overwrite) {
                        skipped.addElement(path + it.name + " (ya existe en el USB; no se sobrescribe)");
                        continue;
                    }
                    deleteEntry(dir, ex);
                    replaced++;
                }
                copyFile(dir, nm, it, t, p, verify);
            }
        }
    }

    private void copyFile(Dir dir, String nm, FileItem it, DiscTree t, Progress p, boolean verify) throws Exception {
        if (p != null) p.file(it.name);
        long first = 0;
        boolean noChain = true;
        if (it.size > 0) {
            long need = (it.size + clusterBytes - 1) / clusterBytes;
            Vector runs = alloc(need);
            try {
                first = ((long[]) runs.elementAt(0))[0];
                noChain = runs.size() == 1;
                writeData(runs, it, t, p);
                if (verify) verifyData(runs, it, t, p);
                flushBitmap();
                flushFat();
            } catch (Exception e) {
                release(runs);
                throw e;
            }
        }
        addEntry(dir, nm, false, first, it.size, noChain);
        files++;
        bytes += it.size;
    }

    private void writeData(Vector runs, FileItem it, DiscTree t, Progress p) throws Exception {
        byte[] buf = new byte[65536];
        long off = 0;
        for (int i = 0; i < runs.size(); i++) {
            long[] r = (long[]) runs.elementAt(i);
            long runBytes = r[1] * clusterBytes;
            long pos = clusterOff(r[0]);
            long done = 0;
            while (done < runBytes) {
                if (p != null && p.cancelled()) throw new Exception("Cancelado");
                int want = (int) Math.min(buf.length, runBytes - done);
                int got = 0;
                if (off < it.size) {
                    int w = (int) Math.min((long) want, it.size - off);
                    while (got < w) {
                        int n = t.readAt(it, off + got, buf, w - got);
                        if (n <= 0) throw new Exception("No pude leer " + it.name + " del teléfono (en " + (off + got) + " de " + it.size + ")");
                        if (n < w - got) {
                            byte[] tmp = new byte[w - got - n];
                            int more = 0;
                            while (more < tmp.length) {
                                int m = t.readAt(it, off + got + n + more, tmp, tmp.length - more);
                                if (m <= 0) throw new Exception("Lectura corta de " + it.name);
                                System.arraycopy(tmp, 0, buf, got + n + more, m);
                                more += m;
                            }
                            n += more;
                        }
                        got += n;
                    }
                }
                for (int k = got; k < want; k++) buf[k] = 0;
                wr(pos + done, buf, 0, want);
                if (p != null && got > 0) p.add(got);
                off += got;
                done += want;
            }
        }
        if (it.size >= 8L * 1024 * 1024) d.flush();
    }

    private void verifyData(Vector runs, FileItem it, DiscTree t, Progress p) throws Exception {
        byte[] exp = new byte[65536];
        long off = 0;
        for (int i = 0; i < runs.size() && off < it.size; i++) {
            long[] r = (long[]) runs.elementAt(i);
            long runBytes = Math.min(r[1] * clusterBytes, it.size - off);
            long pos = clusterOff(r[0]);
            long done = 0;
            while (done < runBytes) {
                if (p != null && p.cancelled()) throw new Exception("Cancelado");
                int want = (int) Math.min(exp.length, runBytes - done);
                byte[] got = rd(pos + done, want);
                int have = 0;
                while (have < want) {
                    int n = t.readAt(it, off + have, exp, want - have);
                    if (n <= 0) throw new Exception("No pude releer " + it.name);
                    for (int k = 0; k < n; k++) {
                        if (got[have + k] != exp[k]) throw new Exception("Verificación fallida en " + it.name + " (byte " + (off + have + k) + ")");
                    }
                    have += n;
                }
                off += want;
                done += want;
            }
        }
    }
}
