package com.usb.informer;

import java.util.Calendar;
import java.util.Hashtable;
import java.util.Vector;

/**
 * Añade archivos y carpetas a un USB FAT12/FAT16/FAT32 que YA tiene datos, sin borrar nada.
 * Los datos se escriben primero y la tabla FAT se vuelca antes de crear la entrada de directorio,
 * así una interrupción deja el USB consistente (como mucho, clusters sin usar).
 */
public class FatAdd extends FsAdd {
    private static final long MAX_FILE = 0xFFFFFFFFL;

    private final OpticalDisc d;
    private final int bs;
    private long base;                 // inicio de la partición en bytes
    private int type;                  // 12, 16 o 32
    private int bps, spc, nfats, rootEntries;
    private long reserved, fatSz, rootCluster, totSec, fsInfoSec;
    private long fatOff, rootOff, dataOff, clusterBytes, nClusters;
    private byte[] fat;
    private long dirtyLo = Long.MAX_VALUE, dirtyHi = -1;
    private long free, hint = 2;
    private int eoc;

    private static class Ent {
        String name, raw;
        boolean dir;
        long first;
        int off, n;
    }

    private static class Dir {
        long first;
        boolean fixed;
        Vector chain = new Vector();
        byte[] data;
        Hashtable names = new Hashtable();
        Hashtable shorts = new Hashtable();
    }

    private FatAdd(OpticalDisc d) {
        this.d = d;
        this.bs = d.blockSize;
    }

    // ------------------------------------------------------------------ abrir

    /** Devuelve el sistema FAT que empieza en el bloque lba, o null si ahí no hay FAT. */
    public static FatAdd tryOpen(OpticalDisc d, long lba) throws Exception {
        FatAdd f = new FatAdd(d);
        byte[] b;
        try {
            b = d.read((int) lba, 1);
        } catch (Throwable t) {
            return null;
        }
        if (!f.parse(lba, b)) return null;
        f.loadFat();
        return f;
    }

    protected long maxFile() { return MAX_FILE; }

    private static int le16(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8); }

    private static long le32(byte[] b, int o) {
        return (b[o] & 0xFFL) | ((b[o + 1] & 0xFFL) << 8) | ((b[o + 2] & 0xFFL) << 16) | ((b[o + 3] & 0xFFL) << 24);
    }

    private boolean parse(long lba, byte[] b) {
        try {
            if ((b[510] & 0xFF) != 0x55 || (b[511] & 0xFF) != 0xAA) return false;
            if (b[3] == 'N' && b[4] == 'T' && b[5] == 'F' && b[6] == 'S') return false;
            if (b[3] == 'E' && b[4] == 'X' && b[5] == 'F' && b[6] == 'A') return false;
            bps = le16(b, 11);
            spc = b[13] & 0xFF;
            if (bps < 512 || bps > 4096 || (bps & (bps - 1)) != 0 || spc == 0 || (spc & (spc - 1)) != 0) return false;
            reserved = le16(b, 14);
            nfats = b[16] & 0xFF;
            rootEntries = le16(b, 17);
            totSec = le16(b, 19) != 0 ? le16(b, 19) : le32(b, 32);
            fatSz = le16(b, 22) != 0 ? le16(b, 22) : le32(b, 36);
            if (reserved == 0 || nfats < 1 || nfats > 2 || fatSz == 0 || totSec == 0) return false;
            long rootSectors = ((long) rootEntries * 32 + bps - 1) / bps;
            long dataSectors = totSec - (reserved + nfats * fatSz + rootSectors);
            if (dataSectors <= 0) return false;
            nClusters = dataSectors / spc;
            if (le16(b, 22) == 0 && rootEntries == 0) {
                type = 32;
                rootCluster = le32(b, 44);
                fsInfoSec = le16(b, 48);
                eoc = 0x0FFFFFFF;
            } else if (nClusters < 4085) {
                type = 12;
                eoc = 0xFFF;
            } else {
                type = 16;
                eoc = 0xFFFF;
            }
            base = lba * bs;
            clusterBytes = (long) spc * bps;
            fatOff = reserved * bps;
            rootOff = (reserved + nfats * fatSz) * bps;
            dataOff = rootOff + rootSectors * bps;
            int lo = type == 32 ? 71 : 43;
            StringBuffer l = new StringBuffer();
            for (int i = 0; i < 11; i++) {
                int c = b[lo + i] & 0xFF;
                l.append((char) (c >= 32 && c < 127 ? c : ' '));
            }
            label = l.toString().trim();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private void loadFat() throws Exception {
        long len = fatSz * bps;
        if (len > 200L * 1024 * 1024) throw new Exception("La tabla FAT de este USB es demasiado grande para cargarla en memoria.");
        fat = rd(fatOff, (int) len);
        free = 0;
        long lim = Math.min(nClusters + 2, type == 32 ? len / 4 : type == 16 ? len / 2 : len * 2 / 3);
        for (long c = 2; c < lim; c++) if (get(c) == 0) free++;
        nClusters = Math.min(nClusters, lim - 2);
    }

    public String typeName() { return "FAT" + type; }

    public long freeBytes() { return free * clusterBytes; }

    public long clusterBytes() { return clusterBytes; }

    // ------------------------------------------------------------------ E/S en bytes

    private byte[] rd(long off, int len) throws Exception {
        long abs = base + off;
        byte[] out = new byte[len];
        int got = 0;
        while (got < len) {
            long a = abs + got;
            long blk = a / bs;
            int skip = (int) (a % bs);
            int n = Math.min(len - got, 128 * bs - skip);
            int count = (skip + n + bs - 1) / bs;
            byte[] b = d.read((int) blk, count);
            System.arraycopy(b, skip, out, got, n);
            got += n;
        }
        return out;
    }

    private void wr(long off, byte[] src, int so, int len) throws Exception {
        long abs = base + off;
        int done = 0;
        while (done < len) {
            long a = abs + done;
            long blk = a / bs;
            int skip = (int) (a % bs);
            int n = Math.min(len - done, 65536 - skip);
            int blocks = (skip + n + bs - 1) / bs;
            int total = blocks * bs;
            byte[] buf;
            if (skip == 0 && n == total) {
                buf = new byte[total];
            } else {
                buf = d.read((int) blk, blocks);   // lectura-modificación-escritura de los bordes
            }
            System.arraycopy(src, so + done, buf, skip, n);
            d.write((int) blk, buf, total);
            done += n;
        }
    }

    // ------------------------------------------------------------------ tabla FAT

    private long get(long c) {
        if (type == 32) return le32(fat, (int) (c * 4)) & 0x0FFFFFFFL;
        if (type == 16) return le16(fat, (int) (c * 2));
        int o = (int) (c + c / 2);
        int v = le16(fat, o);
        return (c & 1) == 0 ? (v & 0xFFF) : (v >> 4);
    }

    private void set(long c, long v) {
        int o, n;
        if (type == 32) {
            o = (int) (c * 4);
            long old = le32(fat, o);
            long nv = (old & 0xF0000000L) | (v & 0x0FFFFFFFL);
            fat[o] = (byte) nv;
            fat[o + 1] = (byte) (nv >> 8);
            fat[o + 2] = (byte) (nv >> 16);
            fat[o + 3] = (byte) (nv >> 24);
            n = 4;
        } else if (type == 16) {
            o = (int) (c * 2);
            fat[o] = (byte) v;
            fat[o + 1] = (byte) (v >> 8);
            n = 2;
        } else {
            o = (int) (c + c / 2);
            int old = le16(fat, o);
            int nv = (c & 1) == 0 ? ((old & 0xF000) | (int) (v & 0xFFF)) : ((old & 0x000F) | (int) ((v & 0xFFF) << 4));
            fat[o] = (byte) nv;
            fat[o + 1] = (byte) (nv >> 8);
            n = 2;
        }
        if (o < dirtyLo) dirtyLo = o;
        if (o + n - 1 > dirtyHi) dirtyHi = o + n - 1;
    }

    private boolean isEoc(long v) {
        return v < 2 || (type == 32 ? v >= 0x0FFFFFF8L : type == 16 ? v >= 0xFFF8L : v >= 0xFF8L);
    }

    private void flushFat() throws Exception {
        if (dirtyHi < dirtyLo) return;
        long lo = dirtyLo / bs * bs;
        long hi = Math.min((long) fat.length, (dirtyHi / bs + 1) * bs);
        for (int k = 0; k < nfats; k++) wr(fatOff + k * fatSz * bps + lo, fat, (int) lo, (int) (hi - lo));
        dirtyLo = Long.MAX_VALUE;
        dirtyHi = -1;
    }

    /** Reserva n clusters (en memoria; no toca el disco). */
    private long[] alloc(long n) throws Exception {
        if (n > free) throw new Exception("No hay espacio libre suficiente en el USB");
        long[] out = new long[(int) n];
        long c = hint < 2 || hint >= nClusters + 2 ? 2 : hint;
        int got = 0;
        long scanned = 0;
        while (got < n && scanned < nClusters) {
            if (get(c) == 0) out[got++] = c;
            c++;
            scanned++;
            if (c >= nClusters + 2) c = 2;
        }
        if (got < n) throw new Exception("No hay espacio libre suficiente en el USB");
        for (int i = 0; i < out.length; i++) set(out[i], i + 1 < out.length ? out[i + 1] : eoc);
        free -= n;
        hint = out[out.length - 1] + 1;
        return out;
    }

    private void release(long[] cl) {
        for (int i = 0; i < cl.length; i++) set(cl[i], 0);
        free += cl.length;
    }

    private long clusterOff(long c) { return dataOff + (c - 2) * clusterBytes; }

    // ------------------------------------------------------------------ directorios

    private Dir loadDir(long first) throws Exception {
        Dir dir = new Dir();
        dir.first = first;
        if (first == 0 && type != 32) {
            dir.fixed = true;
            dir.data = rd(rootOff, rootEntries * 32);
        } else {
            long c = first;
            int guard = 0;
            while (c >= 2 && c < nClusters + 2 && guard++ < nClusters) {
                dir.chain.addElement(new Long(c));
                long nx = get(c);
                if (isEoc(nx)) break;
                c = nx;
            }
            dir.data = new byte[(int) (dir.chain.size() * clusterBytes)];
            int i = 0;
            while (i < dir.chain.size()) {
                int j = i;
                while (j + 1 < dir.chain.size() && ((Long) dir.chain.elementAt(j + 1)).longValue() == ((Long) dir.chain.elementAt(j)).longValue() + 1) j++;
                byte[] part = rd(clusterOff(((Long) dir.chain.elementAt(i)).longValue()), (int) ((j - i + 1) * clusterBytes));
                System.arraycopy(part, 0, dir.data, (int) (i * clusterBytes), part.length);
                i = j + 1;
            }
        }
        indexDir(dir);
        return dir;
    }

    private void indexDir(Dir dir) {
        byte[] b = dir.data;
        String[] parts = new String[32];
        boolean haveLfn = false;
        int lfnStart = -1;
        int[] offs = { 1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30 };
        for (int o = 0; o + 32 <= b.length; o += 32) {
            int f = b[o] & 0xFF;
            if (f == 0) break;
            if (f == 0xE5) {
                haveLfn = false;
                continue;
            }
            int attr = b[o + 11] & 0xFF;
            if (attr == 0x0F) {
                if ((f & 0x40) != 0) {
                    parts = new String[32];
                    haveLfn = true;
                    lfnStart = o;
                }
                int idx = (f & 0x1F) - 1;
                if (idx >= 0 && idx < 32) {
                    StringBuffer sb = new StringBuffer();
                    for (int k = 0; k < offs.length; k++) {
                        int ch = le16(b, o + offs[k]);
                        if (ch == 0 || ch == 0xFFFF) break;
                        sb.append((char) ch);
                    }
                    parts[idx] = sb.toString();
                }
                continue;
            }
            if ((attr & 0x08) != 0) {
                haveLfn = false;
                continue;
            }
            String raw;
            try {
                raw = new String(b, o, 11, "ISO-8859-1");
            } catch (Exception e) {
                raw = "";
            }
            dir.shorts.put(raw, Boolean.TRUE);
            String nm;
            if (haveLfn) {
                StringBuffer sb = new StringBuffer();
                for (int k = 0; k < 32; k++) if (parts[k] != null) sb.append(parts[k]);
                nm = sb.toString();
            } else {
                String base8 = raw.substring(0, 8).trim(), ext = raw.substring(8).trim();
                if ((b[o + 12] & 0x08) != 0) base8 = base8.toLowerCase();
                if ((b[o + 12] & 0x10) != 0) ext = ext.toLowerCase();
                nm = ext.length() > 0 ? base8 + "." + ext : base8;
            }
            boolean lfnOn = haveLfn;
            haveLfn = false;
            if (nm.equals(".") || nm.equals("..")) continue;
            Ent e = new Ent();
            e.name = nm;
            e.dir = (attr & 0x10) != 0;
            e.first = (le16(b, o + 20) << 16) | le16(b, o + 26);
            e.raw = raw;
            e.off = lfnStart >= 0 && lfnOn ? lfnStart : o;
            e.n = (o - e.off) / 32 + 1;
            dir.names.put(nm.toLowerCase(), e);
        }
    }

    /** Borra un archivo existente: marca sus entradas (nombre largo + corta) como libres y libera sus clusters. */
    private void deleteEntry(Dir dir, Ent e) throws Exception {
        for (int k = 0; k < e.n; k++) dir.data[e.off + k * 32] = (byte) 0xE5;
        writeDirBytes(dir, e.off, e.n * 32);
        dir.names.remove(e.name.toLowerCase());
        if (e.raw != null) dir.shorts.remove(e.raw);
        long c = e.first;
        long guard = 0;
        while (c >= 2 && c < nClusters + 2 && guard++ <= nClusters) {
            long nx = get(c);
            set(c, 0);
            free++;
            if (isEoc(nx)) break;
            c = nx;
        }
        if (e.first >= 2 && e.first < hint) hint = e.first;
        flushFat();
    }

    // ------------------------------------------------------------------ nombres

    private static final String BAD83 = "\"*+,./:;<=>?[\\]| ";

    private static String pad(String b, String e) {
        StringBuffer sb = new StringBuffer(b);
        while (sb.length() < 8) sb.append(' ');
        sb.append(e);
        while (sb.length() < 11) sb.append(' ');
        return sb.toString();
    }

    private static String cleanName(String n) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < n.length(); i++) {
            char c = n.charAt(i);
            if (c < 32 || "\\/:*?\"<>|".indexOf(c) >= 0) c = '_';
            sb.append(c);
        }
        String r = sb.toString();
        while (r.length() > 0 && (r.endsWith(" ") || r.endsWith("."))) r = r.substring(0, r.length() - 1);
        if (r.length() > 255) r = r.substring(0, 255);
        return r.length() == 0 ? "_" : r;
    }

    /** Devuelve {nombre corto de 11 caracteres, "1" si hace falta nombre largo, indicadores de minúsculas}. */
    private static String[] makeShort(String n, Hashtable used) {
        int dot = n.lastIndexOf('.');
        String base = dot > 0 ? n.substring(0, dot) : n;
        String ext = dot > 0 ? n.substring(dot + 1) : "";
        boolean lossy = false, hasUp = false, hasLow = false, extUp = false, extLow = false;
        StringBuffer b = new StringBuffer();
        for (int i = 0; i < base.length(); i++) {
            char ch = base.charAt(i);
            if (ch == ' ' || ch == '.') { lossy = true; continue; }
            if (ch > 126 || BAD83.indexOf(ch) >= 0) { ch = '_'; lossy = true; }
            if (Character.isUpperCase(ch)) hasUp = true;
            if (Character.isLowerCase(ch)) hasLow = true;
            b.append(Character.toUpperCase(ch));
        }
        StringBuffer e = new StringBuffer();
        for (int i = 0; i < ext.length(); i++) {
            char ch = ext.charAt(i);
            if (ch == ' ' || ch == '.') { lossy = true; continue; }
            if (ch > 126 || BAD83.indexOf(ch) >= 0) { ch = '_'; lossy = true; }
            if (Character.isUpperCase(ch)) extUp = true;
            if (Character.isLowerCase(ch)) extLow = true;
            e.append(Character.toUpperCase(ch));
        }
        if (b.length() == 0) b.append('_');
        String b8 = b.toString(), e3 = e.toString();
        if (b8.length() > 8) { b8 = b8.substring(0, 8); lossy = true; }
        if (e3.length() > 3) { e3 = e3.substring(0, 3); lossy = true; }
        boolean mixed = (hasUp && hasLow) || (extUp && extLow);
        String key = pad(b8, e3);
        if (!lossy && !mixed && !used.containsKey(key)) {
            return new String[] { key, "0", "" + ((hasLow ? 0x08 : 0) | (extLow ? 0x10 : 0)) };
        }
        for (int t = 1; ; t++) {
            String tail = "~" + t;
            String bb = b8.length() + tail.length() > 8 ? b8.substring(0, 8 - tail.length()) : b8;
            String k = pad(bb + tail, e3);
            if (!used.containsKey(k)) return new String[] { k, "1", "0" };
        }
    }

    private static int checksum(String s11) {
        int sum = 0;
        for (int i = 0; i < 11; i++) sum = (((sum & 1) << 7) + ((sum & 0xFF) >> 1) + (s11.charAt(i) & 0xFF)) & 0xFF;
        return sum;
    }

    private static void put16(byte[] b, int o, int v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
    }

    private static void put32(byte[] b, int o, long v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
        b[o + 2] = (byte) (v >> 16);
        b[o + 3] = (byte) (v >> 24);
    }

    private static int dosDate(Calendar c) {
        return ((c.get(Calendar.YEAR) - 1980) << 9) | ((c.get(Calendar.MONTH) + 1) << 5) | c.get(Calendar.DAY_OF_MONTH);
    }

    private static int dosTime(Calendar c) {
        return (c.get(Calendar.HOUR_OF_DAY) << 11) | (c.get(Calendar.MINUTE) << 5) | (c.get(Calendar.SECOND) / 2);
    }

    private static byte[] shortEntry(String s11, int attr, int caseFlags, long first, long size) {
        Calendar c = Calendar.getInstance();
        byte[] e = new byte[32];
        for (int i = 0; i < 11; i++) e[i] = (byte) s11.charAt(i);
        e[11] = (byte) attr;
        e[12] = (byte) caseFlags;
        put16(e, 14, dosTime(c));
        put16(e, 16, dosDate(c));
        put16(e, 18, dosDate(c));
        put16(e, 20, (int) (first >> 16));
        put16(e, 22, dosTime(c));
        put16(e, 24, dosDate(c));
        put16(e, 26, (int) (first & 0xFFFF));
        put32(e, 28, size);
        return e;
    }

    /** Crea la entrada (con nombre largo si hace falta) en el directorio. */
    private void addEntry(Dir dir, String name, boolean isDir, long first, long size) throws Exception {
        String[] sh = makeShort(name, dir.shorts);
        boolean lfn = sh[1].equals("1");
        int nl = lfn ? (name.length() + 12) / 13 : 0;
        byte[] ent = new byte[(nl + 1) * 32];
        int pos = 0;
        if (lfn) {
            int cs = checksum(sh[0]);
            int[] offs = { 1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30 };
            for (int k = nl; k >= 1; k--) {
                int o = pos * 32;
                ent[o] = (byte) (k | (k == nl ? 0x40 : 0));
                ent[o + 11] = 0x0F;
                ent[o + 13] = (byte) cs;
                for (int j = 0; j < 13; j++) {
                    int idx = (k - 1) * 13 + j;
                    int ch = idx < name.length() ? name.charAt(idx) : (idx == name.length() ? 0 : 0xFFFF);
                    put16(ent, o + offs[j], ch);
                }
                pos++;
            }
        }
        byte[] se = shortEntry(sh[0], isDir ? 0x10 : 0x20, Integer.parseInt(sh[2]), first, size);
        System.arraycopy(se, 0, ent, pos * 32, 32);
        int slots = ent.length / 32;
        int at = findSlots(dir, slots);
        System.arraycopy(ent, 0, dir.data, at * 32, ent.length);
        writeDirBytes(dir, at * 32, ent.length);
        dir.shorts.put(sh[0], Boolean.TRUE);
        Ent e = new Ent();
        e.name = name;
        e.dir = isDir;
        e.first = first;
        dir.names.put(name.toLowerCase(), e);
    }

    private int findSlots(Dir dir, int slots) throws Exception {
        for (;;) {
            int run = 0, startIdx = 0, total = dir.data.length / 32;
            for (int i = 0; i < total; i++) {
                int f = dir.data[i * 32] & 0xFF;
                if (f == 0 || f == 0xE5) {
                    if (run == 0) startIdx = i;
                    run++;
                    if (run == slots) return startIdx;
                } else {
                    run = 0;
                }
            }
            if (dir.fixed) {
                throw new Exception("La carpeta raíz del USB está llena (en FAT12/FAT16 la raíz tiene un número fijo de entradas). "
                        + "Copia dentro de una carpeta.");
            }
            // ampliar el directorio con un cluster más
            long[] nc = alloc(1);
            byte[] z = new byte[(int) clusterBytes];
            wr(clusterOff(nc[0]), z, 0, z.length);
            long last = ((Long) dir.chain.elementAt(dir.chain.size() - 1)).longValue();
            set(last, nc[0]);
            flushFat();
            dir.chain.addElement(new Long(nc[0]));
            byte[] nd = new byte[dir.data.length + (int) clusterBytes];
            System.arraycopy(dir.data, 0, nd, 0, dir.data.length);
            dir.data = nd;
        }
    }

    private void writeDirBytes(Dir dir, int off, int len) throws Exception {
        if (dir.fixed) {
            wr(rootOff + off, dir.data, off, len);
            return;
        }
        int end = off + len;
        int pos = off;
        while (pos < end) {
            int ci = (int) (pos / clusterBytes);
            int inner = (int) (pos % clusterBytes);
            int n = (int) Math.min(end - pos, clusterBytes - inner);
            wr(clusterOff(((Long) dir.chain.elementAt(ci)).longValue()) + inner, dir.data, pos, n);
            pos += n;
        }
    }

    // ------------------------------------------------------------------ copiar

    /** Copia los elementos a la raíz del USB. */
    public void addTree(Vector items, DiscTree t, Progress p, boolean verify) throws Exception {
        Dir root = loadDir(type == 32 ? rootCluster : 0);
        try {
            copyItems(items, t, root, p, verify, "");
        } finally {
            // aunque se cancele o falle, deja la FAT y el contador de espacio libre al día con lo ya copiado
            try {
                flushFat();
                finish();
            } catch (Exception e) {
                // el error original es el importante
            }
        }
    }

    private void copyItems(Vector items, DiscTree t, Dir dir, Progress p, boolean verify, String path) throws Exception {
        for (int i = 0; i < items.size(); i++) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            FileItem it = (FileItem) items.elementAt(i);
            String nm = cleanName(it.name);
            Ent ex = (Ent) dir.names.get(nm.toLowerCase());
            if (it.dir) {
                long first;
                Dir sub;
                if (ex != null && ex.dir) {
                    sub = loadDir(ex.first);
                } else if (ex != null) {
                    skipped.addElement(path + it.name + " (ya existe un archivo con ese nombre)");
                    continue;
                } else {
                    first = makeDir(dir);
                    sub = loadDir(first);
                    addEntry(dir, nm, true, first, 0);
                    dirs++;
                }
                copyItems(t.list(it), t, sub, p, verify, path + it.name + "/");
            } else {
                if (it.size > MAX_FILE) continue;   // ya anotado en el plan
                if (ex != null && ex.dir) {
                    skipped.addElement(path + it.name + " (ya existe una carpeta con ese nombre)");
                    continue;
                }
                if (ex != null) {
                    if (!overwrite) {
                        skipped.addElement(path + it.name + " (ya existe en el USB; no se sobrescribe)");
                        continue;
                    }
                    deleteEntry(dir, ex);
                    replaced++;
                }
                copyFile(dir, nm, it, t, p, verify);
            }
        }
    }

    /** Crea una carpeta nueva (con . y ..) y devuelve su primer cluster. La entrada en el padre la añade quien llama. */
    private long makeDir(Dir parent) throws Exception {
        long[] c = alloc(1);
        try {
            byte[] z = new byte[(int) clusterBytes];
            byte[] dot = shortEntry(".          ", 0x10, 0, c[0], 0);
            byte[] dd = shortEntry("..         ", 0x10, 0, parent.first == 0 || (type == 32 && parent.first == rootCluster) ? 0 : parent.first, 0);
            System.arraycopy(dot, 0, z, 0, 32);
            System.arraycopy(dd, 0, z, 32, 32);
            wr(clusterOff(c[0]), z, 0, z.length);
            flushFat();
        } catch (Exception e) {
            release(c);
            throw e;
        }
        return c[0];
    }

    private void copyFile(Dir dir, String nm, FileItem it, DiscTree t, Progress p, boolean verify) throws Exception {
        if (p != null) p.file(it.name);
        long first = 0;
        if (it.size > 0) {
            long need = (it.size + clusterBytes - 1) / clusterBytes;
            long[] cl = alloc(need);
            try {
                first = cl[0];
                writeData(cl, it, t, p);
                if (verify) verifyData(cl, it, t, p);
                flushFat();
            } catch (Exception e) {
                release(cl);
                throw e;
            }
        }
        addEntry(dir, nm, false, first, it.size);
        files++;
        bytes += it.size;
    }

    private void writeData(long[] cl, FileItem it, DiscTree t, Progress p) throws Exception {
        byte[] buf = new byte[65536];
        long off = 0;
        int i = 0;
        while (i < cl.length) {
            int j = i;
            while (j + 1 < cl.length && cl[j + 1] == cl[j] + 1) j++;
            long runBytes = (j - i + 1) * clusterBytes;
            long pos = clusterOff(cl[i]);
            long done = 0;
            while (done < runBytes) {
                if (p != null && p.cancelled()) throw new Exception("Cancelado");
                int want = (int) Math.min(buf.length, runBytes - done);
                int got = 0;
                if (off < it.size) {
                    int w = (int) Math.min((long) want, it.size - off);
                    while (got < w) {
                        int n = t.readAt(it, off + got, buf, w - got);
                        if (n <= 0) throw new Exception("No pude leer " + it.name + " del teléfono (en " + (off + got) + " de " + it.size + ")");
                        if (n < w - got) {
                            // readAt puede devolver menos; el resto se pide de nuevo en otro buffer
                            byte[] tmp = new byte[w - got - n];
                            int more = 0;
                            while (more < tmp.length) {
                                int m = t.readAt(it, off + got + n + more, tmp, tmp.length - more);
                                if (m <= 0) throw new Exception("Lectura corta de " + it.name);
                                System.arraycopy(tmp, 0, buf, got + n + more, m);
                                more += m;
                            }
                            n += more;
                        }
                        got += n;
                    }
                }
                for (int k = got; k < want; k++) buf[k] = 0;   // relleno del último cluster
                wr(pos + done, buf, 0, want);
                if (p != null && got > 0) p.add(got);
                off += got;
                done += want;
            }
            i = j + 1;
        }
        if (it.size >= 8L * 1024 * 1024) d.flush();   // los archivos pequeños se vuelcan al final
    }

    private void verifyData(long[] cl, FileItem it, DiscTree t, Progress p) throws Exception {
        byte[] exp = new byte[65536];
        long off = 0;
        int i = 0;
        while (i < cl.length && off < it.size) {
            int j = i;
            while (j + 1 < cl.length && cl[j + 1] == cl[j] + 1) j++;
            long runBytes = Math.min((j - i + 1) * clusterBytes, it.size - off);
            long pos = clusterOff(cl[i]);
            long done = 0;
            while (done < runBytes) {
                if (p != null && p.cancelled()) throw new Exception("Cancelado");
                int want = (int) Math.min(exp.length, runBytes - done);
                byte[] got = rd(pos + done, want);
                int have = 0;
                while (have < want) {
                    int n = t.readAt(it, off + have, exp, want - have);
                    if (n <= 0) throw new Exception("No pude releer " + it.name);
                    for (int k = 0; k < n; k++) {
                        if (got[have + k] != exp[k]) throw new Exception("Verificación fallida en " + it.name + " (byte " + (off + have + k) + ")");
                    }
                    have += n;
                }
                off += want;
                done += want;
            }
            i = j + 1;
        }
    }

    private void finish() throws Exception {
        if (type == 32 && fsInfoSec > 0 && fsInfoSec < reserved) {
            byte[] s = rd(fsInfoSec * bps, 512);
            if (le32(s, 0) == 0x41615252L && le32(s, 484) == 0x61417272L) {
                put32(s, 488, free);
                put32(s, 492, hint);
                wr(fsInfoSec * bps, s, 0, 512);
            }
        }
        d.flush();
    }
}
