package com.usb.informer;
/** Tabla de particiones GPT (con MBR de protección y copia de seguridad). */
public class Gpt {
    public static final String TYPE_ESP = "c12a7328-f81f-11d2-ba4b-00a0c93ec93b";
    public static final String TYPE_DATA = "ebd0a0a2-b9e5-4433-87c0-68b6b72699c7";

    private static int[] table;

    public static int crc32(byte[] b, int off, int len) {
        if (table == null) {
            int[] t = new int[256];
            for (int n = 0; n < 256; n++) {
                int c = n;
                for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
                t[n] = c;
            }
            table = t;
        }
        int c = 0xFFFFFFFF;
        for (int i = 0; i < len; i++) c = table[(c ^ b[off + i]) & 0xFF] ^ (c >>> 8);
        return ~c;
    }

    /** "bda60898-76ec-434a-9f12-73a00d8584aa" -> 16 bytes en el orden de disco de GPT. */
    public static byte[] guid(String s) {
        String h = "";
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) != '-') h += s.charAt(i);
        byte[] r = new byte[16];
        byte[] raw = new byte[16];
        for (int i = 0; i < 16; i++) raw[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16);
        r[0] = raw[3]; r[1] = raw[2]; r[2] = raw[1]; r[3] = raw[0];
        r[4] = raw[5]; r[5] = raw[4];
        r[6] = raw[7]; r[7] = raw[6];
        for (int i = 8; i < 16; i++) r[i] = raw[i];
        return r;
    }

    private static void p32(byte[] b, int o, long v) {
        b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24);
    }

    private static void p64(byte[] b, int o, long v) {
        p32(b, o, v & 0xFFFFFFFFL);
        p32(b, o + 4, v >>> 32);
    }

    public static long entryBlocks(int bs) {
        return Math.max(1, 16384 / bs);
    }

    /** Primer y último bloque utilizables del disco. */
    public static long firstUsable(int bs) { return 2 + entryBlocks(bs); }

    public static long lastUsable(long total, int bs) { return total - 2 - entryBlocks(bs); }

    /** Escribe MBR de protección + GPT primaria y secundaria. Las particiones se dan como [inicio, fin] en bloques. */
    public static void write(OpticalDisc dev, byte[] diskGuid, long[][] range, String[] types, byte[][] unique, String[] names)
            throws Exception {
        int bs = dev.blockSize;
        long total = dev.blocks;
        long eb = entryBlocks(bs);
        byte[] ents = new byte[(int) (eb * bs)];
        for (int i = 0; i < range.length; i++) {
            int o = i * 128;
            System.arraycopy(guid(types[i]), 0, ents, o, 16);
            System.arraycopy(unique[i], 0, ents, o + 16, 16);
            p64(ents, o + 32, range[i][0]);
            p64(ents, o + 40, range[i][1]);
            String nm = names[i];
            for (int k = 0; k < nm.length() && k < 36; k++) {
                ents[o + 56 + 2 * k] = (byte) nm.charAt(k);
                ents[o + 57 + 2 * k] = (byte) (nm.charAt(k) >> 8);
            }
        }
        int entCrc = crc32(ents, 0, 128 * 128);
        byte[] mbr = new byte[bs];
        mbr[446 + 4] = (byte) 0xEE;
        mbr[446 + 1] = 0; mbr[446 + 2] = 2; mbr[446 + 3] = 0;
        mbr[446 + 5] = (byte) 0xFF; mbr[446 + 6] = (byte) 0xFF; mbr[446 + 7] = (byte) 0xFF;
        p32(mbr, 446 + 8, 1);
        p32(mbr, 446 + 12, Math.min(total - 1, 0xFFFFFFFFL));
        mbr[510] = 0x55;
        mbr[511] = (byte) 0xAA;
        byte[] h1 = header(bs, 1, total - 1, total - 1 - eb, 2, diskGuid, total, entCrc);
        byte[] h2 = header(bs, total - 1, 1, total - 1 - eb, total - 1 - eb, diskGuid, total, entCrc);
        w(dev, 0, mbr);
        w(dev, 1, h1);
        w(dev, 2, ents);
        w(dev, total - 1 - eb, ents);
        w(dev, total - 1, h2);
        dev.flush();
    }

    private static byte[] header(int bs, long cur, long other, long backupEnts, long entStart, byte[] disk, long total, int entCrc) {
        byte[] h = new byte[bs];
        byte[] sig = { 'E', 'F', 'I', ' ', 'P', 'A', 'R', 'T' };
        System.arraycopy(sig, 0, h, 0, 8);
        p32(h, 8, 0x00010000L);
        p32(h, 12, 92);
        p64(h, 24, cur);
        p64(h, 32, other);
        p64(h, 40, firstUsable(bs));
        p64(h, 48, lastUsable(total, bs));
        System.arraycopy(disk, 0, h, 56, 16);
        p64(h, 72, entStart);
        p32(h, 80, 128);
        p32(h, 84, 128);
        p32(h, 88, entCrc & 0xFFFFFFFFL);
        p32(h, 16, 0);
        p32(h, 16, crc32(h, 0, 92) & 0xFFFFFFFFL);
        return h;
    }

    private static void w(OpticalDisc dev, long lba, byte[] data) throws Exception {
        int pos = 0;
        while (pos < data.length) {
            int n = Math.min(OpticalDisc.WRITE_CHUNK, data.length - pos);
            byte[] part = new byte[n];
            System.arraycopy(data, pos, part, 0, n);
            dev.write((int) (lba + pos / dev.blockSize), part, n);
            pos += n;
        }
    }
}
