package com.usb.informer;
import java.util.Vector;

/** FAT12 / FAT16 / FAT32 de solo lectura, con nombres largos. */
public class FatFs extends BlockFs {
    private int bps, spc, fatType, rootEntries;
    private long fatStart, rootStart, dataStart, rootCluster, clusterBytes;

    public FatFs(OpticalDisc disc, long startLba, byte[] b) throws Exception {
        d = disc;
        baseBytes = startLba * disc.blockSize;
        bps = le16(b, 11);
        spc = b[13] & 0xFF;
        int reserved = le16(b, 14);
        int nfats = b[16] & 0xFF;
        rootEntries = le16(b, 17);
        long tot = le16(b, 19) != 0 ? le16(b, 19) : le32(b, 32);
        long fatSz = le16(b, 22) != 0 ? le16(b, 22) : le32(b, 36);
        if (reserved == 0 || nfats < 1 || nfats > 2 || fatSz == 0 || tot == 0) throw new Exception("no es FAT");
        long rootSectors = ((long) rootEntries * 32 + bps - 1) / bps;
        fatStart = (long) reserved * bps;
        rootStart = (reserved + nfats * fatSz) * bps;
        dataStart = (reserved + nfats * fatSz + rootSectors) * bps;
        clusterBytes = (long) spc * bps;
        long clusters = (tot - (reserved + nfats * fatSz + rootSectors)) / spc;
        if (le16(b, 22) == 0 && rootEntries == 0) {
            fatType = 32;
            rootCluster = le32(b, 44);
        } else {
            fatType = clusters < 4085 ? 12 : 16;
        }
        int lo = fatType == 32 ? 71 : 43;
        String l = "";
        for (int i = 0; i < 11; i++) {
            int c = b[lo + i] & 0xFF;
            l += (char) (c >= 32 && c < 127 ? c : ' ');
        }
        l = l.trim();
        if (l.length() > 0 && !l.equals("NO NAME")) vol = l;
    }

    public String typeName() { return "FAT" + fatType; }

    private long next(long c) throws Exception {
        if (fatType == 32) return le32(readBytes(fatStart + c * 4, 4), 0) & 0x0FFFFFFFL;
        if (fatType == 16) return le16(readBytes(fatStart + c * 2, 2), 0);
        int v = le16(readBytes(fatStart + c + c / 2, 2), 0);
        return (c & 1) == 0 ? (v & 0xFFF) : (v >> 4);
    }

    private boolean eoc(long v) {
        if (v < 2) return true;
        return fatType == 32 ? v >= 0x0FFFFFF8L : (fatType == 16 ? v >= 0xFFF8L : v >= 0xFF8L);
    }

    /** Tramos contiguos de la cadena de clusters; maxClusters limita la longitud. */
    private Vector runs(long first, long maxClusters) throws Exception {
        Vector out = new Vector();
        if (first < 2) return out;
        long c = first, start = first, len = 1, count = 1;
        while (count < maxClusters) {
            long n = next(c);
            if (eoc(n)) break;
            if (n == c + 1) {
                len++;
            } else {
                out.addElement(new long[] { dataStart + (start - 2) * clusterBytes, len * clusterBytes });
                start = n;
                len = 1;
            }
            c = n;
            count++;
        }
        out.addElement(new long[] { dataStart + (start - 2) * clusterBytes, len * clusterBytes });
        return out;
    }

    protected Vector extents(FileItem f) throws Exception {
        long[] r = (long[]) f.ref;
        return runs(r[0], (r[1] + clusterBytes - 1) / clusterBytes);
    }

    public Vector listRoot() throws Exception {
        if (fatType == 32) return listCluster(rootCluster);
        return parse(readBytes(rootStart, rootEntries * 32));
    }

    public Vector list(FileItem dir) throws Exception {
        return listCluster(((long[]) dir.ref)[0]);
    }

    private Vector listCluster(long first) throws Exception {
        Vector rs = runs(first, 65536);
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        for (int i = 0; i < rs.size() && bo.size() < 4 * 1024 * 1024; i++) {
            long[] r = (long[]) rs.elementAt(i);
            long pos = 0;
            while (pos < r[1]) {
                int n = (int) Math.min(65536, r[1] - pos);
                bo.write(readRaw(r[0] + pos, n));
                pos += n;
            }
        }
        return parse(bo.toByteArray());
    }

    private Vector parse(byte[] b) {
        Vector dirs = new Vector();
        Vector files = new Vector();
        String[] parts = new String[32];
        boolean haveLfn = false;
        for (int o = 0; o + 32 <= b.length; o += 32) {
            int first = b[o] & 0xFF;
            if (first == 0) break;
            if (first == 0xE5) {
                haveLfn = false;
                continue;
            }
            int attr = b[o + 11] & 0xFF;
            if (attr == 0x0F) {
                int ord = first;
                if ((ord & 0x40) != 0) {
                    parts = new String[32];
                    haveLfn = true;
                }
                int idx = (ord & 0x1F) - 1;
                if (idx >= 0 && idx < 32) {
                    StringBuffer sb = new StringBuffer();
                    int[] offs = { 1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30 };
                    for (int k = 0; k < offs.length; k++) {
                        int ch = le16(b, o + offs[k]);
                        if (ch == 0 || ch == 0xFFFF) break;
                        sb.append((char) ch);
                    }
                    parts[idx] = sb.toString();
                }
                continue;
            }
            if ((attr & 0x08) != 0) {
                haveLfn = false;
                continue;
            }
            String name;
            if (haveLfn) {
                StringBuffer sb = new StringBuffer();
                for (int k = 0; k < 32 && parts[k] != null; k++) sb.append(parts[k]);
                name = sb.toString();
            } else {
                StringBuffer n8 = new StringBuffer();
                StringBuffer e3 = new StringBuffer();
                boolean lowName = (b[o + 12] & 0x08) != 0, lowExt = (b[o + 12] & 0x10) != 0;
                for (int k = 0; k < 8; k++) {
                    int c = b[o + k] & 0xFF;
                    if (k == 0 && c == 0x05) c = 0xE5;
                    if (c != ' ') n8.append(lowName ? Character.toLowerCase((char) c) : (char) c);
                }
                for (int k = 8; k < 11; k++) {
                    int c = b[o + k] & 0xFF;
                    if (c != ' ') e3.append(lowExt ? Character.toLowerCase((char) c) : (char) c);
                }
                name = e3.length() > 0 ? n8 + "." + e3 : n8.toString();
            }
            haveLfn = false;
            if (name.equals(".") || name.equals("..") || name.length() == 0) continue;
            FileItem it = new FileItem();
            it.name = name;
            it.dir = (attr & 0x10) != 0;
            long cluster = ((long) le16(b, o + 20) << 16) | le16(b, o + 26);
            it.size = it.dir ? 0 : le32(b, o + 28);
            it.ref = new long[] { cluster, it.size };
            FileItem.sortedAdd(it.dir ? dirs : files, it);
        }
        for (int i = 0; i < files.size(); i++) dirs.addElement(files.elementAt(i));
        return dirs;
    }
}
