package com.usb.informer;
public class UsbUtil {

    public static String hex(int v, int digits) {
        String s = Integer.toHexString(v).toUpperCase();
        if (s.length() > digits) s = s.substring(s.length() - digits);
        while (s.length() < digits) s = "0" + s;
        return "0x" + s;
    }

    public static String pad(int v, int digits) {
        String s = String.valueOf(v);
        while (s.length() < digits) s = "0" + s;
        return s;
    }

    public static String nz(String s) {
        return (s == null || s.length() == 0) ? "(n/d)" : s;
    }

    /** bcdDevice (por ejemplo 0x0110) a texto "1.10". */
    public static String bcdVersion(int bcd) {
        String mj = Integer.toHexString((bcd >> 8) & 0xFF);
        String mn = Integer.toHexString(bcd & 0xFF);
        if (mn.length() < 2) mn = "0" + mn;
        return mj + "." + mn;
    }

    public static String className(int c) {
        switch (c & 0xFF) {
            case 0x00: return "definida en la interfaz";
            case 0x01: return "Audio";
            case 0x02: return "Comunicaciones (CDC)";
            case 0x03: return "HID";
            case 0x05: return "Physical";
            case 0x06: return "Imagen";
            case 0x07: return "Impresora";
            case 0x08: return "Almacenamiento masivo";
            case 0x09: return "Hub";
            case 0x0A: return "CDC-Data";
            case 0x0B: return "Smart card";
            case 0x0E: return "Vídeo";
            case 0xE0: return "Inalámbrico";
            case 0xEF: return "Miscelánea";
            case 0xFE: return "Específica de aplicación";
            case 0xFF: return "Específica del fabricante";
            default: return "desconocida";
        }
    }

    public static String endpointType(int attrs) {
        switch (attrs & 3) {
            case 0: return "Control";
            case 1: return "Isócrono";
            case 2: return "Bulk";
            default: return "Interrupción";
        }
    }

    public static String endpointDir(int addr) {
        return ((addr & 0x80) != 0) ? "IN" : "OUT";
    }

    public static UsbNode configNode(int value, int numInterfaces, int attrs, int maxPowerUnits) {
        String power = ((attrs & 0x40) != 0) ? "autoalimentado" : "alimentado por el bus";
        if ((attrs & 0x20) != 0) power = power + ", wakeup remoto";
        String d = "bConfigurationValue: " + value + "\n"
                + "bNumInterfaces: " + numInterfaces + "\n"
                + "bmAttributes: " + hex(attrs, 2) + " (" + power + ")\n"
                + "bMaxPower: " + (maxPowerUnits * 2) + " mA";
        return new UsbNode("Configuración " + value, d);
    }

    public static UsbNode interfaceNode(int num, int alt, int cls, int sub, int proto, int numEndpoints) {
        String t = "Interfaz " + num + (alt > 0 ? " (alt " + alt + ")" : "") + " - " + className(cls);
        String d = "bInterfaceNumber: " + num + "\n"
                + "bAlternateSetting: " + alt + "\n"
                + "bNumEndpoints: " + numEndpoints + "\n"
                + "bInterfaceClass: " + hex(cls, 2) + " (" + className(cls) + ")\n"
                + "bInterfaceSubClass: " + hex(sub, 2) + "\n"
                + "bInterfaceProtocol: " + hex(proto, 2);
        return new UsbNode(t, d);
    }

    public static UsbNode endpointNode(int addr, int attrs, int maxPacket, int interval) {
        String t = "EP " + hex(addr, 2) + " " + endpointDir(addr) + " " + endpointType(attrs);
        String d = "bEndpointAddress: " + hex(addr, 2) + "\n"
                + "Dirección: " + endpointDir(addr) + "\n"
                + "Tipo: " + endpointType(attrs) + "\n"
                + "wMaxPacketSize: " + maxPacket + " bytes\n"
                + "bInterval: " + interval;
        return new UsbNode(t, d);
    }
}
