package com.usb.informer;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Convierte una ImageSource (que empuja datos) en un InputStream (del que se tira), usando un hilo. */
public class Pipe {
    private final byte[] ring = new byte[1 << 20];
    private int head, count;
    private boolean closedW, closedR;
    private Throwable error;

    public static InputStream open(final ImageSource s, final Progress p) {
        final Pipe pi = new Pipe();
        Thread t = new Thread(new Runnable() {
            public void run() {
                try {
                    s.pump(pi.out, p);
                    pi.out.close();
                } catch (Throwable e) {
                    pi.fail(e);
                }
            }
        });
        t.setDaemon(true);
        t.start();
        return pi.in;
    }

    private synchronized void fail(Throwable e) {
        if (!closedR) error = e;
        closedW = true;
        notifyAll();
    }

    private final OutputStream out = new OutputStream() {
        public void write(int b) throws IOException {
            write(new byte[] { (byte) b }, 0, 1);
        }

        public void write(byte[] b, int off, int len) throws IOException {
            synchronized (Pipe.this) {
                while (len > 0) {
                    while (count == ring.length && !closedR) {
                        try { Pipe.this.wait(); } catch (InterruptedException e) { throw new IOException("interrumpido"); }
                    }
                    if (closedR) throw new IOException("Cancelado");
                    int tail = (head + count) % ring.length;
                    int n = Math.min(len, Math.min(ring.length - count, ring.length - tail));
                    System.arraycopy(b, off, ring, tail, n);
                    count += n;
                    off += n;
                    len -= n;
                    Pipe.this.notifyAll();
                }
            }
        }

        public void close() {
            synchronized (Pipe.this) {
                closedW = true;
                Pipe.this.notifyAll();
            }
        }
    };

    private final InputStream in = new InputStream() {
        public int read() throws IOException {
            byte[] one = new byte[1];
            int n = read(one, 0, 1);
            return n < 0 ? -1 : one[0] & 0xFF;
        }

        public int read(byte[] b, int off, int len) throws IOException {
            if (len == 0) return 0;
            synchronized (Pipe.this) {
                while (count == 0) {
                    if (error != null) {
                        Throwable e = error;
                        throw new IOException(e.getMessage() != null ? e.getMessage() : e.toString());
                    }
                    if (closedW) return -1;
                    try { Pipe.this.wait(); } catch (InterruptedException e) { throw new IOException("interrumpido"); }
                }
                int n = Math.min(len, Math.min(count, ring.length - head));
                System.arraycopy(ring, head, b, off, n);
                head = (head + n) % ring.length;
                count -= n;
                Pipe.this.notifyAll();
                return n;
            }
        }

        public void close() {
            synchronized (Pipe.this) {
                closedR = true;
                Pipe.this.notifyAll();
            }
        }
    };
}
