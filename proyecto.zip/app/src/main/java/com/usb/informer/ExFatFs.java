package com.usb.informer;
import java.util.Vector;

/** exFAT de solo lectura. */
public class ExFatFs extends BlockFs {
    private int bpsShift;
    private long fatOff, heapOff, rootCluster, clusterBytes;

    public ExFatFs(OpticalDisc disc, long startLba, byte[] b) throws Exception {
        d = disc;
        baseBytes = startLba * disc.blockSize;
        bpsShift = b[108] & 0xFF;
        int spcShift = b[109] & 0xFF;
        if (bpsShift < 9 || bpsShift > 12 || spcShift > 25) throw new Exception("no es exFAT");
        fatOff = le32(b, 80);
        heapOff = le32(b, 88);
        rootCluster = le32(b, 96);
        clusterBytes = 1L << (bpsShift + spcShift);
        spcShiftValue = spcShift;
    }

    private int spcShiftValue;

    public String typeName() { return "exFAT"; }

    private long clusterOff(long c) {
        return (heapOff + ((c - 2) << spcShiftValue)) << bpsShift;
    }

    private long next(long c) throws Exception {
        return le32(readBytes((fatOff << bpsShift) + c * 4, 4), 0);
    }

    /** Tramos del archivo; si noChain, los clusters son contiguos. */
    private Vector runs(long first, long size, boolean noChain) throws Exception {
        Vector out = new Vector();
        if (first < 2) return out;
        long need = size > 0 ? (size + clusterBytes - 1) / clusterBytes : 65536;
        if (noChain) {
            out.addElement(new long[] { clusterOff(first), need * clusterBytes });
            return out;
        }
        long c = first, start = first, len = 1, count = 1;
        while (count < need) {
            long n = next(c);
            if (n < 2 || n >= 0xFFFFFFF7L) break;
            if (n == c + 1) {
                len++;
            } else {
                out.addElement(new long[] { clusterOff(start), len * clusterBytes });
                start = n;
                len = 1;
            }
            c = n;
            count++;
        }
        out.addElement(new long[] { clusterOff(start), len * clusterBytes });
        return out;
    }

    protected Vector extents(FileItem f) throws Exception {
        long[] r = (long[]) f.ref;
        return runs(r[0], r[1], r[2] != 0);
    }

    public Vector listRoot() throws Exception {
        return listDir(rootCluster, 0, false);
    }

    public Vector list(FileItem dir) throws Exception {
        long[] r = (long[]) dir.ref;
        return listDir(r[0], r[1], r[2] != 0);
    }

    private Vector listDir(long first, long size, boolean noChain) throws Exception {
        Vector rs = runs(first, size, noChain);
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        for (int i = 0; i < rs.size() && bo.size() < 4 * 1024 * 1024; i++) {
            long[] r = (long[]) rs.elementAt(i);
            long pos = 0;
            while (pos < r[1]) {
                int n = (int) Math.min(65536, r[1] - pos);
                bo.write(readRaw(r[0] + pos, n));
                pos += n;
            }
        }
        byte[] b = bo.toByteArray();
        Vector dirs = new Vector();
        Vector files = new Vector();
        for (int o = 0; o + 32 <= b.length; ) {
            int type = b[o] & 0xFF;
            if (type == 0) break;
            if (type == 0x83 && first == rootCluster) {
                int n = b[o + 1] & 0xFF;
                StringBuffer sb = new StringBuffer();
                for (int k = 0; k < n && k < 11; k++) sb.append((char) le16(b, o + 2 + 2 * k));
                if (sb.length() > 0) vol = sb.toString();
            }
            if (type != 0x85) {
                o += 32;
                continue;
            }
            int sec = b[o + 1] & 0xFF;
            int attr = le16(b, o + 4);
            if (o + 32 * (sec + 1) > b.length || sec < 2) {
                o += 32;
                continue;
            }
            int so = o + 32;
            if ((b[so] & 0xFF) != 0xC0) {
                o += 32 * (sec + 1);
                continue;
            }
            boolean nc = (b[so + 1] & 2) != 0;
            int nameLen = b[so + 3] & 0xFF;
            long valid = le64(b, so + 8);
            long cluster = le32(b, so + 20);
            long dataLen = le64(b, so + 24);
            StringBuffer name = new StringBuffer();
            for (int k = 2; k <= sec && name.length() < nameLen; k++) {
                int no = o + 32 * k;
                if ((b[no] & 0xFF) != 0xC1) break;
                for (int j = 0; j < 15 && name.length() < nameLen; j++) name.append((char) le16(b, no + 2 + 2 * j));
            }
            FileItem it = new FileItem();
            it.name = name.toString();
            it.dir = (attr & 0x10) != 0;
            it.size = it.dir ? 0 : Math.min(valid, dataLen);
            it.ref = new long[] { cluster, it.dir ? dataLen : it.size, nc ? 1 : 0 };
            if (it.name.length() > 0) FileItem.sortedAdd(it.dir ? dirs : files, it);
            o += 32 * (sec + 1);
        }
        for (int i = 0; i < files.size(); i++) dirs.addElement(files.elementAt(i));
        return dirs;
    }
}
