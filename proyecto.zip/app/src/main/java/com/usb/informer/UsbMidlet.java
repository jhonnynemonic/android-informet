package com.usb.informer;
import java.util.Vector;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.StringItem;
import javax.microedition.midlet.MIDlet;

/**
 * USB Informer para J2ME. Orden de preferencia: USB real de Android (J2ME Loader),
 * JSR-80 (javax.usb) y, si no hay nada, modo simulado. Incluye explorador del árbol USB
 * y acceso al contenido mediante el explorador de archivos del sistema.
 */
public class UsbMidlet extends MIDlet implements CommandListener, UsbListener {

    private static final String WAITING = "Esperando dispositivo USB...";

    private Display display;
    private Form main;
    private StringItem modeItem;
    private StringItem infoItem;
    private Form detailForm;
    private List explorer;
    private List storageList;
    private List deviceList;
    private List ejectList;
    private Vector ejectDevs = new Vector();
    private Command ejectCmd;
    private Command refreshCmd;
    private List deviceMenu;
    private Vector listedDevices = new Vector();
    private Vector contentItems = new Vector();
    private UsbDevInfo menuDevice;
    private ImageUi images;
    private BackupUi backup;
    private FtpUi ftpUi;
    private PhoneUsbUi phoneUsb;
    private EjectUi ejector;
    private UsbDevInfo selected;
    private MediaUi media;

    private Command filePermCmd, exitCmd, exploreCmd, filesCmd, ftpCmd, deviceCmd, permCmd, plugCmd, unplugCmd, modeCmd, aboutCmd, backCmd, detailCmd;

    private SimUsb sim;
    private Vector candidates = new Vector();
    private int currentIdx;
    private UsbBackend backend;
    private StringBuffer notes = new StringBuffer();

    private UsbNode current;
    private Vector path = new Vector();

    public void startApp() {
        if (display != null) return;
        display = Display.getDisplay(this);
        sim = new SimUsb();
        detectBackends();
        media = new MediaUi(display);
        images = new ImageUi(display);
        images.setMedia(media);
        backup = new BackupUi(display);
        ftpUi = new FtpUi(display);
        phoneUsb = new PhoneUsbUi(display);
        media.setToUsb(phoneUsb);
        ejector = new EjectUi(display);

        exitCmd = new Command("Salir", Command.EXIT, 1);
        filePermCmd = new Command("Permisos de archivos", Command.SCREEN, 4);
        exploreCmd = new Command("Explorar USB", Command.SCREEN, 1);
        filesCmd = new Command("Ver contenido (archivos)", Command.SCREEN, 2);
        ftpCmd = new Command("Servidor FTP (teléfono / USB)", Command.SCREEN, 3);
        deviceCmd = new Command("Elegir dispositivo", Command.SCREEN, 3);
        permCmd = new Command("Pedir permiso USB", Command.SCREEN, 4);
        plugCmd = new Command("Simular conexión", Command.SCREEN, 5);
        unplugCmd = new Command("Simular desconexión", Command.SCREEN, 6);
        modeCmd = new Command("Cambiar modo", Command.SCREEN, 7);
        aboutCmd = new Command("Estado / Ayuda", Command.HELP, 8);
        backCmd = new Command("Atrás", Command.BACK, 1);
        detailCmd = new Command("Detalle", Command.SCREEN, 2);
        ejectCmd = new Command("Expulsar con seguridad", Command.SCREEN, 3);
        refreshCmd = new Command("Actualizar", Command.SCREEN, 2);

        main = new Form("USB Informer");
        media.setHome(main);
        modeItem = new StringItem(null, "");
        infoItem = new StringItem(null, WAITING);
        main.append(modeItem);
        main.append(infoItem);
        main.addCommand(exploreCmd);
        main.addCommand(deviceCmd);
        main.addCommand(aboutCmd);
        main.addCommand(exitCmd);
        main.setCommandListener(this);

        selectBackend(0);
        display.setCurrent(main);
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
        media.close();
        ftpUi.stopServer();
        if (backend != null) backend.stop();
    }

    // ---------- selección de backend ----------

    private void detectBackends() {
        try {
            candidates.addElement((UsbBackend) Class.forName("com.usb.informer.AndroidUsb").newInstance());
        } catch (Throwable t) {
            notes.append("Android USB: no disponible aquí\n");
        }
        try {
            candidates.addElement((UsbBackend) Class.forName("com.usb.informer.PcUsb").newInstance());
        } catch (Throwable t) {
            notes.append("PC: no disponible aquí\n");
        }
        try {
            Class.forName("javax.usb.UsbHostManager");
            candidates.addElement((UsbBackend) Class.forName("com.usb.informer.Jsr80Backend").newInstance());
        } catch (Throwable t) {
            notes.append("JSR-80: este dispositivo no incluye javax.usb\n");
        }
        candidates.addElement(sim);
    }

    private void selectBackend(int idx) {
        if (backend != null) backend.stop();
        if (idx >= candidates.size()) idx = 0;
        while (true) {
            UsbBackend b = (UsbBackend) candidates.elementAt(idx);
            String err = b.start(this);
            if (err == null) {
                backend = b;
                currentIdx = idx;
                break;
            }
            notes.append(b.getName() + ": " + err + "\n");
            candidates.removeElementAt(idx);
            if (idx >= candidates.size()) idx = 0;
        }

        main.removeCommand(plugCmd);
        main.removeCommand(unplugCmd);
        main.removeCommand(modeCmd);
        main.removeCommand(permCmd);
        main.removeCommand(filePermCmd);
        media.setBackend(backend instanceof UsbExtras ? (UsbExtras) backend : null);
        images.setBackend(backend instanceof UsbExtras ? (UsbExtras) backend : null);
        backup.setBackend(backend instanceof UsbExtras ? (UsbExtras) backend : null);
        ftpUi.setBackend(backend instanceof UsbExtras ? (UsbExtras) backend : null);
        phoneUsb.setBackend(backend, backend instanceof UsbExtras ? (UsbExtras) backend : null);
        ejector.setBackend(backend instanceof UsbExtras ? (UsbExtras) backend : null);
        main.removeCommand(filesCmd);
        main.removeCommand(ftpCmd);
        main.removeCommand(ejectCmd);
        if (backend == sim) {
            main.addCommand(plugCmd);
            main.addCommand(unplugCmd);
        }
        if (backend instanceof UsbExtras) {
            main.addCommand(permCmd);
            main.addCommand(filesCmd);
            main.addCommand(filePermCmd);
            main.addCommand(ftpCmd);
        }
        if (backend instanceof AndroidUsb) main.addCommand(ejectCmd);
        if (candidates.size() > 1) main.addCommand(modeCmd);

        modeItem.setText("Modo: " + backend.getName());
        selected = null;
        refreshMain(null);
    }

    /** Muestra en la pantalla principal el dispositivo elegido (o el último detectado). */
    private void refreshMain(String prefix) {
        Vector devs = backend.getDevices();
        String head = (prefix == null) ? "" : prefix + "\n\n";
        if (devs.size() == 0) {
            selected = null;
            if (prefix != null) {
                infoItem.setText(prefix);
            } else if (backend == sim) {
                infoItem.setText(WAITING + "\n(usa Simular conexión)");
            } else {
                infoItem.setText(WAITING + "\n(conecta un USB al teléfono por OTG)");
            }
            return;
        }
        UsbDevInfo shown = null;
        if (selected != null) {
            for (int i = 0; i < devs.size(); i++) {
                UsbDevInfo d = (UsbDevInfo) devs.elementAt(i);
                if (d.deviceName.equals(selected.deviceName)) shown = d;
            }
        }
        if (shown == null) shown = (UsbDevInfo) devs.elementAt(devs.size() - 1);
        selected = shown;
        if (devs.size() > 1) {
            head = head + "Dispositivos conectados: " + devs.size() + " (usa Elegir dispositivo)\n\n";
        }
        infoItem.setText(head + shown.toText());
    }

    // ---------- eventos USB ----------

    public void deviceAttached(final UsbDevInfo d) {
        display.callSerially(new Runnable() {
            public void run() {
                selected = d;
                refreshMain(null);
                AlertType.INFO.playSound(display);
            }
        });
    }

    public void deviceDetached(final UsbDevInfo d) {
        display.callSerially(new Runnable() {
            public void run() {
                if (selected != null && selected.deviceName.equals(d.deviceName)) selected = null;
                int left = backend.getDevices().size();
                if (ejectList != null && display.getCurrent() == ejectList) showEjectList();
                refreshMain(left == 0 ? "Dispositivo USB desconectado"
                        : "Dispositivo USB desconectado (quedan " + left + ")");
                AlertType.INFO.playSound(display);
            }
        });
    }

    // ---------- comandos ----------

    public void commandAction(Command c, Displayable d) {
        if (d == main) {
            if (c == exitCmd) {
                destroyApp(true);
                notifyDestroyed();
            } else if (c == exploreCmd) {
                openExplorer();
            } else if (c == ftpCmd) {
                ftpUi.start(null, main);
            } else if (c == filesCmd) {
                showStorage();
            } else if (c == deviceCmd) {
                showDevices();
            } else if (c == ejectCmd) {
                showEjectList();
            } else if (c == filePermCmd) {
                String e = ((UsbExtras) backend).openAllFilesAccess();
                alert("Permisos de archivos", e != null ? e
                        : "Se abrió la pantalla de ajustes de Android. Activa \"Permitir acceso a todos los archivos\" "
                        + "para USB Informer y vuelve a esta aplicación.");
            } else if (c == permCmd) {
                alert("Permiso USB", ((UsbExtras) backend).requestPermissions());
            } else if (c == plugCmd) {
                sim.attachNext();
            } else if (c == unplugCmd) {
                if (sim.detachLast() == null) refreshMain("No hay dispositivos simulados conectados");
            } else if (c == modeCmd) {
                selectBackend((currentIdx + 1) % candidates.size());
            } else if (c == aboutCmd) {
                showAbout();
            }
        } else if (d == explorer) {
            if (c == List.SELECT_COMMAND) {
                openChild(explorer.getSelectedIndex());
            } else if (c == detailCmd) {
                int i = explorer.getSelectedIndex();
                if (i < current.children.size()) showDetail((UsbNode) current.children.elementAt(i));
                else showDetail(current);
            } else if (c == backCmd) {
                goUp();
            }
        } else if (d == storageList) {
            if (c == List.SELECT_COMMAND) {
                openContentItem(storageList.getSelectedIndex());
            } else if (c == backCmd) {
                display.setCurrent(main);
            }
        } else if (d == ejectList) {
            if (c == List.SELECT_COMMAND) {
                int i = ejectList.getSelectedIndex();
                Runnable again = new Runnable() {
                    public void run() {
                        showEjectList();
                    }
                };
                if (i < ejectDevs.size()) ejector.start((UsbDevInfo) ejectDevs.elementAt(i), ejectList, again);
                else if (ejectDevs.size() > 1 && i == ejectDevs.size()) ejector.startAll(ejectDevs, ejectList, again);
            } else if (c == refreshCmd) {
                showEjectList();
            } else if (c == backCmd) {
                display.setCurrent(main);
            }
        } else if (d == deviceList) {
            if (c == List.SELECT_COMMAND) {
                int i = deviceList.getSelectedIndex();
                if (i < listedDevices.size()) {
                    selected = (UsbDevInfo) listedDevices.elementAt(i);
                    refreshMain(null);
                    display.setCurrent(main);
                }
            } else if (c == backCmd) {
                display.setCurrent(main);
            }
        } else if (d == deviceMenu) {
            if (c == List.SELECT_COMMAND) {
                int sel = deviceMenu.getSelectedIndex();
                if (sel >= 3 && sel != 11) ftpUi.stopIfUsesUsb();   // grabar/expulsar: libera el USB (el FTP del teléfono sigue)
                if (sel == 12 || (sel == 3 && menuDevice.optical)) {
                    ejector.start(menuDevice, deviceMenu);
                } else if (sel == 11) {
                    ftpUi.start(menuDevice, deviceMenu);
                } else if (sel == 10) {
                    backup.start(menuDevice, deviceMenu);
                } else if (sel == 9) {
                    images.start(menuDevice, backend.getDevices(), deviceMenu, 6);
                } else if (sel == 8) {
                    images.start(menuDevice, backend.getDevices(), deviceMenu, 2);
                } else if (sel == 7) {
                    images.start(menuDevice, backend.getDevices(), deviceMenu, 4);
                } else if (sel == 6) {
                    images.start(menuDevice, backend.getDevices(), deviceMenu, 5);
                } else if (sel == 5) {
                    images.start(menuDevice, backend.getDevices(), deviceMenu, 3);
                } else if (sel == 4) {
                    images.start(menuDevice, backend.getDevices(), deviceMenu, 1);
                } else if (sel == 3) {
                    images.start(menuDevice, backend.getDevices(), deviceMenu);
                } else if (sel == 2) {
                    if (menuDevice.optical) media.openDisc(menuDevice, deviceMenu);
                    else media.openUsbDisk(menuDevice, deviceMenu);
                } else if (sel == 0) {
                    selected = menuDevice;
                    refreshMain(null);
                    display.setCurrent(main);
                } else {
                    path.removeAllElements();
                    showNode(menuDevice.toNode());
                }
            } else if (c == backCmd) {
                display.setCurrent(storageList);
            }
        } else if (d == detailForm) {
            if (c == backCmd) display.setCurrent(explorer);
        }
    }

    private void alert(String title, String text) {
        Alert a = new Alert(title, text, null, AlertType.INFO);
        a.setTimeout(Alert.FOREVER);
        display.setCurrent(a, main);
    }

    private void showAbout() {
        String t = "USB Informer (J2ME)\nModo actual: " + backend.getName() + "\n";
        if (notes.length() > 0) t = t + "\nNo disponibles:\n" + notes.toString();
        if (backend == sim) {
            t = t + "\nEn modo simulado los datos son de ejemplo. Para ver el USB real hace falta ejecutar "
                    + "el MIDlet dentro de J2ME Loader en Android.";
        }
        alert("Estado", t);
    }

    // ---------- expulsar con seguridad (todas las unidades, una por una) ----------

    private void showEjectList() {
        Vector devs = backend.getDevices();
        ejectDevs = new Vector();
        for (int i = 0; i < devs.size(); i++) {
            UsbDevInfo d = (UsbDevInfo) devs.elementAt(i);
            if (d.mass || d.optical) ejectDevs.addElement(d);
        }
        ejectList = new List("Expulsar con seguridad (" + ejectDevs.size() + ")", Choice.IMPLICIT);
        for (int i = 0; i < ejectDevs.size(); i++) {
            UsbDevInfo d = (UsbDevInfo) ejectDevs.elementAt(i);
            ejectList.append((i + 1) + ". " + d.label() + (d.optical ? " [CD/DVD]" : "") + (d.needsPermission ? " (sin permiso)" : ""), null);
        }
        if (ejectDevs.size() > 1) ejectList.append("Expulsar TODAS (" + ejectDevs.size() + " unidades)", null);
        if (ejectDevs.size() == 0) ejectList.append("(no hay unidades de almacenamiento conectadas)", null);
        ejectList.addCommand(refreshCmd);
        ejectList.addCommand(backCmd);
        ejectList.setCommandListener(this);
        display.setCurrent(ejectList);
    }

    // ---------- elegir dispositivo ----------

    private void showDevices() {
        Vector devs = backend.getDevices();
        listedDevices = devs;
        deviceList = new List("Dispositivos USB (" + devs.size() + ")", Choice.IMPLICIT);
        for (int i = 0; i < devs.size(); i++) {
            UsbDevInfo d = (UsbDevInfo) devs.elementAt(i);
            deviceList.append(d.label() + (d.needsPermission ? " (sin permiso)" : ""), null);
        }
        if (devs.size() == 0) deviceList.append("(ningún dispositivo conectado)", null);
        deviceList.addCommand(backCmd);
        deviceList.setCommandListener(this);
        display.setCurrent(deviceList);
    }

    // ---------- contenido del USB ----------

    private void showStorage() {
        UsbExtras x = (UsbExtras) backend;
        Vector devs = backend.getDevices();
        Vector names = x.storageNames();
        contentItems.removeAllElements();
        storageList = new List("Contenido / archivos", Choice.IMPLICIT);

        storageList.append("-- Dispositivos USB (" + devs.size() + ") --", null);
        contentItems.addElement(new Object[] { new Integer(0), null });
        for (int i = 0; i < devs.size(); i++) {
            UsbDevInfo d = (UsbDevInfo) devs.elementAt(i);
            storageList.append(d.label() + (d.needsPermission ? " (sin permiso)" : ""), null);
            contentItems.addElement(new Object[] { new Integer(1), d });
        }
        storageList.append("-- Almacenamiento (abre el explorador) --", null);
        contentItems.addElement(new Object[] { new Integer(0), null });
        for (int i = 0; i < names.size(); i++) {
            storageList.append((String) names.elementAt(i), null);
            contentItems.addElement(new Object[] { new Integer(2), new Integer(i) });
        }
        storageList.append("Explorador de archivos (general)", null);
        contentItems.addElement(new Object[] { new Integer(3), null });

        storageList.addCommand(backCmd);
        storageList.setCommandListener(this);
        display.setCurrent(storageList);
    }

    private void openContentItem(int idx) {
        if (idx < 0 || idx >= contentItems.size()) return;
        Object[] it = (Object[]) contentItems.elementAt(idx);
        int kind = ((Integer) it[0]).intValue();
        UsbExtras x = (UsbExtras) backend;
        String err = null;
        if (kind == 1) {
            showDeviceMenu((UsbDevInfo) it[1]);
            return;
        } else if (kind == 2) {
            int vi = ((Integer) it[1]).intValue();
            media.volumeMenu(storageList.getString(idx), x.volumePath(vi), vi, storageList);
            return;
        } else if (kind == 3) {
            err = x.openFileManager();
        } else {
            return;
        }
        if (err != null) alert("Archivos", err);
    }

    private void showDeviceMenu(UsbDevInfo dev) {
        menuDevice = dev;
        deviceMenu = new List(dev.label(), Choice.IMPLICIT);
        deviceMenu.append("Ver información en pantalla principal", null);
        deviceMenu.append("Estructura USB (configuraciones, interfaces)", null);
        if (!(backend instanceof AndroidUsb)) {
            // en PC las unidades se ven en "Contenido / archivos" > Almacenamiento
        } else if (dev.optical) deviceMenu.append("Leer disco (CD/DVD)", null);
        else if (dev.mass) {
            deviceMenu.append("Leer USB directamente (ver y copiar archivos)", null);
            deviceMenu.append("Grabar imagen ISO/IMG en este USB (BORRA TODO)", null);
            deviceMenu.append("Grabar CONTENIDO de una ISO (formatea FAT32, BORRA TODO)", null);
            deviceMenu.append("Copiar el contenido de un VHD (formatea FAT32, BORRA TODO)", null);
            deviceMenu.append("Clonar un VHD entero en este USB (sector a sector, BORRA TODO)", null);
            deviceMenu.append("Examinar un VHD (ver y copiar archivos)", null);
            deviceMenu.append("Instalador de WINDOWS: FAT32 normal (boot) + exFAT con la ISO completa (BORRA TODO)", null);
            deviceMenu.append("Grabar INITRD (cpio/.img) en ext2: carpetas, enlaces simbólicos, permisos (BORRA TODO)", null);
            deviceMenu.append("Crear imagen .img de este USB (copia completa, no borra nada)", null);
            deviceMenu.append("Servidor FTP: este USB y/o el teléfono, desde el PC por Wi-Fi", null);
        }
        if (backend instanceof AndroidUsb && dev.mass) deviceMenu.append("Expulsar / quitar con seguridad", null);
        deviceMenu.addCommand(backCmd);
        deviceMenu.setCommandListener(this);
        display.setCurrent(deviceMenu);
    }

    // ---------- explorador USB ----------

    private void openExplorer() {
        Vector devs = backend.getDevices();
        UsbNode root = new UsbNode("Dispositivos USB (" + devs.size() + ")",
                "Modo: " + backend.getName() + "\nDispositivos conectados: " + devs.size());
        for (int i = 0; i < devs.size(); i++) {
            root.add(((UsbDevInfo) devs.elementAt(i)).toNode());
        }
        path.removeAllElements();
        showNode(root);
    }

    private void showNode(UsbNode n) {
        current = n;
        explorer = new List(n.title, Choice.IMPLICIT);
        int cnt = n.children.size();
        for (int i = 0; i < cnt; i++) {
            UsbNode k = (UsbNode) n.children.elementAt(i);
            explorer.append(k.title + (k.children.size() > 0 ? "  >" : ""), null);
        }
        if (cnt == 0) explorer.append("(sin elementos)", null);
        explorer.addCommand(backCmd);
        explorer.addCommand(detailCmd);
        explorer.setCommandListener(this);
        display.setCurrent(explorer);
    }

    private void openChild(int idx) {
        if (idx < 0 || idx >= current.children.size()) return;
        UsbNode k = (UsbNode) current.children.elementAt(idx);
        if (k.children.size() > 0) {
            path.addElement(current);
            showNode(k);
        } else {
            showDetail(k);
        }
    }

    private void goUp() {
        if (path.size() == 0) {
            display.setCurrent(main);
            return;
        }
        UsbNode parent = (UsbNode) path.elementAt(path.size() - 1);
        path.removeElementAt(path.size() - 1);
        showNode(parent);
    }

    private void showDetail(UsbNode n) {
        detailForm = new Form(n.title);
        detailForm.append(new StringItem(null, n.detail == null ? "" : n.detail));
        detailForm.addCommand(backCmd);
        detailForm.setCommandListener(this);
        display.setCurrent(detailForm);
    }
}
