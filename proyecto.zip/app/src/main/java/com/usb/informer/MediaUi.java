package com.usb.informer;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Vector;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.StringItem;

/**
 * Pantallas para leer discos (CD/DVD) y volúmenes USB: explorador de archivos con copia al
 * teléfono, CD de audio (reproducir y copiar a WAV) y DVD de vídeo (reproductor externo).
 */
public class MediaUi implements CommandListener {

    private interface Job {
        String run(Prog p) throws Exception;
    }

    private Display display;
    private UsbExtras x;
    private Displayable ret;

    private Command backCmd = new Command("Atrás", Command.BACK, 1);
    private Command copyCmd = new Command("Copiar al teléfono", Command.SCREEN, 2);
    private Command copyDirCmd = new Command("Copiar esta carpeta", Command.SCREEN, 3);
    private Command statusCmd = new Command("Estado del servidor", Command.SCREEN, 2);
    private Command closeCmd = new Command("Cerrar disco", Command.SCREEN, 5);
    private Command stopCmd = new Command("Parar", Command.SCREEN, 2);
    private Command wavCmd = new Command("Copiar pista a WAV", Command.SCREEN, 3);

    private OpticalDisc disc;
    private IsoDisc iso;
    private FileSource usbFs;
    private Vector audio = new Vector();
    private Vector menuKinds = new Vector();
    private Vector volItems = new Vector();
    /** Pantalla que el usuario ya abandonó (no dependemos de Display.getCurrent, que en PC no es fiable). */
    private volatile Object gone;

    private Form busyForm, fileForm, playerForm, copyForm, dvdPlayForm;
    private List discMenu, browser, audioList, dvdList, dvdMenu, volMenu;
    private StringItem copyStatus, playerStatus;

    private FileSource src;
    private Vector entries;
    private Vector stack = new Vector();
    private FileItem curDir;
    private String curPath = "";
    private FileItem fileSel;

    private Vector dvdTitles = new Vector();
    private int dvdSel;
    private DvdServer server;
    private AudioPlayer player;
    private int audioSel;

    private String volLabel, volPath;
    private int volIdx;

    private Displayable home;
    private Form resultForm;
    private Command homeCmd = new Command("Menú principal", Command.OK, 1);

    public void setHome(Displayable h) {
        home = h;
    }

    /** Muestra una pantalla (callSerially no funciona bien en FreeJ2ME, así que se llama directo). */
    private void show(final Displayable d) {
        display.setCurrent(d);
    }

    /** Resultado final de una copia en PC: pantalla propia con salida al menú principal. */
    private void showResult(String m) {
        resultForm = new Form("Copia terminada");
        resultForm.append(new StringItem(null, m));
        resultForm.addCommand(homeCmd);
        resultForm.addCommand(backCmd);
        resultForm.setCommandListener(this);
        show(resultForm);
    }

    public MediaUi(Display d) {
        display = d;
    }

    public void setBackend(UsbExtras e) {
        x = e;
    }

    // ---------------------------------------------------------------- utilidades

    private Form noteForm;
    private Displayable noteNext;
    private Command okCmd = new Command("Aceptar", Command.OK, 1);

    private void alert(String title, String text, Displayable next) {
        Displayable fn = next != null ? next : ret;
        if (Phone.isPc()) {
            // FreeJ2ME no repinta las Alert que se lanzan desde otro hilo: usamos una pantalla normal
            noteForm = new Form(title);
            noteForm.append(new StringItem(null, text));
            noteForm.addCommand(okCmd);
            noteForm.addCommand(backCmd);
            noteForm.setCommandListener(this);
            noteNext = fn;
            display.setCurrent(noteForm);
            return;
        }
        Alert a = new Alert(title, text, null, AlertType.INFO);
        a.setTimeout(Alert.FOREVER);
        display.setCurrent(a, fn);
    }

    private static String pad2(int v) {
        return v < 10 ? "0" + v : String.valueOf(v);
    }

    private static String time(int sectors) {
        int s = sectors / 75;
        return pad2(s / 60) + ":" + pad2(s % 60);
    }

    private static String msg(Throwable t) {
        return t.getMessage() != null ? t.getMessage() : t.toString();
    }

    public void close() {
        if (player != null) player.halt();
        player = null;
        if (server != null) server.stop();
        server = null;
        if (disc != null) disc.close();
        disc = null;
        iso = null;
        usbFs = null;
    }

    // ---------------------------------------------------------------- volúmenes montados

    public void volumeMenu(String label, String path, int idx, Displayable back) {
        ret = back;
        volLabel = label;
        volPath = path;
        volIdx = idx;
        volMenu = new List(label, Choice.IMPLICIT);
        volItems.removeAllElements();
        String kind = x != null ? x.volumeKind(idx) : "";
        volMenu.append("Explorar y copiar archivos", null);
        volItems.addElement(new Integer(0));
        volMenu.append("Abrir en el explorador del sistema", null);
        volItems.addElement(new Integer(1));
        if (kind.equals("cd")) {
            volMenu.append("Reproducir DVD con VLC", null);
            volItems.addElement(new Integer(2));
            volMenu.append("Reproducir CD de audio con VLC", null);
            volItems.addElement(new Integer(3));
        } else if (kind.equals("android")) {
            volMenu.append("Aviso: aquí Android solo me deja ver carpetas; para ver y copiar archivos usa \"Leer USB directamente\" en el menú del dispositivo.", null);
            volItems.addElement(new Integer(4));
        }
        volMenu.addCommand(backCmd);
        volMenu.setCommandListener(this);
        show(volMenu);
    }

    private void openVolume() {
        try {
            String nm = volLabel;
            int par = nm.indexOf(" (");
            if (par > 0) nm = nm.substring(0, par);
            LocalVolume lv = new LocalVolume(new File(volPath), nm);
            Vector root = lv.listRoot();
            openBrowser(lv, root);
        } catch (Throwable t) {
            alert("Volumen", msg(t), volMenu);
        }
    }

    // ---------------------------------------------------------------- disco óptico

    public void openDisc(final UsbDevInfo dev, Displayable back) {
        if (x == null) return;
        ret = back;
        if (dev.needsPermission) {
            alert("Disco", "Primero concede el permiso USB (menú: Pedir permiso USB).", back);
            return;
        }
        close();
        busyForm = new Form("Leyendo disco");
        busyForm.append("Leyendo el disco... puede tardar unos segundos mientras la unidad gira.");
        busyForm.addCommand(backCmd);
        busyForm.setCommandListener(this);
        final Form mine = busyForm;
        show(busyForm);
        new Thread(new Runnable() {
            public void run() {
                OpticalDisc o = null;
                try {
                    o = x.openDisc(dev);
                    Vector toc = new Vector();
                    try {
                        toc = o.readToc();
                    } catch (Throwable t) {
                        // sin tabla de pistas: seguimos con ISO
                    }
                    boolean hasData = toc.size() == 0;
                    Vector tr = new Vector();
                    for (int k = 0; k + 1 < toc.size(); k++) {
                        int[] a = (int[]) toc.elementAt(k);
                        int[] b = (int[]) toc.elementAt(k + 1);
                        if ((a[1] & 4) != 0) {
                            hasData = true;
                        } else if (a[0] != 0xAA) {
                            tr.addElement(new int[] { a[0], a[2], b[2] });
                        }
                    }
                    IsoDisc i = null;
                    String isoErr = null;
                    if (hasData) {
                        try {
                            i = new IsoDisc(o);
                        } catch (Throwable t) {
                            isoErr = msg(t);
                        }
                    }
                    if (gone == mine) {
                        o.close();
                        return;
                    }
                    disc = o;
                    iso = i;
                    audio = tr;
                    showDiscMenu(isoErr);
                } catch (Throwable t) {
                    if (o != null) o.close();
                    disc = null;
                    alert("Disco", msg(t), ret);
                }
            }
        }).start();
    }

    /** Lee un pendrive / disco USB directamente por USB (FAT12/16/32, exFAT). */
    public void openUsbDisk(final UsbDevInfo dev, Displayable back) {
        if (x == null) return;
        ret = back;
        if (dev.needsPermission) {
            alert("USB", "Primero concede el permiso USB (menú: Pedir permiso USB).", back);
            return;
        }
        close();
        busyForm = new Form("Leyendo USB");
        busyForm.append("Leyendo el USB directamente... Android desmontará el USB mientras lo uso; "
                + "al cerrar o desconectar vuelve a montarse.");
        busyForm.addCommand(backCmd);
        busyForm.setCommandListener(this);
        final Form mine = busyForm;
        show(busyForm);
        new Thread(new Runnable() {
            public void run() {
                OpticalDisc o = null;
                try {
                    o = x.openDisc(dev, false);
                    FileSource fs = UsbVolume.mount(o);
                    Vector root = fs.listRoot();
                    if (gone == mine) {
                        o.close();
                        return;
                    }
                    disc = o;
                    usbFs = fs;
                    discMenu = new List("USB", Choice.IMPLICIT);
                    discMenu.append("x", null);
                    openBrowser(fs, root);
                } catch (Throwable t) {
                    if (o != null) o.close();
                    disc = null;
                    alert("USB", msg(t), ret);
                }
            }
        }).start();
    }

    /** Examina un sistema de archivos ya montado (p. ej. el interior de un VHD). Atrás en la raíz vuelve a back. */
    public void openFileSource(FileSource fs, Displayable back) throws Exception {
        close();
        ret = back;
        Vector root = fs.listRoot();
        usbFs = fs;
        openBrowser(fs, root);
    }

    private void showDiscMenu(String isoErr) {
        discMenu = new List("Disco: " + (iso != null ? iso.label() : "sin sistema de archivos"), Choice.IMPLICIT);
        menuKinds.removeAllElements();
        if (iso != null) {
            discMenu.append("Archivos del disco (copiar al teléfono)", null);
            menuKinds.addElement(new Integer(1));
            if (findVideoTs() != null) {
                discMenu.append("DVD vídeo (reproducir / copiar)", null);
                menuKinds.addElement(new Integer(3));
            }
        }
        if (audio.size() > 0) {
            discMenu.append("CD de audio (" + audio.size() + " pistas)", null);
            menuKinds.addElement(new Integer(2));
        }
        if (menuKinds.size() == 0) {
            close();
            alert("Disco", isoErr != null ? isoErr : "El disco está vacío o no se puede leer.", ret);
            return;
        }
        discMenu.addCommand(backCmd);
        discMenu.setCommandListener(this);
        show(discMenu);
    }

    private FileItem findVideoTs() {
        try {
            Vector root = iso.listRoot();
            for (int i = 0; i < root.size(); i++) {
                FileItem e = (FileItem) root.elementAt(i);
                if (e.dir && e.name.equalsIgnoreCase("VIDEO_TS")) return e;
            }
        } catch (Throwable t) {
            // sin DVD
        }
        return null;
    }

    // ---------------------------------------------------------------- explorador + copia

    private void openBrowser(FileSource s, Vector root) {
        src = s;
        stack.removeAllElements();
        curDir = null;
        curPath = "";
        showDir(root);
    }

    private void showDir(Vector list) {
        entries = list;
        browser = new List(src.label() + curPath, Choice.IMPLICIT);
        for (int i = 0; i < list.size(); i++) {
            FileItem e = (FileItem) list.elementAt(i);
            browser.append(e.dir ? "[" + e.name + "]" : e.name + " (" + Phone.sizeText(e.size) + ")", null);
        }
        if (list.size() == 0) browser.append("(vacío)", null);
        browser.addCommand(backCmd);
        browser.addCommand(copyDirCmd);
        if (disc != null) browser.addCommand(closeCmd);
        browser.setCommandListener(this);
        show(browser);
    }

    private void openEntry(int idx) {
        if (entries == null || idx < 0 || idx >= entries.size()) return;
        FileItem e = (FileItem) entries.elementAt(idx);
        try {
            if (e.dir) {
                Vector sub = src.list(e);
                stack.addElement(new Object[] { entries, curDir, curPath });
                curDir = e;
                curPath = curPath + "/" + e.name;
                showDir(sub);
            } else {
                fileSel = e;
                StringBuffer sb = new StringBuffer();
                sb.append("Nombre: ").append(e.name).append("\nTamaño: ").append(Phone.sizeText(e.size))
                        .append(" (").append(e.size).append(" bytes)\n\nVista previa:\n");
                try {
                    sb.append(src.preview(e, 700));
                } catch (Throwable t) {
                    sb.append("No se pudo leer: ").append(msg(t));
                }
                fileForm = new Form(e.name);
                fileForm.append(new StringItem(null, sb.toString()));
                fileForm.addCommand(backCmd);
                fileForm.addCommand(copyCmd);
                fileForm.setCommandListener(this);
                show(fileForm);
            }
        } catch (Throwable t) {
            alert("Archivos", msg(t), browser);
        }
    }

    private void browserUp() {
        if (stack.size() == 0) {
            if (usbFs != null) {
                close();
                show(ret);
            } else if (disc != null) show(discMenu);
            else show(volMenu);
            return;
        }
        Object[] top = (Object[]) stack.elementAt(stack.size() - 1);
        stack.removeElementAt(stack.size() - 1);
        curDir = (FileItem) top[1];
        curPath = (String) top[2];
        showDir((Vector) top[0]);
    }

    private void copyItems(final Vector items, final FileSource s, final Displayable back) {
        runJob("Copiando", new Job() {
            public String run(Prog p) throws Exception {
                String rel = Phone.safe(s.label());
                int[] count = { 0 };
                Phone.skipped.removeAllElements();
                String[] where = { "Descargas/USB-Informer/" + rel };
                for (int i = 0; i < items.size(); i++) {
                    Phone.copyItem(s, (FileItem) items.elementAt(i), rel, p, count, 0, where);
                }
                if (count[0] == 0) return "No se copió ningún archivo (las carpetas estaban vacías o sin acceso)." + Phone.skippedText();
                return done("Copiado: " + count[0] + " archivo(s), " + Phone.sizeText(p.bytes), where[0]) + Phone.skippedText();
            }
        }, back);
    }

    private static String done(String what, String where) {
        return what + "\nGuardado en: " + where;
    }

    private class Prog implements Progress {
        volatile boolean cancel;
        long bytes;
        String cur = "";
        long last;

        public boolean cancelled() { return cancel; }

        public void file(String n) {
            cur = n;
            update(true);
        }

        public void add(long n) {
            bytes += n;
            update(false);
        }

        private void update(boolean force) {
            long now = System.currentTimeMillis();
            if (force || now - last > 400) {
                last = now;
                if (copyStatus != null) {
                    copyStatus.setText("Copiando:\n" + cur + "\n\n" + Phone.sizeText(bytes) + " copiados\n\n(Atrás = cancelar)");
                    OpStatus.progress(Phone.sizeText(bytes) + " copiados  \u00B7  " + cur, 0, 0);
                    // en FreeJ2ME el texto solo se repinta al volver a mostrar la pantalla
                    if (Phone.isPc() && gone != copyForm && !cancel) display.setCurrent(copyForm);
                }
            }
        }
    }

    private Prog prog;

    private void runJob(String title, final Job job, final Displayable back) {
        final Prog p = new Prog();
        prog = p;
        OpStatus.begin(title);
        copyForm = new Form(title);
        copyStatus = new StringItem(null, "Preparando...");
        copyForm.append(copyStatus);
        copyForm.addCommand(backCmd);
        copyForm.setCommandListener(this);
        final Form mine = copyForm;
        copyBack = back;
        show(copyForm);
        new Thread(new Runnable() {
            public void run() {
                String m;
                try {
                    m = job.run(p);
                } catch (Throwable t) {
                    m = p.cancel ? "Copia cancelada." : "Error al copiar: " + msg(t);
                    Phone.log("error: " + t);
                }
                Phone.log("fin: " + m.replace('\n', ' '));
                {
                    String first = m;
                    int nl = first.indexOf('\n');
                    if (nl > 0) first = first.substring(0, nl);
                    OpStatus.end(m.startsWith("Error") ? OpStatus.FAIL : p.cancel ? OpStatus.CANCEL : OpStatus.OK, first);
                }
                if (gone != mine) {
                    if (Phone.isPc() && home != null) showResult(m);
                    else alert("Copia", m, back);
                }
            }
        }).start();
    }

    private Displayable copyBack;

    // ---------------------------------------------------------------- CD de audio

    private void showAudioList() {
        audioList = new List("CD de audio", Choice.IMPLICIT);
        for (int i = 0; i < audio.size(); i++) {
            int[] t = (int[]) audio.elementAt(i);
            audioList.append("Pista " + t[0] + "  (" + time(t[2] - t[1]) + ")", null);
        }
        audioList.addCommand(backCmd);
        audioList.setCommandListener(this);
        show(audioList);
    }

    private void playTrack(int idx) {
        if (idx < 0 || idx >= audio.size()) return;
        if (player != null) player.halt();
        audioSel = idx;
        final int[] t = (int[]) audio.elementAt(idx);
        final AudioPlayer pl = new AudioPlayer(disc, t[1], t[2]);
        player = pl;
        playerForm = new Form("Pista " + t[0]);
        playerStatus = new StringItem(null, "Iniciando...");
        playerForm.append(playerStatus);
        playerForm.addCommand(backCmd);
        playerForm.addCommand(stopCmd);
        playerForm.addCommand(wavCmd);
        playerForm.setCommandListener(this);
        final Form mine = playerForm;
        show(playerForm);
        pl.begin();
        new Thread(new Runnable() {
            public void run() {
                while (gone != mine && !pl.done) {
                    playerStatus.setText("Pista " + t[0] + "\nReproduciendo " + time(pl.cur - pl.start) + " / "
                            + time(pl.end - pl.start));
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        return;
                    }
                }
                if (gone != mine) {
                    playerStatus.setText(pl.error != null ? "Error: " + pl.error
                            : (pl.stop ? "Detenido" : "Terminado"));
                }
            }
        }).start();
    }

    private void ripTrack() {
        final int[] t = (int[]) audio.elementAt(audioSel);
        final AudioPlayer old = player;
        if (old != null) {
            old.halt();
            for (int k = 0; k < 40 && !old.done; k++) {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    break;
                }
            }
        }
        runJob("Copiando pista", new Job() {
            public String run(Prog p) throws Exception {
                Phone.Out f = Phone.create("CD-audio", "Pista" + pad2(t[0]) + ".wav");
                p.file("Pista" + pad2(t[0]) + ".wav");
                boolean ok = false;
                try {
                    AudioPlayer.rip(disc, t[1], t[2], f.os, p);
                    ok = true;
                } finally {
                    if (ok) f.os.close();
                    else f.abort();
                }
                return done("Pista " + t[0] + " guardada (" + Phone.sizeText(p.bytes) + ")", f.where);
            }
        }, audioList);
    }

    // ---------------------------------------------------------------- DVD vídeo

    private void showDvd() {
        FileItem vts = findVideoTs();
        if (vts == null) return;
        try {
            Vector files = iso.list(vts);
            Vector titles = new Vector();
            for (int i = 0; i < files.size(); i++) {
                FileItem f = (FileItem) files.elementAt(i);
                String n = f.name.toUpperCase();
                if (f.dir || !n.startsWith("VTS_") || !n.endsWith(".VOB") || n.length() < 12) continue;
                String set = n.substring(4, 6);
                String part = n.substring(7, n.length() - 4);
                if (part.equals("0")) continue;   // menú del título
                Object[] t = null;
                for (int k = 0; k < titles.size(); k++) {
                    if (((String) ((Object[]) titles.elementAt(k))[0]).equals(set)) t = (Object[]) titles.elementAt(k);
                }
                if (t == null) {
                    t = new Object[] { set, new Vector(), new long[] { 0 } };
                    titles.addElement(t);
                }
                ((Vector) t[1]).addElement(f);
                ((long[]) t[2])[0] += f.size;
            }
            dvdTitles = titles;
            if (titles.size() == 0) {
                alert("DVD", "No se encontraron títulos de vídeo en VIDEO_TS.", discMenu);
                return;
            }
            dvdList = new List("DVD vídeo", Choice.IMPLICIT);
            for (int i = 0; i < titles.size(); i++) {
                Object[] t = (Object[]) titles.elementAt(i);
                dvdList.append("Título " + t[0] + " (" + Phone.sizeText(((long[]) t[2])[0]) + ")", null);
            }
            dvdList.addCommand(backCmd);
            dvdList.setCommandListener(this);
            int cp = disc.copyProtection();
            if (cp == 1 || cp == 2) {
                alert("DVD protegido", "Este DVD lleva protección anticopia (" + (cp == 1 ? "CSS" : "CPRM")
                        + "). Esta aplicación no descifra discos protegidos, así que los vídeos no se podrán "
                        + "reproducir ni copiar de forma útil. Los DVD caseros o sin cifrar sí funcionan.", dvdList);
            } else {
                show(dvdList);
            }
        } catch (Throwable t) {
            alert("DVD", msg(t), discMenu);
        }
    }

    private void showDvdMenu(int idx) {
        if (idx < 0 || idx >= dvdTitles.size()) return;
        dvdSel = idx;
        Object[] t = (Object[]) dvdTitles.elementAt(idx);
        dvdMenu = new List("Título " + t[0], Choice.IMPLICIT);
        dvdMenu.append("Reproducir (VLC u otro reproductor)", null);
        dvdMenu.append("Copiar al teléfono (un archivo .vob)", null);
        dvdMenu.addCommand(backCmd);
        dvdMenu.setCommandListener(this);
        show(dvdMenu);
    }

    private void playDvd() {
        final Object[] t = (Object[]) dvdTitles.elementAt(dvdSel);
        if (server != null) server.stop();
        try {
            server = new DvdServer(iso, (Vector) t[1]);
            String url = server.start();
            String err = x.openUrl(url, "video/mpeg");
            dvdPlayForm = new Form("Reproduciendo título " + t[0]);
            dvdPlayForm.append(err == null
                    ? "Se ha abierto el reproductor. Si no se abre, instala VLC o abre esta dirección en "
                      + "VLC (Abrir flujo de red):\n" + url
                    : "No se pudo abrir un reproductor automáticamente (" + err + ").\nInstala VLC y abre esta "
                      + "dirección en VLC (Abrir flujo de red):\n" + url);
            dvdPlayForm.append("\n\nMantén esta pantalla abierta mientras ves el vídeo. Si el reproductor no muestra imagen y el disco es una película comercial, probablemente está cifrado (CSS) y VLC/MX no pueden leerlo en bruto; en ese caso usa un reproductor que lea la unidad USB directamente. Atrás = cerrar el servidor.");
            dvdPlayForm.addCommand(backCmd);
            dvdPlayForm.addCommand(statusCmd);
            dvdPlayForm.setCommandListener(this);
            show(dvdPlayForm);
        } catch (Throwable e) {
            alert("DVD", msg(e), dvdMenu);
        }
    }

    private void copyDvd() {
        final Object[] t = (Object[]) dvdTitles.elementAt(dvdSel);
        final Vector files = (Vector) t[1];
        runJob("Copiando título " + t[0], new Job() {
            public String run(Prog p) throws Exception {
                Phone.Out f = Phone.create("DVD", "Titulo" + t[0] + ".vob");
                p.file("Titulo" + t[0] + ".vob");
                boolean ok = false;
                try {
                    for (int i = 0; i < files.size(); i++) iso.copy((FileItem) files.elementAt(i), f.os, p);
                    ok = true;
                } finally {
                    if (ok) f.os.close();
                    else f.abort();
                }
                return done("Título " + t[0] + " guardado (" + Phone.sizeText(p.bytes) + ")", f.where);
            }
        }, dvdMenu);
    }

    // ---------------------------------------------------------------- comandos

    public void commandAction(Command c, Displayable d) {
        if (d == volMenu) {
            if (c == backCmd) {
                show(ret);
            } else if (c == List.SELECT_COMMAND) {
                int sel = volMenu.getSelectedIndex();
                int code = sel >= 0 && sel < volItems.size() ? ((Integer) volItems.elementAt(sel)).intValue() : -1;
                if (code == 0) {
                    openVolume();
                } else if (code == 1) {
                    String err = x.openStorage(volIdx);
                    if (err != null) alert("Archivos", err, volMenu);
                } else if (code == 2 || code == 3) {
                    String err = x.playDisc(volIdx, code == 3);
                    alert("Reproductor", err != null ? err : "Se abrió VLC con el disco. Si pide clave o no abre, comprueba que VLC está instalado.", volMenu);
                }
            }
        } else if (d == noteForm) {
            display.setCurrent(noteNext != null ? noteNext : ret);
        } else if (d == resultForm) {
            show(home != null ? home : ret);
        } else if (d == busyForm) {
            if (c == backCmd) {
                gone = busyForm;
                show(ret);
            }
        } else if (d == discMenu) {
            if (c == backCmd) {
                close();
                show(ret);
            } else if (c == List.SELECT_COMMAND) {
                int i = discMenu.getSelectedIndex();
                if (i < 0 || i >= menuKinds.size()) return;
                int kind = ((Integer) menuKinds.elementAt(i)).intValue();
                if (kind == 1) {
                    try {
                        openBrowser(iso, iso.listRoot());
                    } catch (Throwable t) {
                        alert("Disco", msg(t), discMenu);
                    }
                } else if (kind == 2) {
                    showAudioList();
                } else {
                    showDvd();
                }
            }
        } else if (d == browser) {
            if (c == List.SELECT_COMMAND) {
                openEntry(browser.getSelectedIndex());
            } else if (c == backCmd) {
                browserUp();
            } else if (c == closeCmd) {
                close();
                show(ret);
            } else if (c == copyDirCmd) {
                Vector items = new Vector();
                if (curDir != null) items.addElement(curDir);
                else items = entries;
                copyItems(items, src, browser);
            }
        } else if (d == fileForm) {
            if (c == backCmd) {
                show(browser);
            } else if (c == copyCmd) {
                Vector one = new Vector();
                one.addElement(fileSel);
                copyItems(one, src, browser);
            }
        } else if (d == copyForm) {
            if (c == backCmd) {
                if (prog != null) prog.cancel = true;
                gone = copyForm;
                show(copyBack != null ? copyBack : ret);
            }
        } else if (d == audioList) {
            if (c == backCmd) {
                show(discMenu);
            } else if (c == List.SELECT_COMMAND) {
                playTrack(audioList.getSelectedIndex());
            }
        } else if (d == playerForm) {
            if (c == backCmd) {
                if (player != null) player.halt();
                gone = playerForm;
                show(audioList);
            } else if (c == stopCmd) {
                if (player != null) player.halt();
            } else if (c == wavCmd) {
                ripTrack();
            }
        } else if (d == dvdList) {
            if (c == backCmd) show(discMenu);
            else if (c == List.SELECT_COMMAND) showDvdMenu(dvdList.getSelectedIndex());
        } else if (d == dvdMenu) {
            if (c == backCmd) {
                show(dvdList);
            } else if (c == List.SELECT_COMMAND) {
                if (dvdMenu.getSelectedIndex() == 0) playDvd();
                else copyDvd();
            }
        } else if (d == dvdPlayForm && c == statusCmd) {
            alert("Servidor DVD", server != null ? server.status() : "Detenido", dvdPlayForm);
        } else if (d == dvdPlayForm) {
            if (c == backCmd) {
                if (server != null) server.stop();
                server = null;
                show(dvdMenu);
            }
        }
    }
}
