package com.usb.informer;
public interface Progress {
    boolean cancelled();
    void add(long bytes);
    void file(String name);
}
