package com.usb.informer;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Vector;

/**
 * Formatea un USB en FAT32 (MBR con una partición) y copia dentro el CONTENIDO de una ISO (archivos y carpetas),
 * en vez de volcar la imagen. Solo FAT32: los archivos de 4 GB o más no caben y se omiten.
 * Todo se escribe de forma secuencial: carpetas primero, luego archivos en el orden en que están en la ISO.
 */
public class FatWriter {

    public static class Node {
        String name;
        String shortName;      // 11 bytes tal cual van en la entrada
        int caseFlags;
        boolean lfn;
        boolean dir;
        long size;
        FileItem src;
        byte[] mem;
        Vector kids = new Vector();
        Node parent;
        long first;
        long clusters;
    }

    private DiscTree iso;
    private OpticalDisc dev;
    private Node root = new Node();
    private Vector dirs = new Vector();       // en orden (raíz primero)
    private Vector files = new Vector();      // ordenados por posición en la ISO
    public Vector skipped = new Vector();
    public long fileBytes;
    public boolean hasEfi;
    public String label = "";

    // geometría
    private int bs, spc;
    private long resv = 32;   // sectores reservados: 32 o más, para que los datos empiecen alineados al cluster (como Windows/Rufus)
    private long clusterBytes, partStart, partBlocks, fatSz, dataStart, totalClusters;
    private int[] fat;
    private long next;
    private int bootDirs;
    private long now = System.currentTimeMillis();
    private long forcedStart = -1, forcedBlocks;
    private boolean gptMode;
    private boolean gptDisk;         // true = este escritor crea también la tabla GPT (una partición)
    private String[] only;

    /** Escribe dentro de una partición ya definida (disco GPT): no toca MBR ni el resto del disco. */
    public void setPartition(long startBlock, long blocks) {
        forcedStart = startBlock;
        forcedBlocks = blocks;
        gptMode = true;
    }

    /** El USB se crea con tabla GPT (una partición FAT32) en vez de MBR. */
    public void setGptDisk(boolean g) {
        gptDisk = g;
        if (g) gptMode = true;
    }

    private static String randGuid() {
        java.util.Random r = new java.util.Random(System.currentTimeMillis() ^ System.identityHashCode(new Object()));
        String h = "0123456789abcdef";
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < 36; i++) {
            if (i == 8 || i == 13 || i == 18 || i == 23) sb.append('-');
            else if (i == 14) sb.append('4');
            else if (i == 19) sb.append("89ab".charAt(r.nextInt(4)));
            else sb.append(h.charAt(r.nextInt(16)));
        }
        return sb.toString();
    }

    /** Solo se copian estas carpetas/archivos de la raíz (sin distinguir mayúsculas). */
    public void setOnly(String[] names) { only = names; }

    /** Rutas concretas (p. ej. "sources/boot.wim") que se copian aunque su carpeta de primer nivel no esté en setOnly. */
    private String[] onlyPaths;
    public void setOnlyPaths(String[] paths) { onlyPaths = paths; }

    private boolean pathOk(String rel, boolean dir) {
        if (onlyPaths == null) return false;
        String r = rel.toLowerCase();
        for (int k = 0; k < onlyPaths.length; k++) {
            String o = onlyPaths[k].toLowerCase();
            if (o.equals(r)) return true;
            if (dir && o.startsWith(r + "/")) return true;
        }
        return false;
    }

    private boolean inOnly(String nm) {
        for (int k = 0; k < only.length; k++) if (only[k].equalsIgnoreCase(nm)) return true;
        return false;
    }

    private Node child(Node d, String nm) {
        for (int i = 0; i < d.kids.size(); i++) {
            if (((Node) d.kids.elementAt(i)).name.equalsIgnoreCase(nm)) return (Node) d.kids.elementAt(i);
        }
        return null;
    }

    /** Pone (o sustituye) un archivo cuyo contenido está en memoria, creando las carpetas que falten. */
    public void putFile(String path, byte[] data) {
        String[] parts = split(path);
        Node d = root;
        for (int i = 0; i < parts.length - 1; i++) {
            Node c = child(d, parts[i]);
            if (c == null) {
                c = new Node();
                c.name = parts[i];
                c.dir = true;
                c.parent = d;
                d.kids.addElement(c);
                dirs.addElement(c);
            }
            d = c;
        }
        String nm = parts[parts.length - 1];
        Node f = child(d, nm);
        if (f == null) {
            f = new Node();
            f.name = nm;
            f.parent = d;
            d.kids.addElement(f);
            files.addElement(f);
        } else {
            fileBytes -= f.size;
        }
        f.mem = data;
        f.size = data.length;
        f.src = null;
        fileBytes += data.length;
    }

    private static String[] split(String path) {
        Vector v = new Vector();
        int st = 0;
        for (int i = 0; i <= path.length(); i++) {
            if (i == path.length() || path.charAt(i) == '/') {
                if (i > st) v.addElement(path.substring(st, i));
                st = i + 1;
            }
        }
        String[] a = new String[v.size()];
        v.copyInto(a);
        return a;
    }

    private long pos(Node n) {
        return n.src == null ? Long.MAX_VALUE : iso.position(n.src);
    }

    public FatWriter(DiscTree iso, OpticalDisc dev) {
        this.iso = iso;
        this.dev = dev;
        root.dir = true;
        root.name = "";
    }

    public int fileCount() { return files.size(); }

    public int dirCount() { return dirs.size(); }

    // ------------------------------------------------------------ 1. recorrer la ISO

    public void scan(Progress p) throws Exception {
        String v = iso.label();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < v.length() && sb.length() < 11; i++) {
            char c = Character.toUpperCase(v.charAt(i));
            if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-') sb.append(c);
            else if (c == ' ') sb.append(' ');
        }
        label = sb.toString().trim();
        if (label.equals("DISCO")) label = "";
        dirs.addElement(root);
        walk(root, iso.listRoot(), "", 0, p);
        Node[] arr = new Node[files.size()];
        files.copyInto(arr);
        Arrays.sort(arr, new Comparator() {
            public int compare(Object a, Object b) {
                long x = pos((Node) a);
                long y = pos((Node) b);
                return x < y ? -1 : (x > y ? 1 : 0);
            }
        });
        files = new Vector();
        for (int i = 0; i < arr.length; i++) files.addElement(arr[i]);
    }

    private void walk(Node dir, Vector items, String path, int depth, Progress p) throws Exception {
        if (depth > 32) return;
        for (int i = 0; i < items.size(); i++) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            FileItem it = (FileItem) items.elementAt(i);
            String nm = clean(it.name);
            if (nm.length() == 0) continue;
            if (only != null) {
                String rel = (path + "/" + nm).substring(1);
                int sl = rel.indexOf('/');
                String top = sl < 0 ? rel : rel.substring(0, sl);
                if (!inOnly(top) && !pathOk(rel, it.dir)) continue;
            }
            if (nameTaken(dir, nm)) {
                skipped.addElement(path + "/" + it.name + " (nombre repetido)");
                continue;
            }
            Node n = new Node();
            n.name = nm;
            n.parent = dir;
            n.src = it;
            n.dir = it.dir;
            if (it.dir) {
                dir.kids.addElement(n);
                dirs.addElement(n);
                String low = nm.toLowerCase();
                walk(n, iso.list(it), path + "/" + nm, depth + 1, p);
                if (dir == root && low.equals("efi")) bootDirs |= 1;
                if (dir.parent == root && dir.name.equalsIgnoreCase("efi") && low.equals("boot")) bootDirs |= 2;
            } else {
                if (it.size > 0xFFFFFFFFL) {
                    skipped.addElement(path + "/" + it.name + " (" + Phone.sizeText(it.size) + ": FAT32 no admite 4 GB o más)");
                    continue;
                }
                n.size = it.size;
                dir.kids.addElement(n);
                files.addElement(n);
                fileBytes += it.size;
                String low = nm.toLowerCase();
                if (dir.parent == root && dir.name.equalsIgnoreCase("boot") && dir.parent != null
                        && root.kids.contains(dir.parent) == false && low.startsWith("boot") && low.endsWith(".efi")) {
                    // se comprueba abajo con la ruta completa
                }
                if (path.toLowerCase().equals("/efi/boot") && low.startsWith("boot") && low.endsWith(".efi")) hasEfi = true;
            }
        }
    }

    private static boolean nameTaken(Node dir, String nm) {
        for (int i = 0; i < dir.kids.size(); i++) {
            if (((Node) dir.kids.elementAt(i)).name.equalsIgnoreCase(nm)) return true;
        }
        return false;
    }

    /** Quita caracteres que FAT no admite en nombres largos. */
    private static String clean(String n) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < n.length() && sb.length() < 255; i++) {
            char c = n.charAt(i);
            if (c < 32 || "\"*/:<>?\\|".indexOf(c) >= 0) c = '_';
            sb.append(c);
        }
        String s = sb.toString();
        while (s.endsWith(" ") || s.endsWith(".")) s = s.substring(0, s.length() - 1);
        while (s.startsWith(" ")) s = s.substring(1);
        return s;
    }

    // ------------------------------------------------------------ 2. geometría y reparto de clusters

    /** Calcula la geometría y reparte los clusters. Lanza excepción si no cabe. */
    public void layout() throws Exception {
        // reordenar archivos (los de memoria al final)
        Node[] arr = new Node[files.size()];
        files.copyInto(arr);
        Arrays.sort(arr, new Comparator() {
            public int compare(Object a, Object b) {
                long x = pos((Node) a);
                long y = pos((Node) b);
                return x < y ? -1 : (x > y ? 1 : 0);
            }
        });
        files = new Vector();
        for (int i = 0; i < arr.length; i++) files.addElement(arr[i]);
        bs = dev.blockSize;
        long totalBlocks = dev.blocks;
        if (bs < 512 || bs > 4096) throw new Exception("Tamaño de sector no admitido: " + bs);
        if (forcedStart >= 0) {
            partStart = forcedStart;
            partBlocks = forcedBlocks;
        } else if (gptDisk) {
            long align = (1024 * 1024) / bs;
            partStart = (Math.max(align, Gpt.firstUsable(bs)) + align - 1) / align * align;
            partBlocks = Gpt.lastUsable(totalBlocks, bs) - partStart + 1;
        } else {
            partStart = (1024 * 1024) / bs;
            if (partStart < 8) partStart = 8;
            partBlocks = totalBlocks - partStart;
        }
        long bytes = partBlocks * bs;
        if (bytes < 32L * 1024 * 1024) throw new Exception("El USB es demasiado pequeño (mínimo 64 MB)");
        if (partBlocks > 0xFFFFFFFFL) partBlocks = 0xFFFFFFFFL;
        long cb;
        if (bytes <= 260L * 1024 * 1024) cb = 512;
        else if (bytes <= 8L * 1024 * 1024 * 1024) cb = 4096;
        else if (bytes <= 16L * 1024 * 1024 * 1024) cb = 8192;
        else if (bytes <= 32L * 1024 * 1024 * 1024) cb = 16384;
        else cb = 32768;
        if (cb < bs) cb = bs;
        spc = (int) (cb / bs);
        clusterBytes = cb;
        fatSz = 1;
        resv = 32;
        long clusters = 0;
        for (int i = 0; i < 40; i++) {
            long dataBlocks = partBlocks - resv - 2 * fatSz;
            clusters = dataBlocks / spc;
            long need = ((clusters + 2) * 4 + bs - 1) / bs;
            // alinear el inicio de los datos al tamaño de cluster (la partición ya empieza alineada a 1 MB)
            long r = 32;
            long mis = (r + 2 * need) % spc;
            if (mis != 0) r += spc - mis;
            if (need == fatSz && r == resv) break;
            fatSz = need;
            resv = r;
        }
        if (clusters > 0x0FFFFFF0L) clusters = 0x0FFFFFF0L;
        if (clusters < 65525) throw new Exception("Este tamaño de USB no sirve para FAT32");
        totalClusters = clusters;
        dataStart = partStart + resv + 2 * fatSz;

        // nombres cortos y número de clusters de cada carpeta
        for (int i = 0; i < dirs.size(); i++) {
            Node d = (Node) dirs.elementAt(i);
            assignNames(d);
            int entries = d == root ? (label.length() > 0 ? 1 : 0) : 2;
            for (int k = 0; k < d.kids.size(); k++) {
                Node c = (Node) d.kids.elementAt(k);
                entries += 1 + (c.lfn ? (c.name.length() + 12) / 13 : 0);
            }
            entries += 1;
            d.size = (long) entries * 32;
            d.clusters = Math.max(1, (d.size + cb - 1) / cb);
        }
        next = 2;
        for (int i = 0; i < dirs.size(); i++) {
            Node d = (Node) dirs.elementAt(i);
            d.first = next;
            next += d.clusters;
        }
        for (int i = 0; i < files.size(); i++) {
            Node f = (Node) files.elementAt(i);
            f.clusters = (f.size + cb - 1) / cb;
            f.first = f.size == 0 ? 0 : next;
            next += f.clusters;
        }
        if (next - 2 > totalClusters) {
            throw new Exception("El contenido no cabe en el USB (necesita " + Phone.sizeText((next - 2) * cb)
                    + ", hay " + Phone.sizeText(totalClusters * cb) + ")");
        }
    }

    /** Bytes que se escribirán en la zona de datos (para la barra de progreso). */
    public long dataBytes() { return (next - 2) * clusterBytes; }

    public long usedBytes() { return (next - 2) * clusterBytes; }

    private void assignNames(Node d) {
        Vector used = new Vector();
        for (int i = 0; i < d.kids.size(); i++) {
            Node c = (Node) d.kids.elementAt(i);
            makeShort(c, used);
        }
    }

    private static final String BAD83 = "\"*+,./:;<=>?[\\]| ";

    private void makeShort(Node c, Vector used) {
        String n = c.name;
        int dot = n.lastIndexOf('.');
        String base = dot > 0 ? n.substring(0, dot) : n;
        String ext = dot > 0 ? n.substring(dot + 1) : "";
        boolean lossy = false;
        boolean hasUp = false, hasLow = false, extUp = false, extLow = false;
        StringBuffer b = new StringBuffer();
        for (int i = 0; i < base.length(); i++) {
            char ch = base.charAt(i);
            if (ch == ' ' || ch == '.') { lossy = true; continue; }
            if (ch > 126 || BAD83.indexOf(ch) >= 0) { ch = '_'; lossy = true; }
            if (Character.isUpperCase(ch)) hasUp = true;
            if (Character.isLowerCase(ch)) hasLow = true;
            b.append(Character.toUpperCase(ch));
        }
        StringBuffer e = new StringBuffer();
        for (int i = 0; i < ext.length(); i++) {
            char ch = ext.charAt(i);
            if (ch == ' ' || ch == '.') { lossy = true; continue; }
            if (ch > 126 || BAD83.indexOf(ch) >= 0) { ch = '_'; lossy = true; }
            if (Character.isUpperCase(ch)) extUp = true;
            if (Character.isLowerCase(ch)) extLow = true;
            e.append(Character.toUpperCase(ch));
        }
        if (b.length() == 0) b.append('_');
        String bs8 = b.toString();
        String es3 = e.toString();
        if (bs8.length() > 8) { bs8 = bs8.substring(0, 8); lossy = true; }
        if (es3.length() > 3) { es3 = es3.substring(0, 3); lossy = true; }
        boolean mixed = (hasUp && hasLow) || (extUp && extLow);
        String key = bs8 + "." + es3;
        if (!lossy && !mixed && used.indexOf(key) < 0) {
            // cabe en 8.3 sin nombre largo (con indicadores de minúsculas si hace falta)
            c.lfn = false;
            c.caseFlags = (hasLow ? 0x08 : 0) | (extLow ? 0x10 : 0);
            used.addElement(key);
            c.shortName = pad(bs8, es3);
            return;
        }
        c.lfn = true;
        c.caseFlags = 0;
        for (int t = 1; ; t++) {
            String tail = "~" + t;
            String bb = bs8.length() + tail.length() > 8 ? bs8.substring(0, 8 - tail.length()) : bs8;
            String k = bb + tail + "." + es3;
            if (used.indexOf(k) < 0) {
                used.addElement(k);
                c.shortName = pad(bb + tail, es3);
                return;
            }
        }
    }

    private static String pad(String b, String e) {
        StringBuffer sb = new StringBuffer(b);
        while (sb.length() < 8) sb.append(' ');
        sb.append(e);
        while (sb.length() < 11) sb.append(' ');
        return sb.toString();
    }

    // ------------------------------------------------------------ 3. escribir

    private int dosDate() {
        Calendar c = Calendar.getInstance();
        c.setTime(new java.util.Date(now));
        return ((c.get(Calendar.YEAR) - 1980) << 9) | ((c.get(Calendar.MONTH) + 1) << 5) | c.get(Calendar.DAY_OF_MONTH);
    }

    private int dosTime() {
        Calendar c = Calendar.getInstance();
        c.setTime(new java.util.Date(now));
        return (c.get(Calendar.HOUR_OF_DAY) << 11) | (c.get(Calendar.MINUTE) << 5) | (c.get(Calendar.SECOND) / 2);
    }

    private static void put16(byte[] b, int o, int v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
    }

    private static void put32(byte[] b, int o, long v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
        b[o + 2] = (byte) (v >> 16);
        b[o + 3] = (byte) (v >> 24);
    }

    private byte[] entry(String name11, int attr, int flags, long cluster, long size) {
        byte[] e = new byte[32];
        for (int i = 0; i < 11; i++) e[i] = (byte) name11.charAt(i);
        e[11] = (byte) attr;
        e[12] = (byte) flags;
        int t = dosTime(), d = dosDate();
        put16(e, 14, t);
        put16(e, 16, d);
        put16(e, 18, d);
        put16(e, 20, (int) (cluster >> 16));
        put16(e, 22, t);
        put16(e, 24, d);
        put16(e, 26, (int) (cluster & 0xFFFF));
        put32(e, 28, size);
        return e;
    }

    private static int checksum(String s11) {
        int sum = 0;
        for (int i = 0; i < 11; i++) sum = (((sum & 1) << 7) + ((sum & 0xFF) >> 1) + (s11.charAt(i) & 0xFF)) & 0xFF;
        return sum;
    }

    private byte[] dirBytes(Node d) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        if (d == root) {
            if (label.length() > 0) {
                StringBuffer l = new StringBuffer(label);
                while (l.length() < 11) l.append(' ');
                o.write(entry(l.toString(), 0x08, 0, 0, 0));
            }
        } else {
            o.write(entry(".          ", 0x10, 0, d.first, 0));
            o.write(entry("..         ", 0x10, 0, d.parent == root ? 0 : d.parent.first, 0));
        }
        for (int i = 0; i < d.kids.size(); i++) {
            Node c = (Node) d.kids.elementAt(i);
            if (c.lfn) {
                int n = (c.name.length() + 12) / 13;
                int cs = checksum(c.shortName);
                for (int k = n; k >= 1; k--) {
                    byte[] e = new byte[32];
                    e[0] = (byte) (k | (k == n ? 0x40 : 0));
                    e[11] = 0x0F;
                    e[13] = (byte) cs;
                    int[] offs = { 1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30 };
                    for (int j = 0; j < 13; j++) {
                        int idx = (k - 1) * 13 + j;
                        int ch = idx < c.name.length() ? c.name.charAt(idx) : (idx == c.name.length() ? 0 : 0xFFFF);
                        put16(e, offs[j], ch);
                    }
                    o.write(e);
                }
            }
            o.write(entry(c.shortName, c.dir ? 0x10 : 0x20, c.caseFlags, c.first, c.dir ? 0 : c.size));
        }
        byte[] b = o.toByteArray();
        byte[] full = new byte[(int) (d.clusters * clusterBytes)];
        System.arraycopy(b, 0, full, 0, b.length);
        return full;
    }

    private void zero(long startBlock, long blocks, Progress p) throws Exception {
        byte[] z = new byte[OpticalDisc.WRITE_CHUNK];
        int per = OpticalDisc.WRITE_CHUNK / bs;
        long done = 0;
        while (done < blocks) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            int n = (int) Math.min(per, blocks - done);
            dev.write((int) (startBlock + done), z, n * bs);
            done += n;
        }
    }

    private void writeBlocks(long lba, byte[] data) throws Exception {
        if (data.length % bs != 0) {
            byte[] c = new byte[((data.length + bs - 1) / bs) * bs];
            System.arraycopy(data, 0, c, 0, data.length);
            data = c;
        }
        int pos = 0;
        while (pos < data.length) {
            int n = Math.min(OpticalDisc.WRITE_CHUNK, data.length - pos);
            byte[] part = new byte[n];
            System.arraycopy(data, pos, part, 0, n);
            dev.write((int) (lba + pos / bs), part, n);
            pos += n;
        }
    }

    /** Formatea y copia todo. DESTRUCTIVO. */
    public void write(Progress p) throws Exception {
        // 1. borrar tablas de particiones anteriores (MBR, GPT principal y copia de seguridad)
        if (!gptMode) {
            zero(0, partStart, p);
            long total = dev.blocks;
            long tail = Math.min(34, total - partStart - 32);
            if (tail > 0) zero(total - tail, tail, p);
        }
        if (gptDisk) {
            zero(0, partStart, p);
            zero(dev.blocks - Gpt.entryBlocks(dev.blockSize) - 1, Gpt.entryBlocks(dev.blockSize) + 1, p);
        }
        zero(partStart, resv, p);

        // 2. zona de datos: carpetas y luego archivos, todo seguido
        ImageWriter w = new ImageWriter(dev, p, (int) dataStart);
        long pos = 0;
        for (int i = 0; i < dirs.size(); i++) {
            Node d = (Node) dirs.elementAt(i);
            byte[] b = dirBytes(d);
            w.write(b, 0, b.length);
            pos += b.length;
        }
        byte[] buf = new byte[32 * 2048];
        for (int i = 0; i < files.size(); i++) {
            Node f = (Node) files.elementAt(i);
            if (f.size == 0) continue;
            long off = 0;
            if (f.mem != null) {
                w.write(f.mem, 0, f.mem.length);
                off = f.size;
                pos += f.size;
            }
            while (off < f.size) {
                if (p != null && p.cancelled()) throw new Exception("Cancelado");
                int n = iso.readAt(f.src, off, buf, (int) Math.min(buf.length, f.size - off));
                if (n <= 0) throw new Exception("No pude leer " + f.name + " de la ISO (en " + off + " de " + f.size + ")");
                w.write(buf, 0, n);
                off += n;
                pos += n;
            }
            long padBytes = f.clusters * clusterBytes - f.size;
            if (padBytes > 0) {
                w.write(new byte[(int) padBytes], 0, (int) padBytes);
                pos += padBytes;
            }
        }
        w.finish();

        // 3. FAT (dos copias)
        fat = new int[(int) next];
        fat[0] = 0x0FFFFFF8;
        fat[1] = 0x0FFFFFFF;
        for (int i = 0; i < dirs.size(); i++) chain((Node) dirs.elementAt(i));
        for (int i = 0; i < files.size(); i++) chain((Node) files.elementAt(i));
        for (int copy = 0; copy < 2; copy++) {
            long start = partStart + resv + copy * fatSz;
            long bytes = fatSz * bs;
            long done = 0;
            int entry = 0;
            byte[] chunk = new byte[OpticalDisc.WRITE_CHUNK];
            while (done < bytes) {
                if (p != null && p.cancelled()) throw new Exception("Cancelado");
                int n = (int) Math.min(chunk.length, bytes - done);
                for (int i = 0; i < n; i += 4) {
                    int idx = entry++;
                    int val = idx < fat.length ? fat[idx] : 0;
                    chunk[i] = (byte) val;
                    chunk[i + 1] = (byte) (val >> 8);
                    chunk[i + 2] = (byte) (val >> 16);
                    chunk[i + 3] = (byte) (val >> 24);
                }
                byte[] part = new byte[n];
                System.arraycopy(chunk, 0, part, 0, n);
                dev.write((int) (start + done / bs), part, n);
                done += n;
            }
        }

        // 4. sector de arranque, FSInfo y copias; por último el MBR
        byte[] boot = new byte[bs];
        boot[0] = (byte) 0xEB;
        boot[1] = 0x58;
        boot[2] = (byte) 0x90;
        byte[] oem = "MSWIN4.1".getBytes();
        System.arraycopy(oem, 0, boot, 3, 8);
        put16(boot, 11, bs);
        boot[13] = (byte) spc;
        put16(boot, 14, (int) resv);
        boot[16] = 2;
        boot[21] = (byte) 0xF8;
        put16(boot, 24, 63);
        put16(boot, 26, 255);
        put32(boot, 28, partStart);
        put32(boot, 32, partBlocks);
        put32(boot, 36, fatSz);
        put32(boot, 44, 2);
        put16(boot, 48, 1);
        put16(boot, 50, 6);
        boot[64] = (byte) 0x80;
        boot[66] = 0x29;
        long volId = now & 0xFFFFFFFFL;
        put32(boot, 67, volId);
        String l = label.length() > 0 ? label : "NO NAME";
        StringBuffer lb = new StringBuffer(l);
        while (lb.length() < 11) lb.append(' ');
        for (int i = 0; i < 11; i++) boot[71 + i] = (byte) lb.charAt(i);
        byte[] ft = "FAT32   ".getBytes();
        System.arraycopy(ft, 0, boot, 82, 8);
        boot[510] = 0x55;
        boot[511] = (byte) 0xAA;

        byte[] info = new byte[bs];
        put32(info, 0, 0x41615252L);
        put32(info, 484, 0x61417272L);
        put32(info, 488, totalClusters - (next - 2));
        put32(info, 492, next);
        info[510] = 0x55;
        info[511] = (byte) 0xAA;
        info[508] = 0;
        info[509] = 0;
        put32(info, 508, 0xAA550000L);

        writeBlocks(partStart, boot);
        writeBlocks(partStart + 1, info);
        writeBlocks(partStart + 6, boot);
        writeBlocks(partStart + 7, info);

        if (gptMode) {
            if (gptDisk) {
                String nm = label.length() > 0 ? label : "DATOS";
                Gpt.write(dev, Gpt.guid(randGuid()), new long[][] { { partStart, partStart + partBlocks - 1 } },
                        new String[] { Gpt.TYPE_DATA }, new byte[][] { Gpt.guid(randGuid()) }, new String[] { nm });
            }
            dev.flush();
            return;
        }
        byte[] mbr = new byte[bs];
        put32(mbr, 440, volId);
        mbr[446] = (byte) 0x80;
        mbr[447] = (byte) 0xFE;
        mbr[448] = (byte) 0xFF;
        mbr[449] = (byte) 0xFF;
        mbr[450] = 0x0C;
        mbr[451] = (byte) 0xFE;
        mbr[452] = (byte) 0xFF;
        mbr[453] = (byte) 0xFF;
        put32(mbr, 454, partStart);
        put32(mbr, 458, partBlocks);
        mbr[510] = 0x55;
        mbr[511] = (byte) 0xAA;
        writeBlocks(0, mbr);
        dev.flush();
    }

    private void chain(Node n) {
        if (n.clusters <= 0 || n.first < 2) return;
        for (long c = n.first; c < n.first + n.clusters; c++) {
            fat[(int) c] = c == n.first + n.clusters - 1 ? 0x0FFFFFFF : (int) (c + 1);
        }
    }

    // ------------------------------------------------------------ 4. verificar

    /** Vuelve a leer el USB como FAT32 y comprueba nombres, tamaños y el principio de cada archivo. */
    public void verify(Progress p) throws Exception {
        FileSource fs = gptMode ? (FileSource) UsbVolume.tryMount(dev, partStart) : UsbVolume.mount(dev);
        if (!(fs instanceof BlockFs)) throw new Exception("La verificación no pudo reconocer el USB como FAT32");
        BlockFs b = (BlockFs) fs;
        verifyDir(b, root, b.listRoot(), "", p);
    }

    private int readFull(FileItem f, long off, byte[] dst, int len) throws Exception {
        byte[] tmp = new byte[len];
        int got = 0;
        while (got < len) {
            int n = iso.readAt(f, off + got, tmp, len - got);
            if (n <= 0) break;
            System.arraycopy(tmp, 0, dst, got, n);
            got += n;
        }
        return got;
    }

    private void verifyDir(BlockFs b, Node d, Vector listing, String path, Progress p) throws Exception {
        for (int i = 0; i < d.kids.size(); i++) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            Node c = (Node) d.kids.elementAt(i);
            FileItem found = null;
            for (int k = 0; k < listing.size(); k++) {
                FileItem it = (FileItem) listing.elementAt(k);
                if (it.name.equals(c.name)) {
                    found = it;
                    break;
                }
            }
            if (found == null) throw new Exception("Falta en el USB: " + path + "/" + c.name);
            if (found.dir != c.dir) throw new Exception("Tipo distinto en el USB: " + path + "/" + c.name);
            if (c.dir) {
                verifyDir(b, c, b.list(found), path + "/" + c.name, p);
            } else {
                if (found.size != c.size) throw new Exception("Tamaño distinto en " + path + "/" + c.name);
                if (c.size > 0 && c.mem != null) {
                    byte[] got = b.readFileRange(found, 0, (int) Math.min(c.size, 65536));
                    byte[] exp = new byte[got.length];
                    System.arraycopy(c.mem, 0, exp, 0, exp.length);
                    if (!Arrays.equals(got, exp)) throw new Exception("Contenido distinto en " + path + "/" + c.name);
                } else if (c.size > 0) {
                    int n = (int) Math.min(c.size, 65536);
                    byte[] got = b.readFileRange(found, 0, n);
                    byte[] exp = new byte[n];
                    readFull(c.src, 0, exp, n);
                    if (!Arrays.equals(got, exp)) throw new Exception("Contenido distinto en " + path + "/" + c.name);
                    if (c.size > 65536) {
                        int m = (int) Math.min(c.size - 65536, 4096);
                        long off = c.size - m;
                        byte[] g2 = b.readFileRange(found, off, m);
                        byte[] e2 = new byte[m];
                        int r = readFull(c.src, off, e2, m);
                        if (r == m && !Arrays.equals(g2, e2)) throw new Exception("Final distinto en " + path + "/" + c.name);
                    }
                }
                if (p != null) p.add(c.size);
            }
        }
    }
}
