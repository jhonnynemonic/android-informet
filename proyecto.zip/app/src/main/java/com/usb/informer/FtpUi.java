package com.usb.informer;

import java.io.File;
import java.util.Vector;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.StringItem;
import javax.microedition.lcdui.TextField;

/** Menú "Servidor FTP": publica el contenido de un USB y/o del almacenamiento del teléfono para verlo desde un PC u otro móvil. */
public class FtpUi implements CommandListener {
    private Display display;
    private UsbExtras x;
    private Displayable ret;
    private UsbDevInfo dev;
    private Form setup, status, note;
    private List modeList;
    private int[] modeIds;
    private boolean useUsb, usePhone, phoneWrite;
    private TextField fUser, fPass, fPort;
    private StringItem info;
    private Displayable noteNext;
    private Command startCmd = new Command("Iniciar servidor", Command.OK, 1);
    private Command backCmd = new Command("Atrás", Command.BACK, 1);
    private Command offCmd = new Command("\u2611 ACTIVADO (pulsa para desactivar)", Command.SCREEN, 1);
    private Command onCmd = new Command("\u2610 DESACTIVADO (pulsa para activar)", Command.SCREEN, 1);
    private Command bgCmd = new Command("Atrás (el servidor sigue activo)", Command.BACK, 2);
    private Command okCmd = new Command("Aceptar", Command.OK, 1);

    private FtpServer server;
    private OpticalDisc disc;
    private volatile boolean running;
    private volatile boolean starting;
    private String banner = "";
    private String lastUser = "", lastPass = "", lastPort = "2121";

    public FtpUi(Display d) {
        display = d;
    }

    public void setBackend(UsbExtras e) {
        x = e;
    }

    private static String msg(Throwable t) {
        String m = t.getMessage();
        return m != null && m.length() > 0 ? m : t.toString();
    }

    private void showNote(String title, String text, Displayable next) {
        note = new Form(title);
        note.append(new StringItem(null, text));
        note.addCommand(okCmd);
        note.setCommandListener(this);
        noteNext = next;
        display.setCurrent(note);
    }

    /** d puede ser null: entonces solo se ofrece publicar el teléfono. */
    public void start(UsbDevInfo d, Displayable back) {
        ret = back;
        if (running) {
            showStatus();
            return;
        }
        if (starting) return;
        dev = d;
        modeList = new List("¿Qué publicar por FTP?", Choice.IMPLICIT);
        if (d != null && x != null) {
            modeList.append("Solo el USB (" + d.label() + "), solo lectura", null);
            modeList.append("Solo el teléfono, solo lectura (ver y descargar)", null);
            modeList.append("Solo el teléfono, con escritura (subir, crear carpetas, borrar)", null);
            modeList.append("USB + teléfono, ambos solo lectura", null);
            modeList.append("USB (solo lectura) + teléfono con escritura", null);
            modeIds = new int[] {0, 1, 2, 3, 4};
        } else {
            modeList.append("El teléfono, solo lectura (ver y descargar)", null);
            modeList.append("El teléfono, con escritura (subir, crear carpetas, borrar)", null);
            modeIds = new int[] {1, 2};
        }
        modeList.addCommand(backCmd);
        modeList.setCommandListener(this);
        display.setCurrent(modeList);
    }

    private void chooseMode(int id) {
        useUsb = id == 0 || id == 3 || id == 4;
        usePhone = id != 0;
        phoneWrite = id == 2 || id == 4;
        if (useUsb && dev.needsPermission) {
            showNote("Servidor FTP", "Primero concede el permiso USB a este dispositivo (menú principal: Pedir permiso USB).", ret);
            return;
        }
        setup = new Form("Servidor FTP");
        StringBuffer sb = new StringBuffer("Se publica por Wi-Fi: ");
        if (useUsb) sb.append("el USB " + dev.label() + " (carpeta USB, solo lectura)");
        if (useUsb && usePhone) sb.append(" y ");
        if (usePhone) sb.append("el teléfono (" + (useUsb ? "carpeta Telefono, " : "") + (phoneWrite ? "con escritura: se puede subir y borrar" : "solo lectura") + ")");
        sb.append(".\n\nEl móvil y el PC deben estar en la misma red.");
        if (usePhone) sb.append(" Para ver el teléfono hace falta el permiso 'Permisos de archivos' del menú principal.");
        if (phoneWrite) sb.append("\n\nATENCIÓN: con escritura, quien se conecte puede borrar y cambiar archivos del teléfono. Usa usuario y contraseña.");
        sb.append("\n\nUsuario y contraseña: pon lo que quieras (pueden ser inventados) o deja el usuario vacío para acceso libre sin contraseña.");
        setup.append(new StringItem(null, sb.toString()));
        fUser = new TextField("Usuario (vacío = sin usuario)", lastUser, 40, TextField.ANY);
        fPass = new TextField("Contraseña", lastPass, 40, TextField.ANY);
        fPort = new TextField("Puerto (2121 por defecto)", lastPort, 5, TextField.NUMERIC);
        setup.append(fUser);
        setup.append(fPass);
        setup.append(fPort);
        setup.addCommand(startCmd);
        setup.addCommand(backCmd);
        setup.setCommandListener(this);
        display.setCurrent(setup);
    }

    private void launch() {
        final String u = fUser.getString().trim();
        final String p = fPass.getString();
        int pt = 2121;
        try { pt = Integer.parseInt(fPort.getString().trim()); } catch (Exception e) { pt = 2121; }
        if (pt < 1024 || pt > 65535) {
            showNote("Puerto", "Usa un puerto entre 1024 y 65535 (Android no permite el 21).", setup);
            return;
        }
        lastUser = u;
        lastPass = p;
        lastPort = "" + pt;
        status = null;
        doLaunch();
    }

    private void doLaunch() {
        final String u = lastUser, p = lastPass;
        int pt = 2121;
        try { pt = Integer.parseInt(lastPort); } catch (Exception e) { pt = 2121; }
        final int port = pt;
        starting = true;
        final Form busy = new Form("Servidor FTP");
        busy.append("Abriendo el USB y arrancando el servidor...");
        display.setCurrent(busy);
        new Thread(new Runnable() {
            public void run() {
                OpticalDisc o = null;
                try {
                    Vector ms = new Vector();
                    boolean multi = useUsb && usePhone;
                    if (useUsb) {
                        o = x.openDisc(dev, false);
                        FileSource fs = UsbVolume.mount(o);
                        ms.addElement(new FtpServer.Mount("USB", fs, null, false));
                    }
                    if (usePhone) {
                        File base = new File("/storage/emulated/0");
                        if (!base.exists()) base = new File("/sdcard");
                        ms.addElement(new FtpServer.Mount("Telefono", new FtpServer.PhoneSource(base), base, phoneWrite));
                    }
                    FtpServer.Mount[] arr = new FtpServer.Mount[ms.size()];
                    for (int i = 0; i < arr.length; i++) arr[i] = (FtpServer.Mount) ms.elementAt(i);
                    FtpServer s = new FtpServer(arr, u, p, port);
                    s.start();
                    disc = o;
                    server = s;
                    running = true;
                    starting = false;
                    Vector ips = FtpServer.addresses();
                    String ip = ips.size() > 0 ? (String) ips.elementAt(0) : "(IP del móvil)";
                    banner = "ftp://" + ip + ":" + s.port();
                    OpStatus.begin("Servidor FTP activo");
                    showStatus();
                    ticker(s);
                } catch (Throwable t) {
                    starting = false;
                    if (o != null) try { o.close(); } catch (Throwable e) { }
                    if (status != null) {
                        status.removeCommand(onCmd);
                        status.addCommand(onCmd);
                    }
                    showNote("Servidor FTP", "No se pudo iniciar: " + msg(t)
                            + "\n\n(Si dice que el puerto está en uso, espera unos segundos y reintenta. Si no reconoce el sistema de archivos, el USB debe ser FAT, exFAT, NTFS o ext.)",
                            status != null ? (Displayable) status : ret);
                }
            }
        }).start();
    }

    private String statusText() {
        FtpServer s = server;
        StringBuffer sb = new StringBuffer();
        if (s == null) {
            return "\u2610 SERVIDOR DESACTIVADO\n\nNo hay conexiones. Pulsa el botón \"DESACTIVADO (pulsa para activar)\" para volver a publicar con los mismos ajustes.";
        }
        sb.append("\u2611 SERVIDOR FTP ACTIVADO").append(phoneWrite && usePhone ? " (teléfono con escritura)" : " (solo lectura)").append("\n\n");
        Vector ips = FtpServer.addresses();
        if (ips.size() == 0) sb.append("No veo ninguna red Wi-Fi. Conéctate a una red o activa el punto de acceso.\n");
        for (int i = 0; i < ips.size(); i++) sb.append("Dirección: ftp://").append((String) ips.elementAt(i)).append(":").append(s.port()).append("\n");
        if (s.needsLogin()) sb.append("Usuario y contraseña: los que has puesto.\n");
        else sb.append("Acceso libre: sin usuario ni contraseña (o usuario 'anonymous').\n");
        sb.append("\nEn el PC: Explorador de Windows (escribe la dirección en la barra), FileZilla, WinSCP o un navegador.\n\n");
        sb.append(s.status());
        return sb.toString();
    }

    private void showStatus() {
        status = new Form("Servidor FTP activo");
        info = new StringItem(null, statusText());
        status.append(info);
        status.addCommand(running ? offCmd : onCmd);
        status.addCommand(bgCmd);
        status.setCommandListener(this);
        display.setCurrent(status);
    }

    private void ticker(final FtpServer s) {
        Thread t = new Thread(new Runnable() {
            public void run() {
                while (running && server == s) {
                    try {
                        info.setText(statusText());
                    } catch (Throwable e) { }
                    if (OpStatus.state == OpStatus.RUNNING && "Servidor FTP activo".equals(OpStatus.title)) {
                        OpStatus.detail(banner + "  ·  " + s.clients + " cliente(s)  ·  enviado " + Phone.sizeText(s.sent));
                    }
                    try { Thread.sleep(1000); } catch (InterruptedException e) { return; }
                }
            }
        }, "ftp-ui");
        t.setDaemon(true);
        t.start();
    }

    /** Se llama al cerrar la app o al detener. */
    public void stopServer() {
        running = false;
        FtpServer s = server;
        server = null;
        if (s != null) s.stop();
        if (disc != null) try { disc.close(); } catch (Throwable t) { }
        disc = null;
        if (OpStatus.state == OpStatus.RUNNING && "Servidor FTP activo".equals(OpStatus.title)) {
            OpStatus.end(OpStatus.OK, "servidor detenido");
        }
    }

    public boolean isRunning() {
        return running;
    }

    public void commandAction(Command c, Displayable d) {
        if (d == note) {
            display.setCurrent(noteNext != null ? noteNext : ret);
        } else if (d == modeList) {
            if (c == backCmd) display.setCurrent(ret);
            else chooseMode(modeIds[modeList.getSelectedIndex()]);
        } else if (d == setup) {
            if (c == startCmd) launch();
            else display.setCurrent(modeList);
        } else if (d == status) {
            if (c == offCmd) {
                stopServer();
                info.setText(statusText());
                status.removeCommand(offCmd);
                status.addCommand(onCmd);
            } else if (c == onCmd) {
                status.removeCommand(onCmd);
                doLaunch();
            } else {
                display.setCurrent(ret);   // el servidor sigue funcionando
            }
        }
    }
}
