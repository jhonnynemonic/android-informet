package com.usb.informer;
import java.io.OutputStream;

/** Reproduce pistas de CD de audio (leídas con READ CD) usando AudioTrack de Android. */
public class AudioPlayer implements Runnable {
    private static final String AT = "android.media.AudioTrack";

    private OpticalDisc disc;
    public final int start;
    public final int end;
    public volatile int cur;
    public volatile boolean stop;
    public volatile boolean done;
    public volatile String error;
    private Object track;

    public AudioPlayer(OpticalDisc d, int s, int e) {
        disc = d;
        start = s;
        end = e;
        cur = s;
    }

    public void begin() {
        new Thread(this).start();
    }

    public void halt() {
        stop = true;
    }

    public void run() {
        try {
            int min = AndroidBridge.num(AndroidBridge.callStatic(AT, "getMinBufferSize",
                    new Class[] { Integer.TYPE, Integer.TYPE, Integer.TYPE },
                    new Object[] { AndroidBridge.i(44100), AndroidBridge.i(12), AndroidBridge.i(2) }));
            if (min < 32768) min = 32768;
            track = Class.forName(AT).getConstructor(new Class[] { Integer.TYPE, Integer.TYPE, Integer.TYPE,
                    Integer.TYPE, Integer.TYPE, Integer.TYPE }).newInstance(new Object[] { AndroidBridge.i(3),
                    AndroidBridge.i(44100), AndroidBridge.i(12), AndroidBridge.i(2), AndroidBridge.i(min * 2),
                    AndroidBridge.i(1) });
            AndroidBridge.call0(track, AT, "play");
            int lba = start;
            while (lba < end && !stop) {
                int n = Math.min(8, end - lba);
                byte[] b = disc.readAudio(lba, n);
                AndroidBridge.call(track, AT, "write", new Class[] { byte[].class, Integer.TYPE, Integer.TYPE },
                        new Object[] { b, AndroidBridge.i(0), AndroidBridge.i(b.length) });
                lba += n;
                cur = lba;
            }
            if (stop) {
                AndroidBridge.call0(track, AT, "pause");
                AndroidBridge.call0(track, AT, "flush");
            } else {
                AndroidBridge.call0(track, AT, "stop");
                Thread.sleep(1200);
            }
        } catch (Throwable t) {
            error = t.getMessage() != null ? t.getMessage() : t.toString();
        } finally {
            try {
                if (track != null) AndroidBridge.call0(track, AT, "release");
            } catch (Throwable t) {
                // nada
            }
            done = true;
        }
    }

    /** Copia una pista a un archivo WAV (PCM 44,1 kHz, 16 bits, estéreo). */
    public static long rip(OpticalDisc d, int start, int end, OutputStream out, Progress p) throws Exception {
        long data = (long) (end - start) * 2352;
        byte[] h = new byte[44];
        put(h, 0, "RIFF");
        le32(h, 4, 36 + data);
        put(h, 8, "WAVEfmt ");
        le32(h, 16, 16);
        h[20] = 1;
        h[22] = 2;
        le32(h, 24, 44100);
        le32(h, 28, 176400);
        h[32] = 4;
        h[34] = 16;
        put(h, 36, "data");
        le32(h, 40, data);
        out.write(h);
        int lba = start;
        while (lba < end) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            int n = Math.min(8, end - lba);
            byte[] b = d.readAudio(lba, n);
            out.write(b);
            if (p != null) p.add(b.length);
            lba += n;
        }
        return data;
    }

    private static void put(byte[] b, int o, String s) {
        for (int i = 0; i < s.length(); i++) b[o + i] = (byte) s.charAt(i);
    }

    private static void le32(byte[] b, int o, long v) {
        b[o] = (byte) v;
        b[o + 1] = (byte) (v >> 8);
        b[o + 2] = (byte) (v >> 16);
        b[o + 3] = (byte) (v >> 24);
    }
}
