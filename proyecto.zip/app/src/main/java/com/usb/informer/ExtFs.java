package com.usb.informer;
import java.io.OutputStream;
import java.util.Vector;

/** ext2 / ext3 / ext4 de solo lectura (bloques con mapa o con extents). Los enlaces simbólicos se listan como "nombre -> destino". */
public class ExtFs extends BlockFs {
    private int bs, ipg, bpg, inodeSize, descSize, firstMetaBg;
    private long firstDataBlock, blocksCount;
    private int incompat, compat, roCompat;
    private String type = "ext2";
    private long freeBlocksSb;
    public int cpioFiles, cpioDirs, cpioLinks, cpioOther;
    public Vector cpioSkipped = new Vector();

    public ExtFs(OpticalDisc disc, long startLba) throws Exception {
        d = disc;
        baseBytes = startLba * disc.blockSize;
        byte[] sb = readRaw(1024, 1024);
        if (le16(sb, 0x38) != 0xEF53) throw new Exception("no es ext");
        int logBs = (int) le32(sb, 0x18);
        if (logBs > 6) throw new Exception("tamaño de bloque ext no válido");
        bs = 1024 << logBs;
        bpg = (int) le32(sb, 0x20);
        ipg = (int) le32(sb, 0x28);
        firstDataBlock = le32(sb, 0x14);
        blocksCount = le32(sb, 0x04);
        long rev = le32(sb, 0x4C);
        inodeSize = rev >= 1 ? le16(sb, 0x58) : 128;
        compat = (int) (rev >= 1 ? le32(sb, 0x5C) : 0);
        incompat = (int) (rev >= 1 ? le32(sb, 0x60) : 0);
        roCompat = (int) (rev >= 1 ? le32(sb, 0x64) : 0);
        descSize = (incompat & 0x80) != 0 ? le16(sb, 0xFE) : 32;
        if (descSize < 32) descSize = 32;
        firstMetaBg = (int) le32(sb, 0x104);
        freeBlocksSb = le32(sb, 0x0C);
        if (bpg <= 0 || ipg <= 0 || inodeSize < 128) throw new Exception("superbloque ext dañado");
        if ((incompat & 0x80) != 0) blocksCount |= le32(sb, 0x150) << 32;
        StringBuffer sbv = new StringBuffer();
        for (int i = 0; i < 16 && sb[0x78 + i] != 0; i++) sbv.append((char) (sb[0x78 + i] & 0xFF));
        if (sbv.length() > 0) vol = sbv.toString();
        boolean ext4 = (incompat & (0x40 | 0x80 | 0x200)) != 0 || (roCompat & (0x8 | 0x20 | 0x40)) != 0;
        type = ext4 ? "ext4" : (compat & 0x4) != 0 ? "ext3" : "ext2";
    }

    public String typeName() { return type; }

    // ---------------------------------------------------------------- inodos

    private static boolean hasSuper(long g) {
        if (g <= 1) return true;
        if ((g & 1) == 0) return false;
        int[] b = { 3, 5, 7 };
        for (int i = 0; i < b.length; i++) {
            long v = b[i];
            while (v < g) v *= b[i];
            if (v == g) return true;
        }
        return false;
    }

    private long gdOffset(long group) {
        int per = bs / descSize;
        long idx = group / per;
        long blk;
        if ((incompat & 0x10) != 0 && idx >= firstMetaBg) {
            long g0 = idx * per;
            blk = firstDataBlock + g0 * bpg + (hasSuper(g0) ? 1 : 0);
        } else {
            blk = firstDataBlock + 1 + idx;
        }
        return blk * bs + (group % per) * descSize;
    }

    private long inodeOffset(long ino) throws Exception {
        long g = (ino - 1) / ipg;
        long idx = (ino - 1) % ipg;
        byte[] gd = readBytes(gdOffset(g), descSize);
        long table = le32(gd, 8);
        if (descSize >= 64) table |= le32(gd, 0x28) << 32;
        return table * bs + idx * inodeSize;
    }

    private byte[] inode(long ino) throws Exception {
        return readBytes(inodeOffset(ino), 128 + 0);
    }

    private static final int ROOT = 2;

    // ---------------------------------------------------------------- mapa de bloques

    /** Construye tramos { desplazamiento, longitud } uniendo bloques contiguos; los huecos llevan desplazamiento -1. */
    private static class Runs {
        final Vector out = new Vector();
        final int bs;
        long start = -2, count;

        Runs(int bs) { this.bs = bs; }

        void add(long blk, long n, boolean hole) {
            long phys = hole || blk == 0 ? -1 : blk;
            if (count > 0 && ((phys == -1 && start == -1) || (phys >= 0 && start >= 0 && phys == start + count))) {
                count += n;
                return;
            }
            flush();
            start = phys;
            count = n;
        }

        void flush() {
            if (count > 0) out.addElement(new long[] { start < 0 ? -1 : start * bs, count * bs });
            count = 0;
            start = -2;
        }
    }

    private Vector mapRuns(byte[] ino, long size) throws Exception {
        Runs rs = new Runs(bs);
        long nblocks = (size + bs - 1) / bs;
        if (nblocks == 0) return rs.out;
        long flags = le32(ino, 0x20);
        if ((flags & 0x10000000L) != 0) throw new Exception("archivo con datos dentro del inodo (inline_data): no soportado");
        if ((flags & 0x80000L) != 0) {
            long[] pos = { 0 };
            extentNode(ino, 0x28, 60, rs, pos, nblocks, 0);
        } else {
            long[] left = { nblocks };
            for (int i = 0; i < 12 && left[0] > 0; i++) {
                rs.add(le32(ino, 0x28 + 4 * i), 1, false);
                left[0]--;
            }
            for (int lvl = 1; lvl <= 3 && left[0] > 0; lvl++) {
                indirect(le32(ino, 0x28 + 4 * (11 + lvl)), lvl, rs, left);
            }
        }
        rs.flush();
        return rs.out;
    }

    private void indirect(long blk, int level, Runs rs, long[] left) throws Exception {
        long per = bs / 4;
        if (blk == 0) {
            long span = 1;
            for (int i = 0; i < level; i++) span *= per;
            long n = Math.min(span, left[0]);
            rs.add(0, n, true);
            left[0] -= n;
            return;
        }
        byte[] b = readBytes(blk * bs, bs);
        for (int i = 0; i < per && left[0] > 0; i++) {
            long v = le32(b, 4 * i);
            if (level == 1) {
                rs.add(v, 1, false);
                left[0]--;
            } else {
                indirect(v, level - 1, rs, left);
            }
        }
    }

    private void extentNode(byte[] buf, int off, int len, Runs rs, long[] pos, long nblocks, int depthGuard) throws Exception {
        if (depthGuard > 6) throw new Exception("árbol de extents demasiado profundo");
        if (le16(buf, off) != 0xF30A) throw new Exception("extents dañados");
        int entries = le16(buf, off + 2);
        int depth = le16(buf, off + 6);
        for (int i = 0; i < entries; i++) {
            int e = off + 12 + 12 * i;
            if (e + 12 > buf.length) break;
            if (depth == 0) {
                long lblk = le32(buf, e);
                int l = le16(buf, e + 4);
                boolean uninit = l > 32768;
                if (uninit) l -= 32768;
                long phys = le32(buf, e + 8) | ((long) le16(buf, e + 6) << 32);
                if (lblk > pos[0]) rs.add(0, lblk - pos[0], true);
                rs.add(phys, l, uninit);
                pos[0] = lblk + l;
            } else {
                long leaf = le32(buf, e + 4) | ((long) le16(buf, e + 8) << 32);
                byte[] child = readBytes(leaf * bs, bs);
                extentNode(child, 0, bs, rs, pos, nblocks, depthGuard + 1);
            }
            if (pos[0] >= nblocks) break;
        }
    }

    private static long inodeSize(byte[] ino) {
        int mode = le16(ino, 0);
        long lo = le32(ino, 4);
        if ((mode & 0170000) == 0100000) return lo | (le32(ino, 0x6C) << 32);
        return lo;
    }

    protected Vector extents(FileItem f) throws Exception {
        long[] r = (long[]) f.ref;
        byte[] ino = inode(r[0]);
        return mapRuns(ino, f.size);
    }

    // ---------------------------------------------------------------- carpetas

    public Vector listRoot() throws Exception {
        return listDir(ROOT);
    }

    public Vector list(FileItem dir) throws Exception {
        return listDir(((long[]) dir.ref)[0]);
    }

    private byte[] readInodeData(byte[] ino, long limit) throws Exception {
        long size = Math.min(inodeSize(ino), limit);
        Vector runs = mapRuns(ino, size);
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        long left = size;
        for (int i = 0; i < runs.size() && left > 0; i++) {
            long[] r = (long[]) runs.elementAt(i);
            long len = Math.min(r[1], left);
            long pos = 0;
            while (pos < len) {
                int n = (int) Math.min(65536, len - pos);
                bo.write(r[0] < 0 ? new byte[n] : readRaw(r[0] + pos, n));
                pos += n;
            }
            left -= len;
        }
        return bo.toByteArray();
    }

    private static String name(byte[] b, int off, int len) {
        try { return new String(b, off, len, "UTF-8"); } catch (Exception e) { return new String(b, off, len); }
    }

    private Vector listDir(long ino) throws Exception {
        byte[] di = inode(ino);
        if ((le16(di, 0) & 0170000) != 040000) throw new Exception("no es una carpeta");
        byte[] data = readInodeData(di, 16L * 1024 * 1024);
        Vector dirs = new Vector(), files = new Vector();
        boolean ft = (incompat & 0x2) != 0;
        int pos = 0;
        while (pos + 8 <= data.length) {
            long child = le32(data, pos);
            int rec = le16(data, pos + 4);
            int nl = data[pos + 6] & 0xFF;
            if (!ft) nl |= (data[pos + 7] & 0xFF) << 8;
            if (rec < 8 || pos + rec > data.length) {
                // registro dañado: pasar al siguiente bloque
                pos = (pos / bs + 1) * bs;
                continue;
            }
            if (child != 0 && nl > 0 && pos + 8 + nl <= data.length) {
                String nm = name(data, pos + 8, nl);
                if (!nm.equals(".") && !nm.equals("..")) {
                    try {
                        FileItem it = item(nm, child);
                        if (it != null) FileItem.sortedAdd(it.dir ? dirs : files, it);
                    } catch (Throwable t) {
                        // inodo ilegible: se omite
                    }
                }
            }
            pos += rec;
        }
        for (int i = 0; i < files.size(); i++) dirs.addElement(files.elementAt(i));
        return dirs;
    }

    private FileItem item(String nm, long child) throws Exception {
        byte[] ci = inode(child);
        int mode = le16(ci, 0);
        int t = mode & 0170000;
        FileItem it = new FileItem();
        it.ref = new long[] { child };
        if (t == 040000) {
            it.name = nm;
            it.dir = true;
        } else if (t == 0100000) {
            it.name = nm;
            it.size = inodeSize(ci);
        } else if (t == 0120000) {
            long sz = le32(ci, 4);
            String target = "?";
            try {
                if (sz < 60 && le32(ci, 0x1C) == 0) target = name(ci, 0x28, (int) sz);
                else target = name(readInodeData(ci, 4096), 0, (int) Math.min(sz, 4096));
            } catch (Throwable x) {
                // destino ilegible
            }
            it.name = nm + " -> " + target;
            it.size = 0;
            it.ref = new long[] { 0 };
        } else {
            it.name = nm + " (" + (t == 020000 ? "dispositivo de caracteres" : t == 060000 ? "dispositivo de bloques" : t == 010000 ? "tubería" : "socket") + ")";
            it.size = 0;
            it.ref = new long[] { 0 };
        }
        return it;
    }

    // ---------------------------------------------------------------- exportar a initrd (cpio newc)

    /** Bytes ocupados según el superbloque (para calcular el avance). */
    public long usedBytes() {
        long used = blocksCount - freeBlocksSb;
        return used < 0 ? 0 : used * bs;
    }

    private long cpioPos;

    private static void hex8(byte[] b, int off, long v) {
        String h = Long.toHexString(v & 0xFFFFFFFFL);
        for (int i = 0; i < 8; i++) b[off + i] = (byte) '0';
        for (int i = 0; i < h.length(); i++) b[off + 8 - h.length() + i] = (byte) h.charAt(i);
    }

    private void cpioHeader(OutputStream out, String name, long ino, long mode, long uid, long gid, long nlink, long mtime,
            long size, long rmaj, long rmin) throws Exception {
        byte[] nb;
        try { nb = name.getBytes("UTF-8"); } catch (Exception e) { nb = name.getBytes(); }
        byte[] h = new byte[110];
        h[0] = '0'; h[1] = '7'; h[2] = '0'; h[3] = '7'; h[4] = '0'; h[5] = '1';
        hex8(h, 6, ino);
        hex8(h, 14, mode);
        hex8(h, 22, uid);
        hex8(h, 30, gid);
        hex8(h, 38, nlink);
        hex8(h, 46, mtime);
        hex8(h, 54, size);
        hex8(h, 62, 0);
        hex8(h, 70, 0);
        hex8(h, 78, rmaj);
        hex8(h, 86, rmin);
        hex8(h, 94, nb.length + 1);
        hex8(h, 102, 0);
        out.write(h);
        out.write(nb);
        out.write(0);
        cpioPos += 110 + nb.length + 1;
        cpioPad(out);
    }

    private void cpioPad(OutputStream out) throws Exception {
        int pad = (int) ((4 - (cpioPos & 3)) & 3);
        if (pad > 0) out.write(new byte[pad], 0, pad);
        cpioPos += pad;
    }

    /**
     * Escribe todo el contenido del sistema de archivos como un archivo cpio "newc" (el formato de los initrd de Linux),
     * con permisos, propietarios, fechas, enlaces simbólicos y nodos de dispositivo. Se omite lost+found.
     * Los enlaces duros salen como archivos independientes. El llamador comprime (gzip) si quiere.
     */
    public void exportCpio(OutputStream out, Progress p) throws Exception {
        cpioPos = 0;
        cpioFiles = cpioDirs = cpioLinks = cpioOther = 0;
        cpioSkipped.removeAllElements();
        cpioWalk(out, ROOT, "", p, 0);
        cpioHeader(out, "TRAILER!!!", 0, 0, 0, 0, 1, 0, 0, 0, 0);
        int pad = (int) ((512 - (cpioPos & 511)) & 511);
        if (pad > 0) out.write(new byte[pad], 0, pad);
    }

    private void cpioWalk(OutputStream out, long dirIno, String path, Progress p, int depth) throws Exception {
        if (depth > 64) throw new Exception("Carpetas anidadas demasiado profundas");
        byte[] di = inode(dirIno);
        byte[] data = readInodeData(di, 256L * 1024 * 1024);
        boolean ft = (incompat & 0x2) != 0;
        int pos = 0;
        while (pos + 8 <= data.length) {
            long child = le32(data, pos);
            int rec = le16(data, pos + 4);
            int nl = data[pos + 6] & 0xFF;
            if (!ft) nl |= (data[pos + 7] & 0xFF) << 8;
            if (rec < 8 || pos + rec > data.length) {
                pos = (pos / bs + 1) * bs;
                continue;
            }
            if (child != 0 && nl > 0 && pos + 8 + nl <= data.length) {
                String nm = name(data, pos + 8, nl);
                if (!nm.equals(".") && !nm.equals("..") && !(dirIno == ROOT && nm.equals("lost+found"))) {
                    if (p != null && p.cancelled()) throw new Exception("Cancelado");
                    String full = path.length() == 0 ? nm : path + "/" + nm;
                    try {
                        cpioEntry(out, child, full, p, depth);
                    } catch (Exception e) {
                        String em = e.getMessage();
                        if ("Cancelado".equals(em) || (em != null && em.startsWith("Error leyendo"))) throw e;
                        cpioSkipped.addElement(full + " (" + e.getMessage() + ")");
                    }
                }
            }
            pos += rec;
        }
    }

    private void cpioEntry(OutputStream out, long ino, String full, Progress p, int depth) throws Exception {
        byte[] ci = inode(ino);
        int mode = le16(ci, 0);
        int t = mode & 0170000;
        long uid = le16(ci, 2) | ((long) le16(ci, 0x78) << 16);
        long gid = le16(ci, 0x18) | ((long) le16(ci, 0x7A) << 16);
        long mtime = le32(ci, 16);
        if (p != null) p.file(full);
        if (t == 040000) {
            cpioHeader(out, full, ino, mode, uid, gid, 2, mtime, 0, 0, 0);
            cpioDirs++;
            cpioWalk(out, ino, full, p, depth + 1);
        } else if (t == 0100000) {
            long size = inodeSize(ci);
            if (size >= 0xFFFFFFFFL) throw new Exception("más de 4 GB, no cabe en cpio");
            FileItem f = new FileItem();
            f.name = full;
            f.size = size;
            f.ref = new long[] { ino };
            Vector runs = mapRuns(ci, size);   // falla antes de escribir nada si no se puede leer
            cpioHeader(out, full, ino, mode, uid, gid, 1, mtime, size, 0, 0);
            try {
                copy(f, out, p);
            } catch (Exception e) {
                throw new Exception("Cancelado".equals(e.getMessage()) ? "Cancelado" : "Error leyendo " + full + ": " + e.getMessage());
            }
            cpioPos += size;
            cpioPad(out);
            cpioFiles++;
        } else if (t == 0120000) {
            long sz = le32(ci, 4);
            byte[] target;
            if (sz < 60 && le32(ci, 0x1C) == 0) {
                target = new byte[(int) sz];
                System.arraycopy(ci, 0x28, target, 0, (int) sz);
            } else {
                target = readInodeData(ci, 4096);
            }
            cpioHeader(out, full, ino, mode, uid, gid, 1, mtime, target.length, 0, 0);
            out.write(target);
            cpioPos += target.length;
            cpioPad(out);
            cpioLinks++;
        } else if (t == 020000 || t == 060000) {
            long v0 = le32(ci, 0x28), v1 = le32(ci, 0x2C);
            long maj, min;
            if (v0 != 0) {
                maj = (v0 >> 8) & 0xFF;
                min = v0 & 0xFF;
            } else {
                maj = (v1 & 0xFFF00L) >> 8;
                min = (v1 & 0xFF) | ((v1 >> 12) & 0xFFF00L);
            }
            cpioHeader(out, full, ino, mode, uid, gid, 1, mtime, 0, maj, min);
            cpioOther++;
        } else if (t == 010000) {
            cpioHeader(out, full, ino, mode, uid, gid, 1, mtime, 0, 0, 0);
            cpioOther++;
        }
        // los sockets no tienen sentido en un initrd: se omiten
    }

    // ---------------------------------------------------------------- permisos (chmod +x)

    /** Se pueden cambiar permisos si no hay journal pendiente ni sumas de comprobación de inodos (ext4 metadata_csum). */
    public boolean canChmod() {
        return (incompat & 0x4) == 0 && (roCompat & 0x400) == 0;
    }

    private int modeOf(FileItem f) throws Exception {
        long ino = ((long[]) f.ref)[0];
        if (ino < 1) throw new Exception("no es un archivo del disco");
        return le16(inode(ino), 0);
    }

    /** Permisos del archivo en texto, p. ej. "rwxr-xr-x (0755)"; "" si no se pueden leer. */
    public String permText(FileItem f) {
        try {
            int m = modeOf(f);
            if ((m & 0170000) != 0100000) return "";
            StringBuffer sb = new StringBuffer();
            String rwx = "rwxrwxrwx";
            for (int i = 0; i < 9; i++) sb.append((m & (0400 >> i)) != 0 ? rwx.charAt(i) : '-');
            String o = Integer.toOctalString(m & 07777);
            while (o.length() < 4) o = "0" + o;
            return sb + " (" + o + ")";
        } catch (Throwable t) {
            return "";
        }
    }

    public boolean isExecutable(FileItem f) {
        try {
            return (modeOf(f) & 0111) != 0;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Pone (on) o quita el permiso de ejecución del propietario, grupo y otros en un archivo normal. */
    public void setExecutable(FileItem f, boolean on) throws Exception {
        if (!canChmod()) throw new Exception("Este ext tiene journal pendiente o sumas de comprobación; no se pueden cambiar permisos aquí");
        long ino = ((long[]) f.ref)[0];
        if (ino < 1) throw new Exception("no es un archivo del disco");
        long off = inodeOffset(ino);
        byte[] in = readBytes(off, 128);
        int m = le16(in, 0);
        if ((m & 0170000) != 0100000) throw new Exception("solo se puede en archivos normales");
        m = on ? (m | 0111) : (m & ~0111);
        in[0] = (byte) m;
        in[1] = (byte) (m >> 8);
        long now = System.currentTimeMillis() / 1000;
        in[12] = (byte) now;
        in[13] = (byte) (now >> 8);
        in[14] = (byte) (now >> 16);
        in[15] = (byte) (now >> 24);
        writeRaw(off, in, 128);
        if (modeOf(f) != m) throw new Exception("no se confirmó el cambio");
    }
}
