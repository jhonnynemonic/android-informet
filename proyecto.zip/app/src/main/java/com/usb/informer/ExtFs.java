package com.usb.informer;
import java.util.Vector;

/** ext2 / ext3 / ext4 de solo lectura (bloques con mapa o con extents). Los enlaces simbólicos se listan como "nombre -> destino". */
public class ExtFs extends BlockFs {
    private int bs, ipg, bpg, inodeSize, descSize, firstMetaBg;
    private long firstDataBlock, blocksCount;
    private int incompat, compat, roCompat;
    private String type = "ext2";

    public ExtFs(OpticalDisc disc, long startLba) throws Exception {
        d = disc;
        baseBytes = startLba * disc.blockSize;
        byte[] sb = readRaw(1024, 1024);
        if (le16(sb, 0x38) != 0xEF53) throw new Exception("no es ext");
        int logBs = (int) le32(sb, 0x18);
        if (logBs > 6) throw new Exception("tamaño de bloque ext no válido");
        bs = 1024 << logBs;
        bpg = (int) le32(sb, 0x20);
        ipg = (int) le32(sb, 0x28);
        firstDataBlock = le32(sb, 0x14);
        blocksCount = le32(sb, 0x04);
        long rev = le32(sb, 0x4C);
        inodeSize = rev >= 1 ? le16(sb, 0x58) : 128;
        compat = (int) (rev >= 1 ? le32(sb, 0x5C) : 0);
        incompat = (int) (rev >= 1 ? le32(sb, 0x60) : 0);
        roCompat = (int) (rev >= 1 ? le32(sb, 0x64) : 0);
        descSize = (incompat & 0x80) != 0 ? le16(sb, 0xFE) : 32;
        if (descSize < 32) descSize = 32;
        firstMetaBg = (int) le32(sb, 0x104);
        if (bpg <= 0 || ipg <= 0 || inodeSize < 128) throw new Exception("superbloque ext dañado");
        if ((incompat & 0x80) != 0) blocksCount |= le32(sb, 0x150) << 32;
        StringBuffer sbv = new StringBuffer();
        for (int i = 0; i < 16 && sb[0x78 + i] != 0; i++) sbv.append((char) (sb[0x78 + i] & 0xFF));
        if (sbv.length() > 0) vol = sbv.toString();
        boolean ext4 = (incompat & (0x40 | 0x80 | 0x200)) != 0 || (roCompat & (0x8 | 0x20 | 0x40)) != 0;
        type = ext4 ? "ext4" : (compat & 0x4) != 0 ? "ext3" : "ext2";
    }

    public String typeName() { return type; }

    // ---------------------------------------------------------------- inodos

    private static boolean hasSuper(long g) {
        if (g <= 1) return true;
        if ((g & 1) == 0) return false;
        int[] b = { 3, 5, 7 };
        for (int i = 0; i < b.length; i++) {
            long v = b[i];
            while (v < g) v *= b[i];
            if (v == g) return true;
        }
        return false;
    }

    private long gdOffset(long group) {
        int per = bs / descSize;
        long idx = group / per;
        long blk;
        if ((incompat & 0x10) != 0 && idx >= firstMetaBg) {
            long g0 = idx * per;
            blk = firstDataBlock + g0 * bpg + (hasSuper(g0) ? 1 : 0);
        } else {
            blk = firstDataBlock + 1 + idx;
        }
        return blk * bs + (group % per) * descSize;
    }

    private long inodeOffset(long ino) throws Exception {
        long g = (ino - 1) / ipg;
        long idx = (ino - 1) % ipg;
        byte[] gd = readBytes(gdOffset(g), descSize);
        long table = le32(gd, 8);
        if (descSize >= 64) table |= le32(gd, 0x28) << 32;
        return table * bs + idx * inodeSize;
    }

    private byte[] inode(long ino) throws Exception {
        return readBytes(inodeOffset(ino), 128 + 0);
    }

    private static final int ROOT = 2;

    // ---------------------------------------------------------------- mapa de bloques

    /** Construye tramos { desplazamiento, longitud } uniendo bloques contiguos; los huecos llevan desplazamiento -1. */
    private static class Runs {
        final Vector out = new Vector();
        final int bs;
        long start = -2, count;

        Runs(int bs) { this.bs = bs; }

        void add(long blk, long n, boolean hole) {
            long phys = hole || blk == 0 ? -1 : blk;
            if (count > 0 && ((phys == -1 && start == -1) || (phys >= 0 && start >= 0 && phys == start + count))) {
                count += n;
                return;
            }
            flush();
            start = phys;
            count = n;
        }

        void flush() {
            if (count > 0) out.addElement(new long[] { start < 0 ? -1 : start * bs, count * bs });
            count = 0;
            start = -2;
        }
    }

    private Vector mapRuns(byte[] ino, long size) throws Exception {
        Runs rs = new Runs(bs);
        long nblocks = (size + bs - 1) / bs;
        if (nblocks == 0) return rs.out;
        long flags = le32(ino, 0x20);
        if ((flags & 0x10000000L) != 0) throw new Exception("archivo con datos dentro del inodo (inline_data): no soportado");
        if ((flags & 0x80000L) != 0) {
            long[] pos = { 0 };
            extentNode(ino, 0x28, 60, rs, pos, nblocks, 0);
        } else {
            long[] left = { nblocks };
            for (int i = 0; i < 12 && left[0] > 0; i++) {
                rs.add(le32(ino, 0x28 + 4 * i), 1, false);
                left[0]--;
            }
            for (int lvl = 1; lvl <= 3 && left[0] > 0; lvl++) {
                indirect(le32(ino, 0x28 + 4 * (11 + lvl)), lvl, rs, left);
            }
        }
        rs.flush();
        return rs.out;
    }

    private void indirect(long blk, int level, Runs rs, long[] left) throws Exception {
        long per = bs / 4;
        if (blk == 0) {
            long span = 1;
            for (int i = 0; i < level; i++) span *= per;
            long n = Math.min(span, left[0]);
            rs.add(0, n, true);
            left[0] -= n;
            return;
        }
        byte[] b = readBytes(blk * bs, bs);
        for (int i = 0; i < per && left[0] > 0; i++) {
            long v = le32(b, 4 * i);
            if (level == 1) {
                rs.add(v, 1, false);
                left[0]--;
            } else {
                indirect(v, level - 1, rs, left);
            }
        }
    }

    private void extentNode(byte[] buf, int off, int len, Runs rs, long[] pos, long nblocks, int depthGuard) throws Exception {
        if (depthGuard > 6) throw new Exception("árbol de extents demasiado profundo");
        if (le16(buf, off) != 0xF30A) throw new Exception("extents dañados");
        int entries = le16(buf, off + 2);
        int depth = le16(buf, off + 6);
        for (int i = 0; i < entries; i++) {
            int e = off + 12 + 12 * i;
            if (e + 12 > buf.length) break;
            if (depth == 0) {
                long lblk = le32(buf, e);
                int l = le16(buf, e + 4);
                boolean uninit = l > 32768;
                if (uninit) l -= 32768;
                long phys = le32(buf, e + 8) | ((long) le16(buf, e + 6) << 32);
                if (lblk > pos[0]) rs.add(0, lblk - pos[0], true);
                rs.add(phys, l, uninit);
                pos[0] = lblk + l;
            } else {
                long leaf = le32(buf, e + 4) | ((long) le16(buf, e + 8) << 32);
                byte[] child = readBytes(leaf * bs, bs);
                extentNode(child, 0, bs, rs, pos, nblocks, depthGuard + 1);
            }
            if (pos[0] >= nblocks) break;
        }
    }

    private static long inodeSize(byte[] ino) {
        int mode = le16(ino, 0);
        long lo = le32(ino, 4);
        if ((mode & 0170000) == 0100000) return lo | (le32(ino, 0x6C) << 32);
        return lo;
    }

    protected Vector extents(FileItem f) throws Exception {
        long[] r = (long[]) f.ref;
        byte[] ino = inode(r[0]);
        return mapRuns(ino, f.size);
    }

    // ---------------------------------------------------------------- carpetas

    public Vector listRoot() throws Exception {
        return listDir(ROOT);
    }

    public Vector list(FileItem dir) throws Exception {
        return listDir(((long[]) dir.ref)[0]);
    }

    private byte[] readInodeData(byte[] ino, long limit) throws Exception {
        long size = Math.min(inodeSize(ino), limit);
        Vector runs = mapRuns(ino, size);
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        long left = size;
        for (int i = 0; i < runs.size() && left > 0; i++) {
            long[] r = (long[]) runs.elementAt(i);
            long len = Math.min(r[1], left);
            long pos = 0;
            while (pos < len) {
                int n = (int) Math.min(65536, len - pos);
                bo.write(r[0] < 0 ? new byte[n] : readRaw(r[0] + pos, n));
                pos += n;
            }
            left -= len;
        }
        return bo.toByteArray();
    }

    private static String name(byte[] b, int off, int len) {
        try { return new String(b, off, len, "UTF-8"); } catch (Exception e) { return new String(b, off, len); }
    }

    private Vector listDir(long ino) throws Exception {
        byte[] di = inode(ino);
        if ((le16(di, 0) & 0170000) != 040000) throw new Exception("no es una carpeta");
        byte[] data = readInodeData(di, 16L * 1024 * 1024);
        Vector dirs = new Vector(), files = new Vector();
        boolean ft = (incompat & 0x2) != 0;
        int pos = 0;
        while (pos + 8 <= data.length) {
            long child = le32(data, pos);
            int rec = le16(data, pos + 4);
            int nl = data[pos + 6] & 0xFF;
            if (!ft) nl |= (data[pos + 7] & 0xFF) << 8;
            if (rec < 8 || pos + rec > data.length) {
                // registro dañado: pasar al siguiente bloque
                pos = (pos / bs + 1) * bs;
                continue;
            }
            if (child != 0 && nl > 0 && pos + 8 + nl <= data.length) {
                String nm = name(data, pos + 8, nl);
                if (!nm.equals(".") && !nm.equals("..")) {
                    try {
                        FileItem it = item(nm, child);
                        if (it != null) FileItem.sortedAdd(it.dir ? dirs : files, it);
                    } catch (Throwable t) {
                        // inodo ilegible: se omite
                    }
                }
            }
            pos += rec;
        }
        for (int i = 0; i < files.size(); i++) dirs.addElement(files.elementAt(i));
        return dirs;
    }

    private FileItem item(String nm, long child) throws Exception {
        byte[] ci = inode(child);
        int mode = le16(ci, 0);
        int t = mode & 0170000;
        FileItem it = new FileItem();
        it.ref = new long[] { child };
        if (t == 040000) {
            it.name = nm;
            it.dir = true;
        } else if (t == 0100000) {
            it.name = nm;
            it.size = inodeSize(ci);
        } else if (t == 0120000) {
            long sz = le32(ci, 4);
            String target = "?";
            try {
                if (sz < 60 && le32(ci, 0x1C) == 0) target = name(ci, 0x28, (int) sz);
                else target = name(readInodeData(ci, 4096), 0, (int) Math.min(sz, 4096));
            } catch (Throwable x) {
                // destino ilegible
            }
            it.name = nm + " -> " + target;
            it.size = 0;
            it.ref = new long[] { 0 };
        } else {
            it.name = nm + " (" + (t == 020000 ? "dispositivo de caracteres" : t == 060000 ? "dispositivo de bloques" : t == 010000 ? "tubería" : "socket") + ")";
            it.size = 0;
            it.ref = new long[] { 0 };
        }
        return it;
    }
}
