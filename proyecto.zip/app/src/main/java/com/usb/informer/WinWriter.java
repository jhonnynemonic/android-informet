package com.usb.informer;
import java.io.InputStream;

/**
 * Pendrive de instalación de Windows en dos particiones sobre disco GPT:
 *  1) FAT32 normal (~1 GB, tipo datos básicos, no EFI) con las carpetas EFI y boot y el BCD que apunta a la segunda partición;
 *  2) exFAT (el resto) con la ISO COMPLETA (boot, efi, sources, setup.exe...), incluido el install.wim de más de 4 GB.
 */
public class WinWriter {
    public static final String DISK_GUID = "bda60898-76ec-434a-9f12-73a00d8584aa";
    public static final String NTFS_GUID = "a4da04f7-7f1d-4a27-b9c9-eaeebc3f5a9b";
    public static final String FAT_GUID = "5f3a1c20-8b7e-4d19-a0c4-62e1b9d70f31";

    public long fatBytes = 1024L * 1024 * 1024;
    public String fatLabel = "WINBOOT";
    public String ntfsLabel = "WINSETUP";
    public boolean hasBootWim, hasEfi, hasInstall;

    private DiscTree tree;
    private OpticalDisc dev;
    private FatWriter fat;
    private ExFatWriter ntfs;   // (nombre histórico: ahora la segunda partición es exFAT)
    private byte[] bcd;
    private long fatStart, fatBlocks, ntfsStart, ntfsBlocks;

    public WinWriter(DiscTree tree, OpticalDisc dev, byte[] bcd) {
        this.tree = tree;
        this.dev = dev;
        this.bcd = bcd;
        String mb = System.getProperty("usbinformer.fatmb");
        if (mb != null) fatBytes = Long.parseLong(mb) * 1024 * 1024;
    }

    public static byte[] loadBcd() {
        try {
            InputStream in = WinWriter.class.getResourceAsStream("/bcd.bin");
            if (in == null) return null;
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            in.close();
            return o.toByteArray();
        } catch (Throwable t) {
            return null;
        }
    }

    public int fileCount() { return fat.fileCount() + ntfs.fileCount(); }

    public long fileBytes() { return fat.fileBytes + ntfs.fileBytes; }

    public long fatFiles() { return fat.fileCount(); }

    public long ntfsFiles() { return ntfs.fileCount(); }

    public long fatBytesUsed() { return fat.fileBytes; }

    public long ntfsBytesUsed() { return ntfs.fileBytes; }

    public long dataBytes() { return fat.dataBytes() + ntfs.dataBytes(); }

    public java.util.Vector skipped() {
        java.util.Vector v = new java.util.Vector();
        for (int i = 0; i < fat.skipped.size(); i++) v.addElement(fat.skipped.elementAt(i));
        for (int i = 0; i < ntfs.skipped.size(); i++) v.addElement(ntfs.skipped.elementAt(i));
        return v;
    }

    public long ntfsCapacity() { return ntfsBlocks * dev.blockSize; }

    public void scan(Progress p) throws Exception {
        String[] boot = { "EFI", "boot" };
        fat = new FatWriter(tree, dev);
        fat.setOnly(boot);
        fat.setOnlyPaths(new String[] { "sources/boot.wim" });   // boot.wim también en el FAT32: el arranque no depende de leer exFAT
        fat.scan(p);
        // el FAT32 crece si boot.wim + EFI + boot no caben en el tamaño por defecto
        long need = (fat.fileBytes + 64L * 1024 * 1024 + 64L * 1024 * 1024 - 1) / (64L * 1024 * 1024) * (64L * 1024 * 1024);
        if (need > fatBytes) fatBytes = need;
        ntfs = new ExFatWriter(tree, dev, 0, 0, ntfsLabel);
        // la NTFS lleva la ISO COMPLETA (también EFI y boot): el arranque de Windows busca \boot en la NTFS
        ntfs.scan(p);
        java.util.Vector top = tree.listRoot();
        for (int i = 0; i < top.size(); i++) {
            FileItem it = (FileItem) top.elementAt(i);
            if (it.dir && it.name.equalsIgnoreCase("sources")) {
                java.util.Vector s = tree.list(it);
                for (int k = 0; k < s.size(); k++) {
                    String n = ((FileItem) s.elementAt(k)).name.toLowerCase();
                    if (n.equals("boot.wim")) hasBootWim = true;
                    if (n.equals("install.wim") || n.equals("install.esd") || n.equals("install.swm")) hasInstall = true;
                }
            }
        }
        hasEfi = fat.hasEfi;
    }

    public void layout() throws Exception {
        int bs = dev.blockSize;
        long total = dev.blocks;
        long align = (1024 * 1024) / bs;
        fatStart = Math.max(align, Gpt.firstUsable(bs));
        fatStart = (fatStart + align - 1) / align * align;
        fatBlocks = fatBytes / bs / align * align;
        ntfsStart = fatStart + fatBlocks;
        long last = Gpt.lastUsable(total, bs);
        ntfsBlocks = (last - ntfsStart + 1) / align * align;
        if (ntfsBlocks < (256L * 1024 * 1024) / bs) throw new Exception("El USB es demasiado pequeño para este esquema");
        fat.label = fatLabel;
        fat.setPartition(fatStart, fatBlocks);
        if (bcd != null) {
            // el BCD apunta ahora a la partición FAT32 (boot.wim y boot.sdi están ahí): se cambia el GUID de partición
            bcd = patchBcd(bcd);
            fat.putFile("EFI/Microsoft/Boot/BCD", bcd);
            fat.putFile("Boot/BCD", bcd);
        }
        fat.layout();
        ntfs = rebuildNtfs();
        ntfs.layout();
    }

    /** Sustituye en el BCD el GUID de la partición de datos por el de la partición FAT32. */
    private static byte[] patchBcd(byte[] src) {
        byte[] from = Gpt.guid(NTFS_GUID), to = Gpt.guid(FAT_GUID);
        byte[] b = new byte[src.length];
        System.arraycopy(src, 0, b, 0, src.length);
        for (int i = 0; i + 16 <= b.length; i++) {
            boolean eq = true;
            for (int k = 0; k < 16 && eq; k++) if (b[i + k] != from[k]) eq = false;
            if (eq) {
                System.arraycopy(to, 0, b, i, 16);
                i += 15;
            }
        }
        return b;
    }

    private ExFatWriter rebuildNtfs() throws Exception {
        ntfs.setGeometry(ntfsStart, ntfsBlocks, ntfsLabel);
        return ntfs;
    }

    private void zero(long lba, long blocks, Progress p) throws Exception {
        byte[] z = new byte[OpticalDisc.WRITE_CHUNK];
        int per = z.length / dev.blockSize;
        long done = 0;
        while (done < blocks) {
            if (p != null && p.cancelled()) throw new Exception("Cancelado");
            int n = (int) Math.min(per, blocks - done);
            dev.write((int) (lba + done), z, n * dev.blockSize);
            done += n;
        }
    }

    public void write(Progress p) throws Exception {
        int bs = dev.blockSize;
        fat.label = fatLabel;
        ntfs.setGeometry(ntfsStart, ntfsBlocks, ntfsLabel);
        zero(0, fatStart, p);
        zero(dev.blocks - Gpt.entryBlocks(bs) - 1, Gpt.entryBlocks(bs) + 1, p);
        fat.write(p);
        ntfs.write(p);
        Gpt.write(dev, Gpt.guid(DISK_GUID),
                new long[][] { { fatStart, fatStart + fatBlocks - 1 }, { ntfsStart, ntfsStart + ntfsBlocks - 1 } },
                new String[] { Gpt.TYPE_DATA, Gpt.TYPE_DATA },   // FAT32 normal (datos básicos), no partición de sistema EFI
                new byte[][] { Gpt.guid(FAT_GUID), Gpt.guid(NTFS_GUID) },
                new String[] { fatLabel, ntfsLabel });
    }

    public void verify(Progress p) throws Exception {
        fat.verify(p);
        ntfs.verify(p);
    }
}
