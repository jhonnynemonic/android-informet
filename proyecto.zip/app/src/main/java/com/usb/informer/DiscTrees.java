package com.usb.informer;
/** Elige el sistema de archivos útil de una ISO: UDF (Windows) o ISO9660/Joliet. */
public class DiscTrees {
    public static DiscTree open(Sectors s) throws Exception {
        Exception udfErr = null;
        if (UdfDisc.present(s)) {
            try {
                UdfDisc u = new UdfDisc(s);
                u.listRoot();
                return u;
            } catch (Exception e) {
                udfErr = e;
            }
        }
        try {
            return new IsoDisc(s);
        } catch (Exception e) {
            if (udfErr != null) throw udfErr;
            throw e;
        }
    }
}
