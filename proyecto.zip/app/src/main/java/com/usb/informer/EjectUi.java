package com.usb.informer;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.StringItem;
import java.util.Vector;

/** Expulsar / quitar con seguridad un USB o un CD/DVD. */
public class EjectUi implements CommandListener {
    private Display display;
    private UsbExtras x;
    private Displayable ret;
    private UsbDevInfo dev;
    private Runnable done;   // se ejecuta al volver (para refrescar la lista de unidades)
    private Form form, result;
    private Command backCmd = new Command("Atrás", Command.BACK, 1);
    private Command ejectCmd = new Command("Expulsar ahora", Command.OK, 1);
    private Command settingsCmd = new Command("Ajustes de almacenamiento", Command.SCREEN, 2);
    private Command okCmd = new Command("Aceptar", Command.OK, 1);

    public EjectUi(Display d) {
        display = d;
    }

    public void setBackend(UsbExtras e) {
        x = e;
    }

    public void start(UsbDevInfo d, Displayable back) {
        start(d, back, null);
    }

    /** Expulsa una a una todas las unidades de la lista (hub con varios puertos). */
    public void startAll(final Vector devs, Displayable back, Runnable after) {
        if (x == null) return;
        ret = back;
        done = after;
        OpStatus.begin("Expulsando todas las unidades (" + devs.size() + ")");
        final Form busy = new Form("Expulsando todo");
        busy.append("Sincronizando y deteniendo " + devs.size() + " unidades...");
        display.setCurrent(busy);
        new Thread(new Runnable() {
            public void run() {
                StringBuffer sb = new StringBuffer();
                for (int i = 0; i < devs.size(); i++) {
                    UsbDevInfo d = (UsbDevInfo) devs.elementAt(i);
                    sb.append((i + 1) + ". " + d.label() + ": ");
                    if (d.needsPermission) {
                        sb.append("falta el permiso USB\n");
                        continue;
                    }
                    OpticalDisc o = null;
                    try {
                        o = x.openDisc(d, d.optical);
                        String err = o.eject(d.optical);
                        o.close();
                        sb.append(err != null ? err : "listo, ya puedes quitarlo").append("\n");
                    } catch (Throwable t) {
                        if (o != null) o.close();
                        sb.append("no se pudo: " + (t.getMessage() != null ? t.getMessage() : t.toString())).append("\n");
                    }
                }
                OpStatus.end(OpStatus.OK, "desconecta las unidades");
                show("Expulsar todo", sb.toString() + "\nDesconecta ahora las unidades (si las dejas, Android puede volver a montarlas).");
            }
        }).start();
    }

    public void start(UsbDevInfo d, Displayable back, Runnable after) {
        if (x == null) return;
        dev = d;
        ret = back;
        done = after;
        form = new Form("Expulsar " + d.label());
        String t;
        if (d.optical) {
            t = "Se sincronizará la unidad y se abrirá la bandeja del CD/DVD.";
        } else {
            t = "Antes de expulsar, asegúrate de que ninguna app está copiando archivos desde o hacia este USB.\n\n"
                    + "'Expulsar ahora' vacía la caché del USB, lo detiene y permite quitarlo. Android lo desmonta "
                    + "al tomar el control de la unidad.\n\n"
                    + "Si Android lo tiene montado y usado por otras apps, es más seguro usar "
                    + "'Ajustes de almacenamiento' y pulsar Expulsar allí.";
        }
        form.append(new StringItem(null, t));
        if (d.needsPermission) {
            form.append(new StringItem(null, "\nFalta el permiso USB: usa antes 'Pedir permiso USB' en el menú principal."));
        } else {
            form.addCommand(ejectCmd);
        }
        if (!d.optical) form.addCommand(settingsCmd);
        form.addCommand(backCmd);
        form.setCommandListener(this);
        display.setCurrent(form);
    }

    private void show(String title, String text) {
        result = new Form(title);
        result.append(new StringItem(null, text));
        result.addCommand(okCmd);
        result.setCommandListener(this);
        display.setCurrent(result);
    }

    private void doEject() {
        OpStatus.begin("Expulsando " + dev.label());
        final Form busy = new Form("Expulsando");
        busy.append("Sincronizando y deteniendo...");
        display.setCurrent(busy);
        new Thread(new Runnable() {
            public void run() {
                OpticalDisc o = null;
                try {
                    o = x.openDisc(dev, dev.optical);
                    String err = o.eject(dev.optical);
                    o.close();
                    OpStatus.end(err != null ? OpStatus.FAIL : OpStatus.OK, err != null ? err : "ya puedes desconectarlo");
                    if (err != null) show("Expulsar", err + "\n\nSi no hay ninguna app usándolo, ya puedes desconectarlo.");
                    else show("Expulsar", dev.optical ? "Listo: bandeja abierta. Si no se abrió, pulsa el botón de la unidad."
                            : "Listo: ya puedes desconectar el USB con seguridad. Desconéctalo ahora (si lo dejas, Android puede volver a montarlo).");
                } catch (Throwable t) {
                    if (o != null) o.close();
                    String m = t.getMessage() != null ? t.getMessage() : t.toString();
                    OpStatus.end(OpStatus.FAIL, m);
                    show("Expulsar", "No se pudo: " + m);
                }
            }
        }).start();
    }

    public void commandAction(Command c, Displayable d) {
        if (d == form) {
            if (c == backCmd) display.setCurrent(ret);
            else if (c == ejectCmd) doEject();
            else if (c == settingsCmd) {
                String err = x.openStorageSettings();
                if (err != null) show("Ajustes", err);
            }
        } else if (d == result) {
            display.setCurrent(ret);
            if (done != null) done.run();
        }
    }
}
