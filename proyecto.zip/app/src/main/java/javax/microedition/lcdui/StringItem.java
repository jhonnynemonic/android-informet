package javax.microedition.lcdui;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.TextView;

public class StringItem extends Item {
    private volatile String text;
    private volatile TextView view;

    public StringItem(String label, String text) { setLabel(label); this.text = text; }
    public String getText() { return text; }

    public void setText(String t) {
        text = t;
        final TextView v = view;
        if (v != null) {
            final String shown = compose();
            UiHost.runUi(new Runnable() { public void run() { v.setText(shown); } });
        }
    }

    private String compose() {
        String l = getLabel();
        String t = text == null ? "" : text;
        return (l != null && l.length() > 0) ? l + "\n" + t : t;
    }

    View createView(Context c) {
        TextView v = new TextView(c);
        v.setTextColor(Color.WHITE);
        v.setTextSize(15);
        int p = UiHost.dp(6);
        v.setPadding(p, p, p, p);
        v.setTextIsSelectable(true);
        v.setText(compose());
        view = v;
        return v;
    }
}
