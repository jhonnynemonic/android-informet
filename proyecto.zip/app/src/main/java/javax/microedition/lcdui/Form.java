package javax.microedition.lcdui;

import java.util.Vector;

public class Form extends Screen {
    final Vector items = new Vector();

    public Form(String title) { setTitle(title); }

    public int append(Item i) {
        int n;
        synchronized (items) { items.addElement(i); n = items.size() - 1; }
        i.owner = this;
        UiHost.refresh(this);
        return n;
    }
    public int append(String s) { return append(new StringItem(null, s)); }
    public Item get(int i) { synchronized (items) { return (Item) items.elementAt(i); } }
    public void delete(int i) { synchronized (items) { items.removeElementAt(i); } UiHost.refresh(this); }
    public void deleteAll() { synchronized (items) { items.removeAllElements(); } UiHost.refresh(this); }
    public int size() { synchronized (items) { return items.size(); } }
}
