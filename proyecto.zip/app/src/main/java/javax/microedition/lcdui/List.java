package javax.microedition.lcdui;

import java.util.Vector;

public class List extends Screen implements Choice {
    public static final Command SELECT_COMMAND = new Command("", Command.SCREEN, 0);
    final Vector items = new Vector();
    private volatile int sel;
    private final int type;

    public List(String title, int type) { setTitle(title); this.type = type; }

    public int append(String s, Image i) {
        int n;
        synchronized (items) { items.addElement(s); n = items.size() - 1; }
        UiHost.refresh(this);
        return n;
    }
    public int size() { synchronized (items) { return items.size(); } }
    public String getString(int i) { synchronized (items) { return (String) items.elementAt(i); } }
    public void set(int i, String s, Image img) { synchronized (items) { items.setElementAt(s, i); } UiHost.refresh(this); }
    public void delete(int i) { synchronized (items) { items.removeElementAt(i); } UiHost.refresh(this); }
    public int getSelectedIndex() { return sel; }
    public void setSelectedIndex(int i, boolean b) { sel = i; }
    public void deleteAll() { synchronized (items) { items.removeAllElements(); } sel = 0; UiHost.refresh(this); }
    void select(int i) { sel = i; }
}
