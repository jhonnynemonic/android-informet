package javax.microedition.lcdui;

import android.content.Context;
import android.graphics.Color;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class TextField extends Item {
    public static final int ANY = 0;
    public static final int EMAILADDR = 1;
    public static final int NUMERIC = 2;
    public static final int PHONENUMBER = 3;
    public static final int URL = 4;
    public static final int PASSWORD = 0x10000;

    private volatile String text;
    private final int maxSize, constraints;
    private volatile EditText edit;

    public TextField(String label, String text, int maxSize, int constraints) {
        setLabel(label);
        this.text = text == null ? "" : text;
        this.maxSize = maxSize;
        this.constraints = constraints;
    }

    public String getString() { return text; }
    public int getMaxSize() { return maxSize; }

    public void setString(String s) {
        text = s == null ? "" : s;
        final EditText e = edit;
        if (e != null) {
            final String v = text;
            UiHost.runUi(new Runnable() { public void run() { if (!e.getText().toString().equals(v)) e.setText(v); } });
        }
    }

    View createView(Context c) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = UiHost.dp(6);
        box.setPadding(p, p, p, p);
        if (getLabel() != null && getLabel().length() > 0) {
            TextView l = new TextView(c);
            l.setText(getLabel());
            l.setTextColor(Color.rgb(170, 190, 210));
            l.setTextSize(13);
            box.addView(l, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }
        final EditText e = new EditText(c);
        e.setTextColor(Color.WHITE);
        e.setTextSize(16);
        int base = constraints & 0xFFFF;
        int type;
        if (base == NUMERIC || base == PHONENUMBER) type = InputType.TYPE_CLASS_NUMBER;
        else if (base == URL) type = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI;
        else if (base == EMAILADDR) type = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS;
        else type = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
        if ((constraints & PASSWORD) != 0) type = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD;
        e.setInputType(type);
        if (maxSize > 0) e.setFilters(new InputFilter[] { new InputFilter.LengthFilter(maxSize) });
        e.setText(text);
        e.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int d) {}
            public void onTextChanged(CharSequence s, int a, int b, int d) {}
            public void afterTextChanged(Editable s) { text = s.toString(); }
        });
        edit = e;
        box.addView(e, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return box;
    }
}
