package javax.microedition.lcdui;

import java.util.Vector;

public abstract class Displayable {
    final Vector cmds = new Vector();
    volatile CommandListener listener;
    private volatile String title;

    public void setTitle(String s) { title = s; UiHost.refresh(this); }
    public String getTitle() { return title; }
    public void addCommand(Command c) {
        synchronized (cmds) { if (!cmds.contains(c)) cmds.addElement(c); }
        UiHost.refresh(this);
    }
    public void removeCommand(Command c) {
        synchronized (cmds) { cmds.removeElement(c); }
        UiHost.refresh(this);
    }
    public void setCommandListener(CommandListener l) { listener = l; }
    public boolean isShown() { return UiHost.getCurrent() == this; }
}
