package javax.microedition.lcdui;

import android.content.Context;
import android.view.View;

public abstract class Item {
    private volatile String label;
    Form owner;
    public String getLabel() { return label; }
    public void setLabel(String l) { label = l; if (owner != null) UiHost.refresh(owner); }
    /** Crea la vista de Android de este elemento. Se llama en el hilo de la interfaz. */
    abstract View createView(Context c);
}
