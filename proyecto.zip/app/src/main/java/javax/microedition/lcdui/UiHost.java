package javax.microedition.lcdui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Dibuja las pantallas del MIDlet (Form, List, Alert, Command) con vistas de Android.
 * Los comandos y callSerially se ejecutan en un hilo propio (como el hilo de eventos de MIDP),
 * así el código que bloquea (red, USB) no corre en el hilo principal de Android.
 */
public final class UiHost {
    private static final int BG = Color.rgb(18, 20, 24);
    private static final int BAR = Color.rgb(38, 46, 58);

    private static Activity act;
    private static final Handler UI = new Handler(Looper.getMainLooper());
    private static final ExecutorService EVENTS = Executors.newSingleThreadExecutor(new ThreadFactory() {
        public Thread newThread(Runnable r) { Thread t = new Thread(r, "midlet-events"); t.setDaemon(true); return t; }
    });
    private static volatile Displayable current;
    private static volatile Displayable beforeAlert;
    private static AlertDialog dialog;
    private static final AtomicBoolean pending = new AtomicBoolean();
    private static float density = 1f;

    private UiHost() {}

    // ---------- ciclo de vida ----------

    public static void attach(Activity a) {
        act = a;
        density = a.getResources().getDisplayMetrics().density;
        final Displayable d = current;
        if (d != null) render(d);
    }

    public static void exit() {
        runUi(new Runnable() { public void run() { if (act != null) act.finish(); } });
    }

    public static int dp(int v) { return (int) (v * density + 0.5f); }

    public static Displayable getCurrent() { return current; }

    public static void runUi(Runnable r) {
        if (Looper.myLooper() == Looper.getMainLooper()) r.run(); else UI.post(r);
    }

    public static void events(Runnable r) { EVENTS.execute(r); }

    // ---------- cambio de pantalla ----------

    static void setCurrent(final Displayable d, final Displayable next) {
        if (d == null) return;
        if (d instanceof Alert) {
            final Displayable back = next != null ? next : (current instanceof Alert ? beforeAlert : current);
            beforeAlert = back;
            current = d;
            runUi(new Runnable() { public void run() { showAlert((Alert) d, back); } });
        } else {
            current = d;
            runUi(new Runnable() { public void run() { render(d); } });
        }
    }

    /** Pide redibujar la pantalla actual (se agrupan varias peticiones seguidas). */
    static void refresh(Displayable d) {
        if (d != current || d instanceof Alert || act == null) return;
        if (pending.compareAndSet(false, true)) {
            UI.post(new Runnable() {
                public void run() {
                    pending.set(false);
                    Displayable c = current;
                    if (c != null && !(c instanceof Alert)) render(c);
                }
            });
        }
    }

    // ---------- dibujo ----------

    private static void fire(final Displayable d, final Command c) {
        final CommandListener l = d.listener;
        if (l == null) return;
        EVENTS.execute(new Runnable() {
            public void run() {
                try { l.commandAction(c, d); } catch (Throwable t) { t.printStackTrace(); }
            }
        });
    }

    private static void render(final Displayable d) {
        if (act == null) return;
        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                v.setPadding(in.getSystemWindowInsetLeft(), in.getSystemWindowInsetTop(),
                        in.getSystemWindowInsetRight(), in.getSystemWindowInsetBottom());
                return in;
            }
        });

        TextView title = new TextView(act);
        title.setText(d.getTitle() == null ? "" : d.getTitle());
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setBackgroundColor(BAR);
        int p = dp(12);
        title.setPadding(p, p, p, p);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View body;
        if (d instanceof List) body = listView((List) d);
        else if (d instanceof Form) body = formView((Form) d);
        else body = new View(act);
        root.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        View bar = commandBar(d);
        if (bar != null) root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        act.setContentView(root);
        root.requestApplyInsets();
    }

    private static View formView(Form f) {
        ScrollView sv = new ScrollView(act);
        LinearLayout col = new LinearLayout(act);
        col.setOrientation(LinearLayout.VERTICAL);
        ArrayList copy;
        synchronized (f.items) { copy = new ArrayList(f.items); }
        for (int i = 0; i < copy.size(); i++) {
            Item it = (Item) copy.get(i);
            col.addView(it.createView(act), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        sv.addView(col, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sv.setFillViewport(false);
        return sv;
    }

    private static View listView(final List l) {
        final ArrayList copy;
        synchronized (l.items) { copy = new ArrayList(l.items); }
        ListView lv = new ListView(act);
        lv.setAdapter(new BaseAdapter() {
            public int getCount() { return copy.size(); }
            public Object getItem(int i) { return copy.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View old, ViewGroup parent) {
                TextView t = old instanceof TextView ? (TextView) old : new TextView(act);
                t.setText((String) copy.get(i));
                t.setTextColor(Color.WHITE);
                t.setTextSize(16);
                int p = dp(14);
                t.setPadding(p, p, p, p);
                return t;
            }
        });
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int pos, long id) {
                l.select(pos);
                fire(l, List.SELECT_COMMAND);
            }
        });
        int sel = l.getSelectedIndex();
        if (sel > 0 && sel < copy.size()) lv.setSelection(sel);
        return lv;
    }

    private static View commandBar(final Displayable d) {
        ArrayList cs;
        synchronized (d.cmds) { cs = new ArrayList(d.cmds); }
        if (cs.isEmpty()) return null;
        Collections.sort(cs, new Comparator() {
            public int compare(Object a, Object b) {
                Command x = (Command) a, y = (Command) b;
                int bx = isBack(x) ? 1 : 0, by = isBack(y) ? 1 : 0;
                if (bx != by) return bx - by;
                return x.getPriority() - y.getPriority();
            }
        });
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackgroundColor(BAR);
        int p = dp(4);
        row.setPadding(p, p, p, p);
        for (int i = 0; i < cs.size(); i++) {
            final Command c = (Command) cs.get(i);
            Button b = new Button(act);
            b.setText(c.getLabel());
            b.setAllCaps(false);
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { fire(d, c); }
            });
            row.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        HorizontalScrollView hs = new HorizontalScrollView(act);
        hs.setBackgroundColor(BAR);
        hs.addView(row, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return hs;
    }

    private static boolean isBack(Command c) {
        int t = c.getCommandType();
        return t == Command.BACK || t == Command.CANCEL || t == Command.EXIT || t == Command.STOP;
    }

    private static void showAlert(final Alert a, final Displayable back) {
        if (act == null) return;
        if (dialog != null) { try { dialog.setOnDismissListener(null); dialog.dismiss(); } catch (Throwable t) { } }
        AlertDialog.Builder b = new AlertDialog.Builder(act, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
        b.setTitle(a.getTitle());
        b.setMessage(a.getString());
        b.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface di, int w) { di.dismiss(); }
        });
        b.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface di) {
                dialog = null;
                if (current == a) {
                    if (back != null) setCurrent(back, null);
                    else current = beforeAlert;
                }
            }
        });
        dialog = b.create();
        dialog.show();
    }

    // ---------- botón Atrás del sistema ----------

    /** Devuelve true si el MIDlet ha gestionado la pulsación. */
    public static boolean onBack() {
        Displayable d = current;
        if (d == null || d instanceof Alert) return false;
        Command found = null;
        synchronized (d.cmds) {
            for (int i = 0; i < d.cmds.size(); i++) {
                Command c = (Command) d.cmds.elementAt(i);
                if (c.getCommandType() == Command.BACK || c.getCommandType() == Command.CANCEL) { found = c; break; }
            }
        }
        if (found == null) return false;
        fire(d, found);
        return true;
    }
}
