package javax.microedition.lcdui;

import javax.microedition.midlet.MIDlet;

public class Display {
    private static final Display INST = new Display();

    public static Display getDisplay(MIDlet m) { return INST; }
    public void setCurrent(Displayable d) { UiHost.setCurrent(d, null); }
    public void setCurrent(Alert a, Displayable next) { UiHost.setCurrent(a, next); }
    public Displayable getCurrent() { return UiHost.getCurrent(); }
    public void callSerially(Runnable r) { UiHost.events(r); }
    public boolean flashBacklight(int d) { return true; }
    public boolean vibrate(int d) { return true; }
}
