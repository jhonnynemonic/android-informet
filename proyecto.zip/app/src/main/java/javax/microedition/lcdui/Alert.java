package javax.microedition.lcdui;

public class Alert extends Screen {
    public static final int FOREVER = -2;
    private volatile String text;
    private volatile int timeout = FOREVER;

    public Alert(String title, String text, Image img, AlertType type) { setTitle(title); this.text = text; }
    public void setTimeout(int t) { timeout = t; }
    public int getTimeout() { return timeout; }
    public String getString() { return text; }
    public void setString(String s) { text = s; }
}
