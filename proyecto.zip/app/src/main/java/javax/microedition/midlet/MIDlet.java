package javax.microedition.midlet;

import javax.microedition.lcdui.UiHost;

/** MIDlet mínimo: la aplicación Android hace de "gestor" del MIDlet. */
public abstract class MIDlet {
    protected MIDlet() {}
    protected abstract void startApp() throws MIDletStateChangeException;
    protected abstract void pauseApp();
    protected abstract void destroyApp(boolean unconditional) throws MIDletStateChangeException;
    public final void notifyDestroyed() { UiHost.exit(); }
    public final String getAppProperty(String key) { return null; }
    public final boolean platformRequest(String url) { return false; }
}
