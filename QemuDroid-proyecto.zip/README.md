# QemuDroid

Emulador de PC x86 (32 bits, estilo QEMU) para Android. Arranca kernel + initrd
directamente desde una ISO, con el menú de GRUB, CD-ROM IDE, framebuffer VESA para
Xorg, ratón PS/2 táctil y teclado (español o US). Núcleo compartido con QemuJ2ME.

## Compilar con GitHub Actions
1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta
   (incluida la carpeta oculta `.github`).
2. Cada `push` lanza el workflow **Compilar APK** (pestaña *Actions*). También se puede
   lanzar a mano con *Run workflow*.
3. Al terminar, descarga el artefacto **QemuDroid-apk** (un .zip con `app-debug.apk`)
   e instálalo en el móvil.

## Uso
- **Elegir ISO…** abre el selector de Android (no hace falta dar permisos de almacenamiento).
- Elige la entrada de GRUB (se marcan los kernels de 64 bits, que no arrancan) y pulsa **ARRANCAR**.
- Ratón: arrastra el dedo = mover, toque = clic, pulsación larga o dos dedos = clic derecho,
  dos dedos en vertical = rueda.
- Barra inferior: teclado (⌨), Esc, Tab, Ctrl/Alt (se quedan pulsadas para la siguiente tecla),
  flechas, F1–F12, VGA/Serie, Info, Diag, Pausa.
- Teclado físico USB/Bluetooth: va con los códigos de tecla reales.
- Atrás = apagar el PC emulado.

El fichero de intercambio va en la carpeta privada de la app y se borra al salir.
