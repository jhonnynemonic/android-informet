package es.juanantonio.qemudroid;

import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import emu.Store;

/** ISO abierta con el selector de Android (content://): lectura aleatoria por FileChannel. */
public final class ContentStore extends Store {
    private final ParcelFileDescriptor pfd;
    private final FileInputStream in;
    private final FileChannel ch;
    private final long len;

    public ContentStore(Context c, Uri u) throws IOException {
        pfd = c.getContentResolver().openFileDescriptor(u, "r");
        if (pfd == null) throw new IOException("no se puede abrir " + u);
        in = new FileInputStream(pfd.getFileDescriptor());
        ch = in.getChannel();
        long l = pfd.getStatSize();
        if (l <= 0) l = ch.size();
        len = l;
    }

    @Override public long length() { return len; }

    @Override public int read(long pos, byte[] b, int off, int n) throws IOException {
        if (pos >= len) return -1;
        return ch.read(ByteBuffer.wrap(b, off, n), pos);
    }

    @Override public void close() {
        try { ch.close(); in.close(); pfd.close(); } catch (Exception e) { }
    }
}
