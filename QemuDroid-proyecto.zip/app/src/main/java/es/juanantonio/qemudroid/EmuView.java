package es.juanantonio.qemudroid;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;

import java.io.InputStream;

import emu.Keys;
import emu.Machine;
import emu.Mem;
import emu.Pc;
import emu.SerialTerm;

/** Pantalla del PC emulado: texto VGA, framebuffer o terminal serie; ratón táctil y teclado. */
public class EmuView extends View {
    static final int[] PAL = {0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xAA5500, 0xAAAAAA,
        0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF};

    final Machine m;
    final SerialTerm term;
    boolean vga, info = true, diag, es;
    boolean ctrl, alt;          // modificadores "pegajosos" de la barra de teclas
    final byte[] font = new byte[4096];
    final int[] tpix = new int[640 * 400];
    final Bitmap tbmp = Bitmap.createBitmap(640, 400, Bitmap.Config.ARGB_8888);
    Bitmap gbmp;
    int[] gpix;
    final Paint crisp = new Paint(), smooth = new Paint(), text = new Paint(), bg = new Paint();
    final Rect dst = new Rect();
    volatile String diagText = "";
    long diagAt;

    public EmuView(Context c, Machine mm, SerialTerm t, boolean startVga, boolean esLayout) {
        super(c);
        m = mm; term = t; vga = startVga; es = esLayout;
        setFocusable(true);
        setFocusableInTouchMode(true);
        smooth.setFilterBitmap(true);
        text.setColor(Color.YELLOW);
        text.setTypeface(Typeface.MONOSPACE);
        text.setTextSize(28);
        text.setAntiAlias(true);
        bg.setColor(0xC0102030);
        try {
            InputStream in = c.getAssets().open("font.bin");
            int o = 0, n;
            while (o < 4096 && (n = in.read(font, o, 4096 - o)) > 0) o += n;
            in.close();
        } catch (Exception e) { }
        if (m.fbW > 0) {
            gbmp = Bitmap.createBitmap(m.fbW, m.fbH, Bitmap.Config.ARGB_8888);
            gpix = new int[m.fbW * m.fbH];
        }
    }

    // ------------------------------------------------------------ dibujo
    void fit(int w, int h, int sw, int sh) {
        int dw = sw, dh = (int) ((long) w * sw / h);
        if (dh > sh) { dh = sh; dw = (int) ((long) h * sh / w); }
        int x = (sw - dw) / 2;
        dst.set(x, 0, x + dw, dh);
    }

    void cell(int col, int row, int c, int a, boolean cur) {
        int fg = 0xFF000000 | PAL[a & 15], bgc = 0xFF000000 | PAL[(a >> 4) & 7];
        int base = row * 16 * 640 + col * 8;
        for (int y = 0; y < 16; y++) {
            int bits = font[(c & 255) * 16 + y];
            int o = base + y * 640;
            boolean ul = cur && y >= 14;
            for (int x = 0; x < 8; x++) tpix[o + x] = (ul || ((bits >> (7 - x)) & 1) != 0) ? fg : bgc;
        }
    }

    void drawText(Canvas c) {
        if (vga) {
            Pc pc = m.pc;
            int start = pc.vgaStart(), cursor = pc.vgaCursor() - start;
            boolean curOn = (pc.crtc[0x0A] & 0x20) == 0 && (System.currentTimeMillis() / 400 & 1) == 0;
            for (int i = 0; i < 2000; i++) {
                int a = 0xB8000 + (((start + i) * 2) & 0x7FFF);
                cell(i % 80, i / 80, m.mem.peek8(a), m.mem.peek8(a + 1), curOn && i == cursor);
            }
        } else {
            for (int i = 0; i < 2000; i++) cell(i % 80, i / 80, term.ch[i], term.at[i], i == term.cy * 80 + term.cx);
        }
        tbmp.setPixels(tpix, 0, 640, 0, 0, 640, 400);
        fit(4, 3, getWidth(), getHeight());
        c.drawBitmap(tbmp, null, dst, crisp);
    }

    void drawFb(Canvas c) {
        int fw = m.fbW, fh = m.fbH;
        Mem mem = m.mem;
        int base = Machine.FB_BASE;
        for (int y = 0; y < fh; y++) {
            int row = base + y * fw * 4, o = y * fw;
            byte[] cur = null;
            int curC = -1;
            for (int x = 0; x < fw; x++) {
                int a = row + x * 4, ch = a >>> 16;
                if (ch != curC) { cur = mem.peekChunk(ch); curC = ch; }
                if (cur == null) { gpix[o + x] = 0xFF000000; continue; }
                int i = a & 0xFFFF;
                gpix[o + x] = 0xFF000000 | ((cur[i + 2] & 0xFF) << 16) | ((cur[i + 1] & 0xFF) << 8) | (cur[i] & 0xFF);
            }
        }
        gbmp.setPixels(gpix, 0, fw, 0, 0, fw, fh);
        fit(fw, fh, getWidth(), getHeight());
        c.drawBitmap(gbmp, null, dst, smooth);
    }

    void lines(Canvas c, String s, int maxLines) {
        float cw = text.measureText("m");
        int per = Math.max(10, (int) (getWidth() / cw) - 1);
        float lh = text.getTextSize() * 1.15f;
        java.util.List<String> out = new java.util.ArrayList<>();
        for (String l : s.split("\n")) {
            while (l.length() > per) { out.add(l.substring(0, per)); l = l.substring(per); }
            out.add(l);
        }
        int n = Math.min(maxLines, out.size());
        c.drawRect(0, 0, getWidth(), n * lh + 8, bg);
        for (int i = 0; i < n; i++) c.drawText(out.get(i), 4, (i + 1) * lh, text);
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(Color.BLACK);
        if (vga && m.fbW > 0) drawFb(c); else drawText(c);
        String st = (vga ? (m.fbW > 0 ? "[Gráficos] " : "[VGA] ") : "[Serie] ") + (m.stopped ? "DETENIDO | " : "") + m.info();
        if (diag) {
            long now = System.currentTimeMillis();
            if (now - diagAt > 2000) { diagAt = now; refreshDiag(); }
            text.setColor(0xFF80FF80);
            lines(c, diagText, 60);
            text.setColor(Color.YELLOW);
        } else if (info || m.stopped) {
            text.setColor(m.stopped ? 0xFFFF6060 : Color.YELLOW);
            lines(c, st, m.stopped ? 8 : 2);
            text.setColor(Color.YELLOW);
        }
        postInvalidateDelayed(66);
    }

    void refreshDiag() {
        new Thread(() -> {
            boolean was = m.paused;
            m.paused = true;
            try { Thread.sleep(150); } catch (InterruptedException e) { }
            String d = m.diag();
            m.paused = was;
            diagText = d;
        }).start();
    }

    // ------------------------------------------------------------ ratón táctil (como un touchpad)
    float lx, ly, accX, accY, sx, sy;
    long tDown;
    boolean moved, twoFingers;

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lx = sx = e.getX(); ly = sy = e.getY();
                tDown = System.currentTimeMillis();
                moved = false; twoFingers = false;
                requestFocus();
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                twoFingers = true;
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (e.getPointerCount() > 1) {   // dos dedos en vertical = rueda
                    float dy = e.getY() - ly;
                    if (Math.abs(dy) > 40) { m.pc.mouse(0, 0, -1, dy > 0 ? 1 : -1); ly = e.getY(); moved = true; }
                    return true;
                }
                float x = e.getX(), y = e.getY();
                if (Math.abs(x - sx) + Math.abs(y - sy) > 12) moved = true;
                if (moved) {
                    int gw = m.fbW > 0 ? m.fbW : 640;
                    float sc = dst.width() > 0 ? (float) gw / dst.width() * 1.3f : 1.5f;
                    accX += (x - lx) * sc; accY += (y - ly) * sc;
                    int dx = (int) accX, dy = (int) accY;
                    accX -= dx; accY -= dy;
                    if (dx != 0 || dy != 0) m.pc.mouse(dx, dy, -1);
                }
                lx = x; ly = y;
                return true;
            }
            case MotionEvent.ACTION_UP:
                if (!moved) {
                    long t = System.currentTimeMillis() - tDown;
                    int b = twoFingers || t > 550 ? 2 : 1;
                    m.pc.mouse(0, 0, b);
                    m.pc.mouse(0, 0, 0);
                }
                return true;
        }
        return super.onTouchEvent(e);
    }

    // ------------------------------------------------------------ teclado
    void showKeyboard() {
        requestFocus();
        InputMethodManager im = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
    }

    @Override public boolean onCheckIsTextEditor() { return true; }

    int composing;

    @Override public InputConnection onCreateInputConnection(EditorInfo out) {
        out.inputType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
        out.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_FLAG_NO_FULLSCREEN | EditorInfo.IME_ACTION_NONE;
        return new BaseInputConnection(this, false) {
            @Override public boolean commitText(CharSequence t, int pos) {
                for (int i = 0; i < composing; i++) backspace();
                composing = 0;
                typeText(t);
                return true;
            }
            @Override public boolean setComposingText(CharSequence t, int pos) {
                for (int i = 0; i < composing; i++) backspace();
                typeText(t);
                composing = t.length();
                return true;
            }
            @Override public boolean finishComposingText() { composing = 0; return true; }
            @Override public boolean deleteSurroundingText(int before, int after) {
                for (int i = 0; i < Math.max(1, before); i++) backspace();
                return true;
            }
            @Override public boolean sendKeyEvent(KeyEvent ev) {
                if (ev.getAction() == KeyEvent.ACTION_DOWN) softKey(ev.getKeyCode(), ev);
                return true;
            }
        };
    }

    void typeText(CharSequence t) {
        for (int i = 0; i < t.length(); i++) typeChar(t.charAt(i));
    }

    void typeChar(char c) {
        if (!vga) { m.pc.serialIn(c == '\n' ? '\r' : c); return; }
        if (ctrl || alt) {
            if (ctrl) m.pc.keyScan(0x1D);
            if (alt) m.pc.keyScan(0x38);
            int[] k = Keys.map(Character.toLowerCase(c));
            if (k != null) { m.pc.keyScan(k[0]); m.pc.keyScan(k[0] | 0x80); }
            releaseMods();
            return;
        }
        KeyMap.type(m.pc, c, es);
    }

    void releaseMods() {
        if (ctrl) m.pc.keyScan(0x9D);
        if (alt) m.pc.keyScan(0xB8);
        ctrl = alt = false;
    }

    void backspace() { special("Retroceso"); }

    /** teclas sin carácter del teclado en pantalla */
    void softKey(int code, KeyEvent ev) {
        switch (code) {
            case KeyEvent.KEYCODE_DEL: special("Retroceso"); return;
            case KeyEvent.KEYCODE_ENTER: case KeyEvent.KEYCODE_NUMPAD_ENTER: special("Intro"); return;
            case KeyEvent.KEYCODE_TAB: special("Tab"); return;
            case KeyEvent.KEYCODE_ESCAPE: special("Esc"); return;
            case KeyEvent.KEYCODE_DPAD_UP: special("↑"); return;
            case KeyEvent.KEYCODE_DPAD_DOWN: special("↓"); return;
            case KeyEvent.KEYCODE_DPAD_LEFT: special("←"); return;
            case KeyEvent.KEYCODE_DPAD_RIGHT: special("→"); return;
            case KeyEvent.KEYCODE_FORWARD_DEL: special("Supr"); return;
        }
        int u = ev.getUnicodeChar();
        if (u > 0) typeChar((char) u);
    }

    static boolean physical(KeyEvent e) {
        return e.getScanCode() > 0 && e.getDevice() != null && !e.getDevice().isVirtual();
    }

    @Override public boolean onKeyDown(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN)
            return super.onKeyDown(code, e);
        if (physical(e) && vga) {
            if (e.getRepeatCount() == 0 || true) KeyMap.scan(m.pc, KeyMap.linuxToSet1(e.getScanCode()), true);
            return true;
        }
        softKey(code, e);
        return true;
    }

    @Override public boolean onKeyUp(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN)
            return super.onKeyUp(code, e);
        if (physical(e) && vga) {
            KeyMap.scan(m.pc, KeyMap.linuxToSet1(e.getScanCode()), false);
            return true;
        }
        return true;
    }

    /** botones de la barra inferior */
    void special(String s) {
        Pc pc = m.pc;
        if (!vga) {
            String q = null;
            switch (s) {
                case "Intro": q = "\r"; break;
                case "Esc": q = "\033"; break;
                case "Tab": q = "\t"; break;
                case "Retroceso": q = "\177"; break;
                case "↑": q = "\033[A"; break;
                case "↓": q = "\033[B"; break;
                case "→": q = "\033[C"; break;
                case "←": q = "\033[D"; break;
                case "Supr": q = "\033[3~"; break;
                case "Inicio": q = "\033[H"; break;
                case "Fin": q = "\033[F"; break;
            }
            if (s.startsWith("Ctrl+") && s.length() == 6) q = "" + (char) (s.charAt(5) - 'A' + 1);
            if (q != null) for (int i = 0; i < q.length(); i++) pc.serialIn(q.charAt(i));
            return;
        }
        int code = 0;
        switch (s) {
            case "Intro": code = 0x1C; break;
            case "Esc": code = 0x01; break;
            case "Tab": code = 0x0F; break;
            case "Retroceso": code = 0x0E; break;
            case "↑": code = 0x148; break;
            case "↓": code = 0x150; break;
            case "←": code = 0x14B; break;
            case "→": code = 0x14D; break;
            case "Inicio": code = 0x147; break;
            case "Fin": code = 0x14F; break;
            case "RePág": code = 0x149; break;
            case "AvPág": code = 0x151; break;
            case "Supr": code = 0x153; break;
            case "Ctrl+Alt+Supr":
                pc.keyScan(0x1D); pc.keyScan(0x38); KeyMap.scan(pc, 0x153, true); KeyMap.scan(pc, 0x153, false);
                pc.keyScan(0xB8); pc.keyScan(0x9D);
                return;
            case "SysRq W":
                pc.keyScan(0x38); pc.keyScan(0x54); pc.keyScan(0x11); pc.keyScan(0x91); pc.keyScan(0xD4); pc.keyScan(0xB8);
                return;
        }
        if (s.length() >= 2 && s.charAt(0) == 'F' && Character.isDigit(s.charAt(1))) {
            int n = Integer.parseInt(s.substring(1));
            code = n <= 10 ? 0x3A + n : 0x57 + n - 11;
        }
        if (code == 0) return;
        if (ctrl) pc.keyScan(0x1D);
        if (alt) pc.keyScan(0x38);
        KeyMap.scan(pc, code, true);
        KeyMap.scan(pc, code, false);
        releaseMods();
    }
}
