package emu;

import java.io.IOException;
import java.util.Vector;

/** Lector ISO9660 con nombres Rock Ridge (NM) o Joliet. */
public final class Iso9660 {
    public static final class Entry {
        public String name, path;
        public long lba, size;
        public boolean dir;
        public long offset() { return lba * 2048L; }
    }

    final Store s;
    long rootLba, rootSize;
    boolean joliet, rr;

    public Iso9660(Store st) throws IOException {
        s = st;
        byte[] b = new byte[2048];
        long jl = -1, js = 0;
        for (int sec = 16; sec < 64; sec++) {
            s.readFully(sec * 2048L, b, 0, 2048);
            if (b[1] != 'C' || b[2] != 'D' || b[3] != '0' || b[4] != '0' || b[5] != '1') break;
            int type = b[0] & 0xFF;
            if (type == 1 && rootSize == 0) { rootLba = le32(b, 156 + 2); rootSize = le32(b, 156 + 10); }
            else if (type == 2 && b[88] == '%' && b[89] == '/') { jl = le32(b, 156 + 2); js = le32(b, 156 + 10); }
            else if (type == 255) break;
        }
        if (rootSize == 0) throw new IOException("no es una ISO9660");
        // ¿hay Rock Ridge?
        Vector v = rawList(rootLba, rootSize, "", false);
        for (int i = 0; i < v.size(); i++) if (((String[]) v.elementAt(i))[0] != null) { rr = true; break; }
        if (!rr && jl > 0) { joliet = true; rootLba = jl; rootSize = js; }
    }

    static long le32(byte[] b, int o) {
        return (b[o] & 0xFFL) | ((b[o + 1] & 0xFFL) << 8) | ((b[o + 2] & 0xFFL) << 16) | ((b[o + 3] & 0xFFL) << 24);
    }

    /** devuelve vector de String[]{rrName, isoName, lba, size, dir} */
    private Vector rawList(long lba, long size, String x, boolean jol) throws IOException {
        Vector out = new Vector();
        if (size > 64L * 1024 * 1024) return out;
        byte[] b = new byte[(int) size];
        s.readFully(lba * 2048L, b, 0, (int) size);
        int o = 0;
        while (o < b.length) {
            int len = b[o] & 0xFF;
            if (len == 0) { o = (o / 2048 + 1) * 2048; continue; }
            if (o + len > b.length) break;
            long ext = le32(b, o + 2), dsz = le32(b, o + 10);
            int fl = b[o + 25] & 0xFF, nl = b[o + 32] & 0xFF;
            String iso;
            if (nl == 1 && (b[o + 33] == 0 || b[o + 33] == 1)) iso = null;
            else if (jol) {
                StringBuffer sb = new StringBuffer();
                for (int i = 0; i + 1 < nl; i += 2) sb.append((char) (((b[o + 33 + i] & 0xFF) << 8) | (b[o + 34 + i] & 0xFF)));
                iso = sb.toString();
            } else {
                StringBuffer sb = new StringBuffer();
                for (int i = 0; i < nl; i++) sb.append((char) (b[o + 33 + i] & 0xFF));
                iso = sb.toString();
            }
            String rrn = null;
            int su = o + 33 + nl + ((nl & 1) == 0 ? 1 : 0);
            StringBuffer nm = null;
            while (su + 4 <= o + len) {
                int sl = b[su + 2] & 0xFF;
                if (sl < 4) break;
                if (b[su] == 'N' && b[su + 1] == 'M') {
                    if (nm == null) nm = new StringBuffer();
                    for (int i = 5; i < sl; i++) nm.append((char) (b[su + i] & 0xFF));
                }
                su += sl;
            }
            if (nm != null) rrn = nm.toString();
            if (iso != null) out.addElement(new String[] {rrn, iso, Long.toString(ext), Long.toString(dsz), (fl & 2) != 0 ? "d" : "f"});
            else if (rrn != null) out.addElement(new String[] {rrn, null, "0", "0", "."});
            o += len;
        }
        return out;
    }

    public Vector list(long lba, long size, String parent) throws IOException {
        Vector raw = rawList(lba, size, parent, joliet);
        Vector out = new Vector();
        for (int i = 0; i < raw.size(); i++) {
            String[] r = (String[]) raw.elementAt(i);
            if (r[1] == null) continue;
            Entry e = new Entry();
            String n = r[0];
            if (n == null || n.length() == 0) {
                n = r[1];
                int sc = n.indexOf(';');
                if (sc >= 0) n = n.substring(0, sc);
                if (n.endsWith(".")) n = n.substring(0, n.length() - 1);
                if (!joliet) n = n.toLowerCase();
            }
            e.name = n;
            e.path = parent + "/" + n;
            e.lba = Long.parseLong(r[2]);
            e.size = Long.parseLong(r[3]);
            e.dir = "d".equals(r[4]);
            out.addElement(e);
        }
        return out;
    }

    public Entry root() {
        Entry e = new Entry();
        e.name = ""; e.path = ""; e.lba = rootLba; e.size = rootSize; e.dir = true;
        return e;
    }

    public Vector list(Entry d) throws IOException { return list(d.lba, d.size, d.path); }

    public Entry find(String path) throws IOException {
        Entry cur = root();
        int i = 0;
        while (i < path.length()) {
            while (i < path.length() && path.charAt(i) == '/') i++;
            if (i >= path.length()) break;
            int j = path.indexOf('/', i);
            if (j < 0) j = path.length();
            String comp = path.substring(i, j);
            i = j;
            if (!cur.dir) return null;
            Vector v = list(cur);
            Entry nx = null;
            for (int k = 0; k < v.size(); k++) {
                Entry e = (Entry) v.elementAt(k);
                if (e.name.equalsIgnoreCase(comp)) { nx = e; break; }
            }
            if (nx == null) return null;
            cur = nx;
        }
        return cur;
    }

    /** todos los ficheros hasta cierta profundidad */
    public void scan(Entry d, int depth, Vector out) throws IOException {
        Vector v = list(d);
        for (int k = 0; k < v.size(); k++) {
            Entry e = (Entry) v.elementAt(k);
            if (e.dir) { if (depth > 0) scan(e, depth - 1, out); }
            else out.addElement(e);
        }
    }

    public String readText(Entry e, int max) throws IOException {
        int n = (int) Math.min(e.size, max);
        byte[] b = new byte[n];
        s.readFully(e.offset(), b, 0, n);
        StringBuffer sb = new StringBuffer(n);
        for (int i = 0; i < n; i++) sb.append((char) (b[i] & 0xFF));
        return sb.toString();
    }
}
