package emu;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Acceso a la red real del anfitrión (wifi/datos/127.0.0.1). Todas las llamadas son bloqueantes
 * y se hacen SIEMPRE desde hilos de trabajo, nunca desde el hilo del emulador.
 * Implementaciones: JNet (java.net: Android, FreeJ2ME, PC) y J2meNet (javax.microedition.io).
 */
public abstract class NetIo {
    public interface Conn {
        InputStream in() throws IOException;
        OutputStream out() throws IOException;
        /** cerrar la mitad de escritura (FIN) si se puede; si no, no hace nada */
        void shutOut();
        void close();
    }
    public interface Dgram {
        void send(byte[] b, int off, int len, String host, int port) throws IOException;
        /** recibe en buf; devuelve longitud, y en from[0]=ip "a.b.c.d", from[1]=puerto. -1 = tiempo agotado */
        int recv(byte[] buf, Object[] from) throws IOException;
        void close();
    }
    public interface Server {
        Conn accept() throws IOException;
        void close();
    }

    public abstract Conn tcp(String host, int port, int timeoutMs) throws IOException;
    /** localPort 0 = efímero */
    public abstract Dgram udp(int localPort, int timeoutMs) throws IOException;
    public abstract Server listen(int port) throws IOException;
    /** direcciones IPv4 (4 bytes cada una) o null */
    public abstract byte[][] resolve(String name);
    /** ping "de usuario": true si el host responde (puede fallar donde un ping real funcionaría) */
    public boolean reachable(String host, int timeoutMs) { return false; }
    public abstract String name();

    public static NetIo create() {
        try { return (NetIo) Class.forName("emu.JNet").newInstance(); } catch (Throwable t) { }
        try { return (NetIo) Class.forName("emu.J2meNet").newInstance(); } catch (Throwable t) { }
        return null;
    }
}
