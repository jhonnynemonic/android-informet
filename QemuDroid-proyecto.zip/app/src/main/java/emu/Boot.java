package emu;

import java.io.IOException;

/** Carga directa de kernel Linux (protocolo de arranque de 32 bits), ELF o binario plano. */
public final class Boot {
    public static final int ZP = 0x10000, CMDL = 0x20000, GDT = 0x30000;

    static int le16(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8); }
    static int le32(byte[] b, int o) { return le16(b, o) | (le16(b, o + 2) << 16); }

    /**
     * kOff/kLen: posición del kernel en su Store; iOff/iLen: initrd (iLen = 0 si no hay).
     * Devuelve un texto informativo (avisos incluidos).
     */
    public static String load(Machine m, Store ks, long kOff, long kLen, Store is, long iOff, long iLen, String cmdline)
            throws IOException {
        Mem mem = m.mem;
        X86 cpu = m.cpu;
        StringBuffer info = new StringBuffer();
        long ram = m.ram;
        byte[] h = new byte[4096];
        ks.readFully(kOff, h, 0, (int) Math.min(4096, kLen));
        // pantalla en blanco con atributo gris
        for (int i = 0; i < 80 * 25; i++) mem.wr16(0xB8000 + i * 2, 0x0720);

        if (h[0x202] == 'H' && h[0x203] == 'd' && h[0x204] == 'r' && h[0x205] == 'S') {
            int ver = le16(h, 0x206);
            int setup = h[0x1F1] & 0xFF;
            if (setup == 0) setup = 4;
            int lf = h[0x211] & 0xFF;
            if ((lf & 1) == 0) throw new IOException("zImage antiguo (no bzImage): no soportado");
            long pmOff = (setup + 1) * 512L;
            long pmLen = kLen - pmOff;
            int xlf = ver >= 0x20C ? le16(h, 0x236) : 0;
            int initMax = ver >= 0x203 ? le32(h, 0x22C) : 0x37FFFFFF;
            int initSize = ver >= 0x20A ? le32(h, 0x260) : (int) (pmLen * 4);
            info.append("bzImage v").append(Integer.toHexString(ver >> 8)).append('.')
                .append(Integer.toHexString(ver & 0xFF)).append(", ").append(pmLen / 1024).append(" KB\n");
            if ((xlf & 1) != 0) {
                cpu.sseLevel = 2;   // x86-64 exige SSE/SSE2/FXSR
                info.append("Kernel de 64 bits: CPU x86-64 con SSE2 (experimental)\n");
            }
            if (0x100000L + Math.max(pmLen, initSize & 0xFFFFFFFFL) + 0x100000 > ram)
                info.append("AVISO: poca RAM para descomprimir el kernel\n");
            mem.map(0x100000, pmLen, ks, kOff + pmOff);

            int hdrEnd = 0x202 + (h[0x201] & 0xFF);
            for (int i = 0x1F1; i < hdrEnd && i < 0x290; i++) mem.wr8(ZP + i, h[i]);
            mem.wr8(ZP + 0x210, 0xFF);
            mem.wr8(ZP + 0x211, (lf | 0x80) & ~0x20);
            mem.wr16(ZP + 0x224, 0xFE00);
            mem.wr32(ZP + 0x228, CMDL);
            // screen_info: modo texto VGA 80x25 color
            mem.wr8(ZP + 0x00, 0); mem.wr8(ZP + 0x01, 0);
            mem.wr8(ZP + 0x06, 3); mem.wr8(ZP + 0x07, 80);
            mem.wr8(ZP + 0x0E, 25); mem.wr8(ZP + 0x0F, 1); mem.wr16(ZP + 0x10, 16);
            if (m.fbW > 0) {
                // framebuffer lineal tipo VESA (como GRUB con gfxpayload=keep): vesafb/simpledrm -> /dev/fb0
                int w = m.fbW, hh = m.fbH;
                mem.wr8(ZP + 0x0F, 0x23);                 // VIDEO_TYPE_VLFB
                mem.wr16(ZP + 0x12, w); mem.wr16(ZP + 0x14, hh); mem.wr16(ZP + 0x16, 32);
                mem.wr32(ZP + 0x18, Machine.FB_BASE);
                mem.wr32(ZP + 0x1C, Machine.FB_SIZE >> 16);  // en unidades de 64 KB
                mem.wr16(ZP + 0x24, w * 4);
                mem.wr8(ZP + 0x26, 8); mem.wr8(ZP + 0x27, 16);
                mem.wr8(ZP + 0x28, 8); mem.wr8(ZP + 0x29, 8);
                mem.wr8(ZP + 0x2A, 8); mem.wr8(ZP + 0x2B, 0);
                mem.wr8(ZP + 0x2C, 8); mem.wr8(ZP + 0x2D, 24);
                mem.wr16(ZP + 0x32, 1);
                mem.wr16(ZP + 0x34, 0x9B);                // atributos VBE: soportado, color, gráfico, LFB
                mem.wr8(ZP + 0x06, 0x18);
                info.append("Framebuffer VESA ").append(w).append('x').append(hh).append("x32 en 0xE0000000\n");
            }
            mem.wr16(ZP + 0x02, (int) Math.min(0xFFFF, (ram >> 10) - 1024));
            mem.wr32(ZP + 0x1E0, (int) ((ram >> 10) - 1024));
            // mapa e820
            int n = 0;
            n = e820(mem, n, 0, 0x9FC00, 1);
            n = e820(mem, n, 0x9FC00, 0x400, 2);
            n = e820(mem, n, 0xF0000, 0x10000, 2);
            long ramTop = Math.min(ram, 0xFFFC0000L);
            long fbA = Machine.FB_BASE & 0xFFFFFFFFL;
            // huecos: framebuffer (reservado) y MMIO de la e1000 (sin entrada, como el agujero PCI de QEMU)
            long[] hA = new long[2], hL = new long[2]; int[] hT = new int[2]; int nh = 0;
            if (m.fbW > 0) { hA[nh] = fbA; hL[nh] = Machine.FB_SIZE; hT[nh++] = 2; }
            if (m.pc.nic != null) { hA[nh] = Pc.NET_MMIO & 0xFFFFFFFFL; hL[nh] = 0x20000; hT[nh++] = 0; }
            long a0 = 0x100000;
            for (int i = 0; i < nh; i++) if (hA[i] < ramTop) {
                if (hA[i] > a0) n = e820(mem, n, a0, hA[i] - a0, 1);
                if (hT[i] != 0) n = e820(mem, n, hA[i], hL[i], hT[i]);
                a0 = Math.max(a0, hA[i] + hL[i]);
            }
            if (ramTop > a0) n = e820(mem, n, a0, ramTop - a0, 1);
            for (int i = 0; i < nh; i++) if (hA[i] >= ramTop && hT[i] != 0) n = e820(mem, n, hA[i], hL[i], hT[i]);
            if (ram > ramTop) n = e820(mem, n, ramTop, 0x100000000L - ramTop, 2);
            mem.wr8(ZP + 0x1E8, n);
            // initrd arriba del todo
            if (iLen > 0) {
                long top = Math.min((long) ram, (initMax & 0xFFFFFFFFL) + 1);
                top = Math.min(top, 0x37C00000L);
                long addr = (top - iLen) & ~0xFFFL;
                long kEnd = 0x100000L + Math.max(pmLen, initSize & 0xFFFFFFFFL);
                if (addr < kEnd + 0x400000) throw new IOException("RAM insuficiente para kernel + initrd: sube la RAM");
                mem.map(addr, iLen, is, iOff);
                mem.wr32(ZP + 0x218, (int) addr);
                mem.wr32(ZP + 0x21C, (int) iLen);
                info.append("initrd ").append(iLen >> 20).append(" MB en 0x").append(Long.toString(addr, 16)).append('\n');
            }
            int cmax = ver >= 0x206 ? le32(h, 0x238) : 255;
            if (cmdline.length() > cmax) cmdline = cmdline.substring(0, cmax);
            for (int i = 0; i < cmdline.length(); i++) mem.wr8(CMDL + i, cmdline.charAt(i));
            mem.wr8(CMDL + cmdline.length(), 0);
            cpu.setupFlat32(GDT);
            cpu.r[6] = ZP;
            cpu.r[5] = cpu.r[7] = cpu.r[3] = 0;
            cpu.r[4] = 0x9F000;
            cpu.eip = le32(h, 0x214);
            if (cpu.eip == 0) cpu.eip = 0x100000;
        } else if (h[0] == 0x7F && h[1] == 'E' && h[2] == 'L' && h[3] == 'F') {
            int phoff = le32(h, 28), phent = le16(h, 42), phnum = le16(h, 44);
            for (int i = 0; i < phnum; i++) {
                int p = phoff + i * phent;
                if (le32(h, p) != 1) continue;
                long off = le32(h, p + 4) & 0xFFFFFFFFL;
                int pa = le32(h, p + 12);
                long fsz = le32(h, p + 16) & 0xFFFFFFFFL;
                if (fsz > 0) mem.map(pa & 0xFFFFFFFFL, fsz, ks, kOff + off);
            }
            cpu.setupFlat32(GDT);
            cpu.eip = le32(h, 24);
            cpu.r[4] = 0x9F000;
            info.append("ELF, entrada 0x").append(Integer.toHexString(cpu.eip)).append('\n');
        } else {
            mem.map(0x100000, kLen, ks, kOff);
            cpu.setupFlat32(GDT);
            cpu.eip = 0x100000;
            cpu.r[4] = 0x9F000;
            info.append("binario plano en 1 MB\n");
        }
        m.pc.setMemSize(ram);
        return info.toString();
    }

    static int e820(Mem m, int n, long a, long len, int type) {
        int o = ZP + 0x2D0 + n * 20;
        m.wr32(o, (int) a); m.wr32(o + 4, (int) (a >>> 32));
        m.wr32(o + 8, (int) len); m.wr32(o + 12, (int) (len >>> 32));
        m.wr32(o + 16, type);
        return n + 1;
    }
}
