package emu;

/** Dónde ocurrió un error (usa la traza de Java completo si existe). */
public final class Diag {
    public interface Impl { String where(Throwable t); }
    public static String where(Throwable t) {
        try { return ((Impl) Class.forName("emu.JDiag").newInstance()).where(t); } catch (Throwable x) { return ""; }
    }
}
