package emu;

/**
 * Anillo de audio entre la tarjeta emulada (hilo del emulador) y el reproductor real (hilo de audio).
 * PCM 16 bits con signo, estéreo, little-endian. El emulador solo escribe lo que cabe: así la
 * reproducción marca el ritmo real y el invitado nunca se adelanta ni se bloquea.
 */
public final class AudioOut {
    final byte[] buf;
    int head, len;
    public volatile int rate = 48000;
    public volatile boolean closed;
    public long written, underruns;
    /** lo llama el hilo de audio cuando queda poco, para que el emulador rellene antes */
    public Runnable lowWater;

    public AudioOut(int bytes) { buf = new byte[bytes & ~3]; }

    public synchronized int space() { return buf.length - len; }
    public synchronized int fill() { return len; }
    public int capacity() { return buf.length; }

    public synchronized int write(byte[] b, int off, int n) {
        int k = Math.min(n, buf.length - len) & ~3;
        int t = (head + len) % buf.length;
        int a = Math.min(k, buf.length - t);
        System.arraycopy(b, off, buf, t, a);
        if (a < k) System.arraycopy(b, off + a, buf, 0, k - a);
        len += k;
        written += k;
        notifyAll();
        return k;
    }

    /** hilo de audio: espera hasta waitMs a que haya datos; devuelve bytes leídos (múltiplo de 4) */
    public synchronized int read(byte[] dst, int max, long waitMs) {
        if (len == 0 && !closed) { try { wait(waitMs); } catch (InterruptedException e) { } }
        int k = Math.min(max, len) & ~3;
        int a = Math.min(k, buf.length - head);
        System.arraycopy(buf, head, dst, 0, a);
        if (a < k) System.arraycopy(buf, 0, dst, a, k - a);
        head = (head + k) % buf.length;
        len -= k;
        return k;
    }

    public synchronized void clear() { head = 0; len = 0; }
    public synchronized void close() { closed = true; notifyAll(); }
}
