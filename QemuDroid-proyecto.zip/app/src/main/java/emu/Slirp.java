package emu;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

/**
 * Red "de usuario" estilo QEMU -netdev user, escrita en Java:
 *   invitado 10.0.2.15, puerta de enlace 10.0.2.2 (= 127.0.0.1 del anfitrión), DNS 10.0.2.3.
 * DHCP, ARP, DNS, ICMP eco, NAT de UDP y TCP con sockets reales, y redirección de puertos
 * del anfitrión hacia el invitado (hostfwd). Toda la pila corre en el hilo del emulador;
 * los sockets reales viven en hilos de trabajo que solo tocan colas, así el emulador nunca se bloquea.
 */
public final class Slirp {
    static final int NETW = 0x0A000200, GW = 0x0A000202, DNS = 0x0A000203, GUEST = 0x0A00020F;
    static final byte[] HMAC = {0x52, 0x55, 0x0A, 0x00, 0x02, 0x02};
    static final int WQMAX = 128 * 1024, RCAP = 192 * 1024;

    final E1000 nic;
    final NetIo io;
    final Pc pc;
    byte[] gmac = {-1, -1, -1, -1, -1, -1};
    final Vector outq = new Vector();
    final Vector ev = new Vector();
    volatile boolean pending;
    int ipId = 1;
    public String log = "";
    public long tcpOpen, udpOpen, dnsQ, fwdIn;
    final Hashtable tcp = new Hashtable(), udp = new Hashtable(), ufwPeer = new Hashtable();
    final Vector rules = new Vector();
    int ephem = 40000;
    final long t0 = System.currentTimeMillis();

    public Slirp(E1000 nic, NetIo io, Pc pc) {
        this.nic = nic; this.io = io; this.pc = pc;
        nic.net = this;
    }

    void note(String s) { log = s; }

    // ================================================================ hilos -> emulador
    void post(Runnable r) {
        ev.addElement(r);
        pending = true;
        pc.wake();
    }

    long lastPoll;
    /** se llama a menudo desde Pc.tick() (hilo del emulador) */
    public void tick() {
        long now = System.currentTimeMillis();
        if (!pending && now - lastPoll < 20) return;
        lastPoll = now;
        poll(now);
    }

    void poll(long now) {
        pending = false;
        while (ev.size() > 0) {
            Runnable r = (Runnable) ev.elementAt(0);
            ev.removeElementAt(0);
            try { r.run(); } catch (Throwable t) { note("evento: " + t); }
        }
        for (Enumeration e = tcp.elements(); e.hasMoreElements(); ) timers((T) e.nextElement(), now);
        if (now - lastSweep > 5000) { lastSweep = now; sweepUdp(now); }
        pump();
    }
    long lastSweep;

    /** entregar al invitado lo pendiente mientras haya sitio en el anillo RX */
    public void pump() {
        while (outq.size() > 0) {
            byte[] f = (byte[]) outq.elementAt(0);
            if (!nic.deliver(f, f.length)) break;
            outq.removeElementAt(0);
        }
    }

    void toGuest(byte[] f) {
        if (outq.size() > 2048) { nic.rxDrop++; return; }
        outq.addElement(f);
        pump();
    }

    // ================================================================ desde el invitado
    public void fromGuest(byte[] f, int n) {
        System.arraycopy(f, 6, gmac, 0, 6);
        int type = u16(f, 12);
        if (type == 0x0806) arp(f, n);
        else if (type == 0x0800 && n >= 34) ipIn(f, n);
    }

    void arp(byte[] f, int n) {
        if (n < 42 || u16(f, 20) != 1) return;
        int tip = be32(f, 38);
        if ((tip & 0xFFFFFF00) != NETW || tip == GUEST || (tip & 0xFF) == 0 || (tip & 0xFF) == 255) return;
        byte[] r = new byte[42];
        System.arraycopy(f, 6, r, 0, 6);
        System.arraycopy(HMAC, 0, r, 6, 6);
        r[12] = 8; r[13] = 6;
        System.arraycopy(f, 14, r, 14, 6);
        r[20] = 0; r[21] = 2;
        System.arraycopy(HMAC, 0, r, 22, 6); r[27] = (byte) tip;
        put32(r, 28, tip);
        System.arraycopy(f, 22, r, 32, 10);
        toGuest(r);
    }

    void ipIn(byte[] f, int n) {
        int ihl = (f[14] & 0xF) * 4;
        if ((f[14] >> 4 & 0xF) != 4 || ihl < 20) return;
        int tot = u16(f, 16);
        if (tot == 0 || 14 + tot > n) tot = n - 14;     // TSO deja tot_len a 0
        if ((u16(f, 20) & 0x3FFF) != 0) return;           // sin fragmentos
        int proto = f[23] & 0xFF, src = be32(f, 26), dst = be32(f, 30);
        int l4 = 14 + ihl, len = tot - ihl;
        if (len < 0) return;
        if (proto == 17 && len >= 8) udpIn(f, l4, len, src, dst);
        else if (proto == 6 && len >= 20) tcpIn(f, l4, len, src, dst);
        else if (proto == 1 && len >= 8) icmpIn(f, l4, len, src, dst);
    }

    static String ipStr(int a) { return ((a >>> 24) & 255) + "." + ((a >>> 16) & 255) + "." + ((a >>> 8) & 255) + "." + (a & 255); }
    static int ipParse(String s) {
        int v = 0, p = 0;
        for (int k = 0; k < 4; k++) {
            int q = s.indexOf('.', p); if (q < 0) q = s.length();
            v = (v << 8) | (Integer.parseInt(s.substring(p, q)) & 255); p = q + 1;
        }
        return v;
    }
    /** dirección del invitado -> dirección real del anfitrión */
    static String hostOf(int dst) {
        if (dst == GW) return "127.0.0.1";
        return ipStr(dst);
    }
    /** dirección real -> como la ve el invitado */
    static int guestView(String a) {
        try {
            int v = ipParse(a);
            if ((v >>> 24) == 127) return GW;
            return v;
        } catch (Throwable t) { return GW; }
    }

    // ================================================================ tramas hacia el invitado
    byte[] ipFrame(int src, int dst, int proto, int l4len) {
        byte[] r = new byte[34 + l4len];
        System.arraycopy(gmac, 0, r, 0, 6);
        System.arraycopy(HMAC, 0, r, 6, 6);
        r[12] = 8; r[13] = 0;
        r[14] = 0x45;
        put16(r, 16, 20 + l4len);
        put16(r, 18, ipId++);
        r[20] = 0x40;   // DF
        r[22] = 64; r[23] = (byte) proto;
        put32(r, 26, src); put32(r, 30, dst);
        put16(r, 24, ~csum(r, 14, 20, 0) & 0xFFFF);
        return r;
    }
    void l4sum(byte[] r, int at, int proto) {
        int len = r.length - 34;
        int s = sum(r, 26, 8) + proto + len;
        r[at] = 0; r[at + 1] = 0;
        int c = ~csum(r, 34, len, s) & 0xFFFF;
        if (proto == 17 && c == 0) c = 0xFFFF;
        put16(r, at, c);
    }
    void sendUdp(int src, int sport, int dst, int dport, byte[] d, int off, int n) {
        byte[] r = ipFrame(src, dst, 17, 8 + n);
        put16(r, 34, sport); put16(r, 36, dport); put16(r, 38, 8 + n);
        System.arraycopy(d, off, r, 42, n);
        l4sum(r, 40, 17);
        toGuest(r);
    }

    // ================================================================ ICMP
    int pings;
    void icmpIn(byte[] f, int l4, int len, int src, final int dst) {
        if ((f[l4] & 0xFF) != 8) return;    // solo petición de eco
        final byte[] p = new byte[len];
        System.arraycopy(f, l4, p, 0, len);
        if ((dst & 0xFFFFFF00) == NETW) { echoReply(dst, p); return; }
        if (pings >= 4) return;
        pings++;
        new Thread() { public void run() {
            boolean ok = io.reachable(ipStr(dst), 2000);
            post(new Runnable() { public void run() { pings--; } });
            if (ok) post(new Runnable() { public void run() { echoReply(dst, p); } });
        } }.start();
    }
    void echoReply(int from, byte[] p) {
        byte[] r = ipFrame(from, GUEST, 1, p.length);
        System.arraycopy(p, 0, r, 34, p.length);
        r[34] = 0; r[36] = 0; r[37] = 0;
        put16(r, 36, ~csum(r, 34, p.length, 0) & 0xFFFF);
        toGuest(r);
    }

    // ================================================================ UDP
    final class U {
        int gport; NetIo.Dgram d; long last; boolean dead;
    }
    final class UF {   // redirección UDP entrante
        int hport, gport; NetIo.Dgram d;
    }
    final class Peer { String host; int port; UF uf; }

    void udpIn(byte[] f, int l4, int len, int src, int dst) {
        int sport = u16(f, l4), dport = u16(f, l4 + 2);
        int ulen = Math.min(u16(f, l4 + 4), len) - 8;
        if (ulen < 0) return;
        if (dport == 67) { dhcp(f, l4 + 8, ulen); return; }
        if (dst == DNS && dport == 53) { dns(f, l4 + 8, ulen, sport); return; }
        if (dst == 0xFFFFFFFF || (dst & 0xFF) == 255 || (dst >>> 28) == 14) return;   // difusión / multidifusión
        byte[] data = new byte[ulen];
        System.arraycopy(f, l4 + 8, data, 0, ulen);
        if (dst == GW) {
            Peer pe = (Peer) ufwPeer.get(new Integer(dport));
            if (pe != null) { try { pe.uf.d.send(data, 0, ulen, pe.host, pe.port); } catch (Throwable t) { } return; }
        }
        if ((dst & 0xFFFFFF00) == NETW && dst != GW) return;
        U u = (U) udp.get(new Integer(sport));
        if (u == null || u.dead) {
            final U nu = new U();
            nu.gport = sport;
            try { nu.d = io.udp(0, 0); } catch (Throwable t) { note("UDP: " + t); return; }
            udp.put(new Integer(sport), nu);
            udpOpen++;
            u = nu;
            new Thread() { public void run() { udpReader(nu); } }.start();
        }
        u.last = System.currentTimeMillis();
        try { u.d.send(data, 0, ulen, hostOf(dst), dport); } catch (Throwable t) { note("UDP envío: " + t); }
    }
    void udpReader(final U u) {
        byte[] b = new byte[65536];
        Object[] from = new Object[2];
        while (!u.dead) {
            int n;
            try { n = u.d.recv(b, from); } catch (Throwable t) { break; }
            if (n < 0) continue;
            final byte[] d = new byte[n];
            System.arraycopy(b, 0, d, 0, n);
            final int src = guestView((String) from[0]), sp = ((Integer) from[1]).intValue();
            post(new Runnable() { public void run() { u.last = System.currentTimeMillis(); sendUdp(src, sp, GUEST, u.gport, d, 0, d.length); } });
        }
    }
    void sweepUdp(long now) {
        for (Enumeration e = udp.keys(); e.hasMoreElements(); ) {
            Object k = e.nextElement();
            U u = (U) udp.get(k);
            if (now - u.last > 120000) { u.dead = true; u.d.close(); udp.remove(k); }
        }
    }

    // ================================================================ DHCP
    void dhcp(byte[] f, int o, int n) {
        if (n < 240 || f[o] != 1) return;
        int type = 0;
        for (int i = o + 240; i < o + n; ) {
            int c = f[i] & 0xFF;
            if (c == 255) break;
            if (c == 0) { i++; continue; }
            int l = f[i + 1] & 0xFF;
            if (c == 53) type = f[i + 2] & 0xFF;
            i += 2 + l;
        }
        int reply;
        if (type == 1) reply = 2;               // DISCOVER -> OFFER
        else if (type == 3 || type == 8) reply = 5;   // REQUEST/INFORM -> ACK
        else return;
        byte[] p = new byte[300];
        p[0] = 2; p[1] = 1; p[2] = 6;
        System.arraycopy(f, o + 4, p, 4, 4);    // xid
        System.arraycopy(f, o + 10, p, 10, 2);  // flags
        if (type != 8) put32(p, 16, GUEST);
        put32(p, 20, GW);
        System.arraycopy(f, o + 28, p, 28, 16); // chaddr
        p[236] = 99; p[237] = (byte) 130; p[238] = 83; p[239] = 99;
        int i = 240;
        p[i++] = 53; p[i++] = 1; p[i++] = (byte) reply;
        p[i++] = 54; p[i++] = 4; put32(p, i, GW); i += 4;
        p[i++] = 51; p[i++] = 4; put32(p, i, 86400); i += 4;
        p[i++] = 1; p[i++] = 4; put32(p, i, 0xFFFFFF00); i += 4;
        p[i++] = 3; p[i++] = 4; put32(p, i, GW); i += 4;
        p[i++] = 6; p[i++] = 4; put32(p, i, DNS); i += 4;
        p[i++] = 28; p[i++] = 4; put32(p, i, 0x0A0002FF); i += 4;
        p[i++] = (byte) 255;
        byte[] save = gmac;
        gmac = new byte[] {-1, -1, -1, -1, -1, -1};
        sendUdp(GW, 67, 0xFFFFFFFF, 68, p, 0, p.length);
        gmac = save;
        note(reply == 2 ? "DHCP: oferta 10.0.2.15" : "DHCP: concedida 10.0.2.15");
    }

    // ================================================================ DNS
    void dns(byte[] f, int o, int n, final int gport) {
        if (n < 12) return;
        final byte[] q = new byte[n];
        System.arraycopy(f, o, q, 0, n);
        dnsQ++;
        new Thread() { public void run() {
            final byte[] a = dnsAnswer(q);
            if (a != null) post(new Runnable() { public void run() { sendUdp(DNS, 53, GUEST, gport, a, 0, a.length); } });
        } }.start();
    }

    /** hilo de trabajo: responde con el resolvedor del sistema (tipo A) o reenvía a 8.8.8.8 */
    byte[] dnsAnswer(byte[] q) {
        int qd = u16(q, 4);
        int i = 12;
        StringBuffer name = new StringBuffer();
        if (qd == 1) {
            while (i < q.length && q[i] != 0) {
                int l = q[i] & 0xFF;
                if ((l & 0xC0) != 0 || i + 1 + l > q.length) { name = null; break; }
                if (name.length() > 0) name.append('.');
                for (int k = 0; k < l; k++) name.append((char) (q[i + 1 + k] & 0xFF));
                i += 1 + l;
            }
        } else name = null;
        if (name != null && i + 5 <= q.length) {
            int end = i + 5, qt = u16(q, i + 1), qc = u16(q, i + 3);
            if (qc == 1 && (qt == 1 || qt == 28)) {
                byte[][] ips = qt == 1 ? io.resolve(name.toString()) : null;
                if (qt == 28 || ips != null) {
                    if (qt == 28 && io.resolve("localhost") == null) return forward(q);  // sin resolvedor propio
                    int na = ips == null ? 0 : ips.length;
                    byte[] r = new byte[end + na * 16];
                    System.arraycopy(q, 0, r, 0, end);
                    r[2] = (byte) (0x80 | (q[2] & 0x01)); r[3] = (byte) (0x80 | (na == 0 && qt == 1 ? 3 : 0));
                    put16(r, 6, na); put16(r, 8, 0); put16(r, 10, 0);
                    int p = end;
                    for (int k = 0; k < na; k++) {
                        r[p] = (byte) 0xC0; r[p + 1] = 12; put16(r, p + 2, 1); put16(r, p + 4, 1);
                        put32(r, p + 6, 300); put16(r, p + 10, 4);
                        System.arraycopy(ips[k], 0, r, p + 12, 4);
                        p += 16;
                    }
                    return r;
                }
            }
        }
        return forward(q);
    }
    byte[] forward(byte[] q) {
        NetIo.Dgram d = null;
        try {
            d = io.udp(0, 4000);
            d.send(q, 0, q.length, "8.8.8.8", 53);
            byte[] b = new byte[4096];
            Object[] from = new Object[2];
            int n = d.recv(b, from);
            if (n > 0) { byte[] r = new byte[n]; System.arraycopy(b, 0, r, 0, n); return r; }
        } catch (Throwable t) {
        } finally { if (d != null) d.close(); }
        byte[] r = new byte[q.length];   // SERVFAIL
        System.arraycopy(q, 0, r, 0, q.length);
        r[2] = (byte) (0x80 | (q[2] & 1)); r[3] = (byte) 0x82;
        return r;
    }

    // ================================================================ TCP
    static final int CONNECTING = 0, SYNACK = 1, EST = 2, SYNSENT = 3;
    final class T {
        int gport, rip, rport;
        Long key;
        int state;
        boolean inbound;
        int iss, sndUna, sndNxt, rcvNxt, sndWnd = 65535, mss = 536, advWnd;
        NetIo.Conn c;
        // anfitrión -> invitado (anillo; buf[head] es el byte con secuencia sndUna)
        final byte[] rb = new byte[RCAP];
        int head, rlen;
        boolean hostEof, finSent, finAcked, guestFin, dead, closing;
        // invitado -> anfitrión
        final Vector wq = new Vector();
        int wqBytes;
        long rto; int rtoMs = 1000, tries, dup;
        long born = System.currentTimeMillis();
    }

    static Long key(int gport, int rip, int rport) {
        return new Long(((long) gport << 48) | ((rip & 0xFFFFFFFFL) << 16) | (rport & 0xFFFF));
    }

    void tcpIn(byte[] f, int l4, int len, int src, int dst) {
        int sport = u16(f, l4), dport = u16(f, l4 + 2);
        int seq = be32(f, l4 + 4), ack = be32(f, l4 + 8);
        int off = ((f[l4 + 12] >> 4) & 0xF) * 4;
        int fl = f[l4 + 13] & 0x3F, win = u16(f, l4 + 14);
        if (off < 20 || off > len) return;
        int plen = len - off, po = l4 + off;
        Long k = key(sport, dst, dport);
        T t = (T) tcp.get(k);
        boolean SYN = (fl & 2) != 0, ACK = (fl & 0x10) != 0, RST = (fl & 4) != 0, FIN = (fl & 1) != 0;
        if (t == null) {
            if (RST) return;
            if (SYN && !ACK) { open(k, sport, dst, dport, seq, win, optMss(f, l4 + 20, off - 20)); return; }
            rstFor(dst, dport, sport, ACK ? ack : 0, seq + plen + (SYN ? 1 : 0) + (FIN ? 1 : 0), !ACK);
            return;
        }
        if (RST) { kill(t, false); return; }
        if (t.state == CONNECTING) return;
        if (t.state == SYNSENT) {
            if (SYN && ACK && ack == t.iss + 1) {
                t.rcvNxt = seq + 1; t.sndUna = t.sndNxt = t.iss + 1; t.sndWnd = win;
                t.mss = optMss(f, l4 + 20, off - 20);
                t.state = EST; t.rto = 0; t.tries = 0;
                seg(t, 0x10, t.sndNxt, null, 0, 0);
                startIo(t);
            }
            return;
        }
        if (SYN) { if (t.state == SYNACK) seg(t, 0x12, t.iss, null, 0, 0); else seg(t, 0x10, t.sndNxt, null, 0, 0); return; }
        boolean needAck = false;
        if (ACK) {
            if (t.state == SYNACK && ack == t.iss + 1) {
                t.state = EST; t.sndUna = t.sndNxt = t.iss + 1; t.rto = 0; t.tries = 0;
            }
            if (t.state == EST) {
                int a = ack - t.sndUna;
                int fly = t.sndNxt - t.sndUna;
                if (a > 0 && a <= fly) {
                    int data = a;
                    if (t.finSent && ack == t.sndNxt) { t.finAcked = true; data--; }
                    synchronized (t) {
                        if (data > t.rlen) data = t.rlen;
                        t.head = (t.head + data) % RCAP; t.rlen -= data;
                        t.notifyAll();
                    }
                    t.sndUna = ack; t.dup = 0; t.tries = 0; t.rtoMs = 1000;
                    t.rto = t.sndNxt != t.sndUna ? System.currentTimeMillis() + t.rtoMs : 0;
                } else if (a == 0 && plen == 0 && fly > 0 && win == t.sndWnd) {
                    if (++t.dup == 3) { t.sndNxt = t.sndUna; t.finSent = false; }
                }
                t.sndWnd = win;
            }
        }
        if (t.state != EST) return;
        if (plen > 0) {
            if (seq == t.rcvNxt && !t.guestFin) {
                int space = WQMAX - t.wqBytes;
                int take = Math.min(plen, Math.max(0, space));
                if (take > 0) {
                    byte[] d = new byte[take];
                    System.arraycopy(f, po, d, 0, take);
                    synchronized (t) { t.wq.addElement(d); t.wqBytes += take; t.notifyAll(); }
                    t.rcvNxt += take;
                }
                if (take < plen) FIN = false;
            }
            needAck = true;
        }
        if (FIN && seq + plen == t.rcvNxt && !t.guestFin) {
            t.rcvNxt++;
            synchronized (t) { t.guestFin = true; t.notifyAll(); }
            needAck = true;
        } else if (FIN) needAck = true;
        if (needAck) seg(t, 0x10, t.sndNxt, null, 0, 0);
        output(t);
        if (t.guestFin && t.finAcked) finish(t);
    }

    static int optMss(byte[] f, int o, int n) {
        int m = 536;
        for (int i = 0; i < n; ) {
            int k = f[o + i] & 0xFF;
            if (k == 0) break;
            if (k == 1) { i++; continue; }
            if (i + 1 >= n) break;
            int l = f[o + i + 1] & 0xFF;
            if (l < 2) break;
            if (k == 2 && l == 4) m = u16(f, o + i + 2);
            i += l;
        }
        return Math.max(64, Math.min(m, 1460));
    }

    int window(T t) { return Math.max(0, Math.min(65535, WQMAX - t.wqBytes)); }

    /** segmento TCP al invitado (como visto desde rip:rport) */
    void seg(T t, int flags, int seq, byte[] d, int off, int n) {
        boolean syn = (flags & 2) != 0;
        int ol = syn ? 4 : 0;
        byte[] r = ipFrame(t.rip, GUEST, 6, 20 + ol + n);
        put16(r, 34, t.rport); put16(r, 36, t.gport);
        put32(r, 38, seq); put32(r, 42, (flags & 0x10) != 0 ? t.rcvNxt : 0);
        r[46] = (byte) ((5 + ol / 4) << 4); r[47] = (byte) flags;
        int w = window(t);
        t.advWnd = w;
        put16(r, 48, w);
        if (syn) { r[54] = 2; r[55] = 4; put16(r, 56, 1460); }
        if (n > 0) System.arraycopy(d, off, r, 54 + ol, n);
        l4sum(r, 50, 6);
        toGuest(r);
    }

    void rstFor(int from, int fport, int gport, int seq, int ack, boolean withAck) {
        byte[] r = ipFrame(from, GUEST, 6, 20);
        put16(r, 34, fport); put16(r, 36, gport);
        put32(r, 38, seq); put32(r, 42, ack);
        r[46] = 0x50; r[47] = (byte) (withAck ? 0x14 : 0x04);
        l4sum(r, 50, 6);
        toGuest(r);
    }

    int rnd() { return (int) (System.currentTimeMillis() * 2654435761L) ^ (ipId << 16); }

    void open(Long k, int gport, final int dst, final int dport, int seq, int win, int mss) {
        if ((dst & 0xFFFFFF00) == NETW && dst != GW && !(dst == DNS && dport == 53)) { rstFor(dst, dport, gport, 0, seq + 1, true); return; }
        final T t = new T();
        t.key = k; t.gport = gport; t.rip = dst; t.rport = dport;
        t.rcvNxt = seq + 1; t.sndWnd = win; t.mss = mss;
        t.iss = rnd(); t.sndUna = t.iss; t.sndNxt = t.iss + 1;
        t.state = CONNECTING;
        tcp.put(k, t);
        tcpOpen++;
        final String host = dst == DNS ? "8.8.8.8" : hostOf(dst);
        new Thread() { public void run() {
            NetIo.Conn c = null; Throwable err = null;
            try { c = io.tcp(host, dport, 15000); } catch (Throwable e) { err = e; }
            final NetIo.Conn cc = c; final Throwable ee = err;
            post(new Runnable() { public void run() {
                if (t.dead) { if (cc != null) cc.close(); return; }
                if (cc == null) {
                    note("TCP " + host + ":" + dport + " " + ee);
                    rstFor(t.rip, t.rport, t.gport, 0, t.rcvNxt, true);
                    tcp.remove(t.key); t.dead = true;
                    return;
                }
                t.c = cc;
                t.state = SYNACK;
                seg(t, 0x12, t.iss, null, 0, 0);
                t.rto = System.currentTimeMillis() + t.rtoMs;
                startIo(t);
            } });
        } }.start();
    }

    void startIo(final T t) {
        new Thread() { public void run() { reader(t); } }.start();
        new Thread() { public void run() { writer(t); } }.start();
    }

    void reader(final T t) {
        byte[] b = new byte[16384];
        try {
            java.io.InputStream in = t.c.in();
            while (!t.dead) {
                int n = in.read(b);
                if (n < 0) break;
                synchronized (t) {
                    int p = 0;
                    while (p < n && !t.dead) {
                        while (t.rlen == RCAP && !t.dead) t.wait(1000);
                        int room = RCAP - t.rlen, tail = (t.head + t.rlen) % RCAP;
                        int k = Math.min(n - p, Math.min(room, RCAP - tail));
                        System.arraycopy(b, p, t.rb, tail, k);
                        t.rlen += k; p += k;
                    }
                }
                pending = true; pc.wake();
            }
        } catch (Throwable e) { }
        post(new Runnable() { public void run() { t.hostEof = true; output(t); } });
    }

    void writer(final T t) {
        try {
            java.io.OutputStream out = t.c.out();
            while (true) {
                byte[] d;
                synchronized (t) {
                    while (t.wq.size() == 0 && !t.guestFin && !t.dead) t.wait(1000);
                    if (t.dead) break;
                    if (t.wq.size() == 0) { if (t.guestFin) break; else continue; }
                    d = (byte[]) t.wq.elementAt(0);
                    t.wq.removeElementAt(0);
                }
                out.write(d);
                out.flush();
                synchronized (t) { t.wqBytes -= d.length; }
                pending = true; pc.wake();
            }
            if (!t.dead) t.c.shutOut();
        } catch (Throwable e) {
            post(new Runnable() { public void run() { kill(t, true); } });
        }
    }

    /** mandar datos pendientes al invitado respetando su ventana */
    void output(T t) {
        if (t.state != EST || t.dead || t.closing) return;
        int guard = 0;
        while (guard++ < 64 && outq.size() < 48) {
            int fly = t.sndNxt - t.sndUna - (t.finSent ? 1 : 0);
            int avail;
            synchronized (t) { avail = t.rlen - fly; }
            int wnd = t.sndWnd - (t.sndNxt - t.sndUna);
            int n = Math.min(avail, Math.min(wnd, t.mss));
            if (n <= 0 || t.finSent) break;
            byte[] d = new byte[n];
            synchronized (t) {
                int s = (t.head + fly) % RCAP;
                int a = Math.min(n, RCAP - s);
                System.arraycopy(t.rb, s, d, 0, a);
                if (a < n) System.arraycopy(t.rb, 0, d, a, n - a);
            }
            seg(t, 0x18, t.sndNxt, d, 0, n);
            t.sndNxt += n;
            if (t.rto == 0) t.rto = System.currentTimeMillis() + t.rtoMs;
        }
        int fly = t.sndNxt - t.sndUna;
        int left; synchronized (t) { left = t.rlen - fly; }
        if (t.hostEof && !t.finSent && left <= 0) {
            seg(t, 0x11, t.sndNxt, null, 0, 0);
            t.sndNxt++; t.finSent = true;
            if (t.rto == 0) t.rto = System.currentTimeMillis() + t.rtoMs;
        }
        if (t.guestFin && t.finAcked) finish(t);
    }

    void timers(T t, long now) {
        if (t.dead || t.closing) return;
        if (t.state == EST) {
            if (t.advWnd < 16384 && window(t) >= 32768) seg(t, 0x10, t.sndNxt, null, 0, 0);
            output(t);
            if (t.sndWnd == 0 && t.sndNxt == t.sndUna && t.rto == 0) {
                int r; synchronized (t) { r = t.rlen; }
                if (r > 0) t.rto = now + t.rtoMs;
            }
        }
        if (t.rto != 0 && now >= t.rto) {
            if (++t.tries > 12) { kill(t, true); return; }
            t.rtoMs = Math.min(t.rtoMs * 2, 8000);
            t.rto = now + t.rtoMs;
            if (t.state == SYNACK) seg(t, 0x12, t.iss, null, 0, 0);
            else if (t.state == SYNSENT) seg(t, 0x02, t.iss, null, 0, 0);
            else if (t.state == EST) {
                if (t.sndNxt == t.sndUna) {          // sonda de ventana cero
                    int r; synchronized (t) { r = t.rlen; }
                    if (r > 0) { byte[] d = new byte[1]; synchronized (t) { d[0] = t.rb[t.head]; } seg(t, 0x10, t.sndUna, d, 0, 1); }
                    else t.rto = 0;
                } else {
                    t.sndNxt = t.sndUna; t.finSent = false;   // reenviar desde lo último confirmado
                    int sw = t.sndWnd; if (sw < t.mss) t.sndWnd = t.mss;
                    output(t);
                    t.sndWnd = sw;
                }
            }
        }
        if (t.state == EST && t.guestFin && t.hostEof && now - t.born > 0 && t.finAcked) finish(t);
    }

    void finish(final T t) {
        if (t.closing) return;
        t.closing = true;
        tcp.remove(t.key);
        new Thread() { public void run() {
            try {
                synchronized (t) {   // dejar que el escritor vacíe lo pendiente antes de cerrar
                    for (int i = 0; i < 100 && t.wq.size() > 0; i++) t.wait(100);
                    t.dead = true;
                    t.notifyAll();
                }
                Thread.sleep(100);
            } catch (Throwable e) { }
            if (t.c != null) t.c.close();
        } }.start();
    }

    void kill(T t, boolean sendRst) {
        if (t.dead || t.closing) return;
        if (sendRst && t.state != CONNECTING) rstFor(t.rip, t.rport, t.gport, t.sndNxt, t.rcvNxt, true);
        t.dead = true;
        tcp.remove(t.key);
        synchronized (t) { t.notifyAll(); }
        if (t.c != null) t.c.close();
    }

    // ================================================================ redirección de puertos (hostfwd)
    /** reglas "tcp:8080:80,udp:5353:53" (puerto del anfitrión : puerto del invitado) */
    public String addRules(String spec) {
        StringBuffer res = new StringBuffer();
        if (spec == null) return "";
        int p = 0;
        while (p < spec.length()) {
            int q = spec.indexOf(',', p); if (q < 0) q = spec.length();
            String r = spec.substring(p, q).trim();
            p = q + 1;
            if (r.length() == 0) continue;
            try {
                boolean u = r.startsWith("udp:");
                if (u || r.startsWith("tcp:")) r = r.substring(4);
                int c = r.indexOf(':');
                int hp = Integer.parseInt(c < 0 ? r : r.substring(0, c).trim());
                int gp = c < 0 ? hp : Integer.parseInt(r.substring(c + 1).trim());
                if (u) listenUdp(hp, gp); else listenTcp(hp, gp);
                res.append(u ? "udp " : "tcp ").append(hp).append("->").append(gp).append(" ");
            } catch (Throwable t) {
                res.append("[").append(r).append(": ").append(t.getMessage()).append("] ");
            }
        }
        return res.toString();
    }

    void listenTcp(final int hp, final int gp) throws Exception {
        new Thread() { public void run() {
            final NetIo.Server s;
            try { s = io.listen(hp); } catch (Throwable e) { note("no se pudo abrir tcp " + hp + ": " + e.getMessage()); return; }
            rules.addElement(s);
            while (true) {
                final NetIo.Conn c;
                try { c = s.accept(); } catch (Throwable e) { break; }
                post(new Runnable() { public void run() { inbound(c, gp); } });
            }
        } }.start();
    }

    void inbound(NetIo.Conn c, int gp) {
        fwdIn++;
        T t = new T();
        t.inbound = true;
        t.gport = gp; t.rip = GW; t.rport = nextEphem();
        t.key = key(gp, GW, t.rport);
        t.c = c;
        t.iss = rnd(); t.sndUna = t.iss; t.sndNxt = t.iss + 1;
        t.state = SYNSENT;
        tcp.put(t.key, t);
        seg(t, 0x02, t.iss, null, 0, 0);
        t.rto = System.currentTimeMillis() + t.rtoMs;
    }
    int nextEphem() {
        for (int i = 0; i < 20000; i++) {
            ephem = ephem >= 60000 ? 40000 : ephem + 1;
            if (ufwPeer.get(new Integer(ephem)) == null) return ephem;
        }
        return ephem;
    }

    void listenUdp(final int hp, final int gp) throws Exception {
        final UF uf = new UF();
        uf.hport = hp; uf.gport = gp;
        final Hashtable byPeer = new Hashtable();
        new Thread() { public void run() {
            try { uf.d = io.udp(hp, 0); } catch (Throwable e) { note("no se pudo abrir udp " + hp + ": " + e.getMessage()); return; }
            rules.addElement(uf);
            byte[] b = new byte[65536];
            Object[] from = new Object[2];
            while (true) {
                int n;
                try { n = uf.d.recv(b, from); } catch (Throwable e) { break; }
                if (n < 0) continue;
                final byte[] d = new byte[n];
                System.arraycopy(b, 0, d, 0, n);
                final String h = (String) from[0]; final int pp = ((Integer) from[1]).intValue();
                post(new Runnable() { public void run() {
                    String id = h + ":" + pp;
                    Integer gw = (Integer) byPeer.get(id);
                    if (gw == null) {
                        gw = new Integer(nextEphem());
                        Peer pe = new Peer(); pe.host = h; pe.port = pp; pe.uf = uf;
                        byPeer.put(id, gw); ufwPeer.put(gw, pe);
                    }
                    fwdIn++;
                    sendUdp(GW, gw.intValue(), GUEST, uf.gport, d, 0, d.length);
                } });
            }
        } }.start();
    }

    // ================================================================ utilidades
    static int u16(byte[] b, int o) { return ((b[o] & 0xFF) << 8) | (b[o + 1] & 0xFF); }
    static int be32(byte[] b, int o) { return ((b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF); }
    static void put16(byte[] b, int o, int v) { b[o] = (byte) (v >> 8); b[o + 1] = (byte) v; }
    static void put32(byte[] b, int o, int v) { b[o] = (byte) (v >> 24); b[o + 1] = (byte) (v >> 16); b[o + 2] = (byte) (v >> 8); b[o + 3] = (byte) v; }
    static int sum(byte[] b, int o, int n) {
        int s = 0;
        for (int i = 0; i + 1 < n; i += 2) s += ((b[o + i] & 0xFF) << 8) | (b[o + i + 1] & 0xFF);
        if ((n & 1) != 0) s += (b[o + n - 1] & 0xFF) << 8;
        return s;
    }
    static int csum(byte[] b, int o, int n, int init) {
        int s = init + sum(b, o, n);
        while ((s >>> 16) != 0) s = (s & 0xFFFF) + (s >>> 16);
        return s;
    }

    public String diag() {
        return "red: tcp " + tcp.size() + " (abiertas " + tcpOpen + ") udp " + udp.size() + " dns " + dnsQ
            + " entrantes " + fwdIn + " cola " + outq.size() + (log.length() > 0 ? " | " + log : "");
    }
}
